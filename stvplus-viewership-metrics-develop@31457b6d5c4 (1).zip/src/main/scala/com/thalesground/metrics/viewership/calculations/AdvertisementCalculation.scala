package com.thalesground.metrics.viewership.calculations

import com.thales.avionics.ife.tvs.etl.ETLContext
import com.thalesground.metrics.viewership.utils.CustomDebugUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class AdvertisementCalculation(val etlContext: ETLContext, val debugFlag:Boolean) extends BaseCalculation {

  val logger = Logger.getLogger(getClass().getName())
  val customDebugUtils = new CustomDebugUtils()

  // UDFs
  val getRoadblockTitle = udf(getAdvertisementTitle(_: String, _: String))
  val getRoadblockHashId = udf(getAdvertisementHashId(_: String, _: String))

  // Phoenix output columns
  val columns = Seq[String](
    "flight_id",
    "airline_id",
    "seat_class",
    "flight_takeoff_time",
    "flight_type",
    "flight_day_period",
    "flight_duration",
    "tail_number",
    "flight_airport_origin",
    "flight_airport_dest",
    "flight_number",
    "roadblock_title",
    "ad_title",
    "ad_id",
    "roadblock_type",
    "category",
    "roadblock_metric_id",
    "roadblock_metric_value"
  )
  val outputColumns = columns.map(name => col(name))

  def compute(seatSessionDerivedDF: DataFrame) {
    val adDerivedDF = seatSessionDerivedDF.filter("media_type='ROADBLOCK' and category ='AD'")

    if (!adDerivedDF.head(1).isEmpty) {
      val advertisement_total_time_viewed_df = calculateTotalTimeViewedPerAdTitle(adDerivedDF)
      etlContext.phoenix.save(advertisement_total_time_viewed_df, "viewership_metrics_by_roadblock")

      val advertisement_unique_nb_views_df = calculateNbUniqueViewsPerAdvertisement(adDerivedDF)
      etlContext.phoenix.save(advertisement_unique_nb_views_df, "viewership_metrics_by_roadblock")
    } else {
      logger.info("No Advertisement Data Found. Skipping Calculations...")
    }
  }

  def calculateTotalTimeViewedPerAdTitle(adDerivedDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = adDerivedDF
      .withColumn("roadblock_title", getRoadblockTitle($"program_title", $"media_type"))
      .withColumn("ad_title", getRoadblockTitle($"program_title_ext", $"media_type"))
      .withColumn("ad_id", getRoadblockHashId($"program_title", $"program_title_ext"))
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "roadblock_title",
        "ad_title",
        "ad_id",
        "category",
        "roadblock_type"
      )
      .agg(
        expr("sum(time_viewed) as total_time_viewed")
      )
      .withColumn("roadblock_metric_id", lit("roadblock_total__time_viewed"))
      .withColumn("roadblock_metric_value", coalesce(round($"total_time_viewed", 2), lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("AD TOTAL TIME VIEWED DF", resultDF, debugFlag)

    resultDF
  }

  def calculateNbUniqueViewsPerAdvertisement(adDerivedDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = adDerivedDF
      .withColumn("ad_title", getRoadblockTitle($"program_title_ext", $"media_type"))
      .withColumn("ad_id", $"ad_title")
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "ad_title",
        "ad_id",
        "category",
        "roadblock_type"
      )
      .agg(
        expr("count(distinct seat_id) as distinct_seat_count")
      )
      .withColumn("roadblock_title", lit(""))
      .withColumn("roadblock_metric_id", lit("roadblock_nb_unique_views"))
      .withColumn("roadblock_metric_value", coalesce($"distinct_seat_count", lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("AD NUMBER OF UNIQUE VIEWS DF", resultDF, debugFlag)

    resultDF
  }
}
