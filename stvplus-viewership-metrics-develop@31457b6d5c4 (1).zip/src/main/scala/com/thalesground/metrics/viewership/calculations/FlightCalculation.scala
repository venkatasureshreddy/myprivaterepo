package com.thalesground.metrics.viewership.calculations

import java.sql.Timestamp

import com.thales.avionics.ife.tvs.etl.ETLContext
import com.thalesground.metrics.viewership.utils.CustomDebugUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._


class FlightCalculation(val etlContext: ETLContext, val debugFlag: Boolean) extends BaseCalculation with Serializable {
  val logger = Logger.getLogger(getClass().getName())
  val customDebugUtils = new CustomDebugUtils()

  // UDFs
  val timeDeltaUDF = udf(timeDelta(_: Timestamp, _: Timestamp))

  // Phoenix output columns
  val columns = Seq[String](
    "flight_id",
    "airline_id",
    "seat_class",
    "flight_takeoff_time",
    "flight_type",
    "flight_day_period",
    "flight_duration",
    "tail_number",
    "flight_airport_origin",
    "flight_airport_dest",
    "flight_number",
    "flight_metric_id",
    "flight_metric_value"
  )
  val outputColumns = columns.map(name => col(name))

  def compute(seatSessionDF: DataFrame, flightsDF: DataFrame, instantaneousEventsDF: DataFrame, channelDwellTime: Integer, avodDwellTime: Int) {
    val flight_metrics_flight_total_nb_passengers_df = calculateFlightMetricsFlightTotalPassengers(seatSessionDF, flightsDF)
    etlContext.phoenix.save(flight_metrics_flight_total_nb_passengers_df, "viewership_metrics_by_flight")

    val flightMaxSimulChannelsFinalDf = calculateSimultaneousMaxChannelCount(instantaneousEventsDF, flightsDF, channelDwellTime)
    etlContext.phoenix.save(flightMaxSimulChannelsFinalDf, "viewership_metrics_by_flight")

    val flightMaxSimulVideosFinalDf = calculateSimultaneousMaxAvodCount(instantaneousEventsDF, flightsDF, avodDwellTime)
    etlContext.phoenix.save(flightMaxSimulVideosFinalDf, "viewership_metrics_by_flight")
  }

  def calculateFlightMetricsFlightTotalPassengers(seatSessionDF: DataFrame, flightsDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    // Calculate the total number of passengers per flight
    val numPassengersDF = seatSessionDF.filter($"msg_type".contains("InstantaneousEvent_json"))
      .filter(get_json_object($"msg_data", "$.event.event_type") === "PASSENGER_PRESENCE_INDICATOR")
      .withColumn("seat_class", get_json_object($"msg_data", "$.cabin_class"))
      .withColumn("seat_id", get_json_object($"msg_data", "$.seat_id"))
      .groupBy(
        $"flight_id",
        $"seat_class"
      ).agg(
        expr("count(distinct seat_id) as flight_total_nb_passengers")
      )

      .select(
        "flight_id",
        "seat_class",
        "flight_total_nb_passengers"
      )

    val resultDF = flightsDF
      .join(numPassengersDF, Seq("flight_id"), "left_outer")
      .withColumn("flight_metric_id", lit("flight_total_nb_passengers"))
      .withColumn("flight_metric_value", coalesce($"flight_total_nb_passengers", lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("FLIGHT TOTAL PASSENGERS", resultDF, debugFlag)

    resultDF
  }

  def calculateSimultaneousMaxChannelCount(instantaneousEventsDF: DataFrame, flightsDF: DataFrame, channelDwellTime: Int) = {
    import etlContext.sqlContext.implicits._

    /**
      * SPARK-14948
      * https://issues.apache.org/jira/browse/SPARK-14948?focusedCommentId=15497086&page=com.atlassian.jira.plugin.system.issuetabpanels%3Acomment-tabpanel#comment-15497086
      */
    val inputDF = instantaneousEventsDF
      .select(
        "flight_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_date_arrival",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "media_type",
        "channel_id",
        "program_title",
        "program_title_ext",
        "view_session_hash_id",
        "view_start_time",
        "view_end_time"
      )
      .toDF(
        "flight_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_date_arrival",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "media_type",
        "channel_id",
        "program_title",
        "program_title_ext",
        "view_session_hash_id",
        "view_start_time",
        "view_end_time"
      )

    val seatClassesByFlightDF = inputDF
      .select(
        "flight_id",
        "seat_class"
      )
      .distinct()

    val endDF = inputDF
      .filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .select(
        $"flight_id",
        $"seat_class",
        $"seat_id".as("end_seat_id"),
        $"channel_id".as("end_channel_id"),
        $"program_title".as("end_program_title"),
        $"program_title_ext".as("end_program_title_ext"),
        $"view_end_time".as("end_time")
      )

    val maxSimChannelsDF = inputDF
      .filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .join(
        endDF,
        inputDF("flight_id") === endDF("flight_id") &&
          inputDF("seat_class") === endDF("seat_class") &&
          inputDF("view_start_time") <= endDF("end_time") &&
          inputDF("view_end_time") >= endDF("end_time") &&
          timeDeltaUDF(inputDF("view_start_time"), endDF("end_time")) >= channelDwellTime
      )
      .select(
        inputDF("flight_id"),
        inputDF("seat_class"),
        inputDF("seat_id"),
        inputDF("channel_id"),
        inputDF("view_start_time"),
        inputDF("view_end_time"),
        endDF("end_seat_id"),
        endDF("end_channel_id"),
        endDF("end_program_title"),
        endDF("end_program_title_ext"),
        endDF("end_time")
      )
      .groupBy(
        "flight_id",
        "seat_class",
        "end_seat_id",
        "end_channel_id",
        "end_program_title",
        "end_program_title_ext",
        "end_time"
      )
      .agg(
        expr("count(distinct channel_id) as simultaneous_channels")
      )
      .groupBy(
        "flight_id",
        "seat_class"
      )
      .agg(
        expr("max(simultaneous_channels) as max_simultaneous_channels")
      )

    val resultDF = flightsDF
      .join(seatClassesByFlightDF, Seq("flight_id"), "left_outer")
      .join(maxSimChannelsDF, Seq("flight_id", "seat_class"), "left_outer")
      .withColumn("flight_metric_id", lit("flight_max_simul_channels"))
      .withColumn("flight_metric_value", coalesce($"max_simultaneous_channels", lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("MAX SIMULTANEOUS CHANNELS", resultDF, debugFlag)

    resultDF
  }

  def calculateSimultaneousMaxAvodCount(instantaneousEventsDF: DataFrame, flightsDF: DataFrame, avodDwellTime: Int): DataFrame = {
    import etlContext.sqlContext.implicits._

    val inputDF = instantaneousEventsDF
      .select(
        "flight_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_date_arrival",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "media_type",
        "program_title",
        "program_title_ext",
        "view_session_hash_id",
        "view_start_time",
        "view_end_time"
      )
      .toDF(
        "flight_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_date_arrival",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "media_type",
        "program_title",
        "program_title_ext",
        "view_session_hash_id",
        "view_start_time",
        "view_end_time"
      )

    val seatClassesByFlightDF = inputDF
      .select(
        "flight_id",
        "seat_class"
      )
      .distinct()

    val endDF = inputDF
      .filter("media_type='AVOD'")
      .select(
        $"flight_id",
        $"seat_class",
        $"seat_id".as("end_seat_id"),
        $"program_title".as("end_program_title"),
        $"program_title_ext".as("end_program_title_ext"),
        $"view_end_time".as("end_time")
      )

    val maxSimAvodDF = inputDF
      .filter("media_type='AVOD'")
      .join(
        endDF,
        inputDF("flight_id") === endDF("flight_id") &&
          inputDF("seat_class") === endDF("seat_class") &&
          inputDF("view_start_time") <= endDF("end_time") &&
          inputDF("view_end_time") >= endDF("end_time") &&
          timeDeltaUDF(inputDF("view_start_time"), endDF("end_time")) >= avodDwellTime
      )
      .select(
        inputDF("flight_id"),
        inputDF("seat_class"),
        inputDF("seat_id"),
        inputDF("program_title"),
        inputDF("program_title_ext"),
        inputDF("view_start_time"),
        inputDF("view_end_time"),
        endDF("end_seat_id"),
        endDF("end_program_title"),
        endDF("end_program_title_ext"),
        endDF("end_time")
      )
      .groupBy(
        "flight_id",
        "seat_class",
        "end_seat_id",
        "end_program_title",
        "end_program_title_ext",
        "end_time"
      )
      .agg(
        expr("count(distinct program_title) as simultaneous_content")
      )
      .groupBy(
        "flight_id",
        "seat_class"
      )
      .agg(
        expr("max(simultaneous_content) as max_simultaneous_content")
      )

    val resultDF = flightsDF
      .join(seatClassesByFlightDF, Seq("flight_id"), "left_outer")
      .join(maxSimAvodDF, Seq("flight_id", "seat_class"), "left_outer")
      .withColumn("flight_metric_id", lit("flight_max_simul_avod"))
      .withColumn("flight_metric_value", coalesce($"max_simultaneous_content", lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("MAX SIMULTANEOUS AVOD CONTENT", resultDF, debugFlag)

    resultDF
  }
}
