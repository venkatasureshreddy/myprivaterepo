package com.thalesground.metrics.viewership.utils

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

class FirstNonNullStringAggregate extends UserDefinedAggregateFunction {

  override def inputSchema: org.apache.spark.sql.types.StructType =
    StructType(StructField("column", StringType) :: Nil)

  //internal buffer storage
  override def bufferSchema: StructType = inputSchema

  //output data type
  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  // This is the initial value for your buffer schema.
  override def initialize(buffer: MutableAggregationBuffer) {
    buffer(0) = null
  }

  // This is how to update your buffer schema given an input.
  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    val bufferVal = buffer(0)
    if(bufferVal == null && !input.isNullAt(0)) {
      buffer(0) = input.getAs[String](0)
    }
  }

  // This is how to merge two objects with the bufferSchema type.
  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row) {
    if(!buffer2.isNullAt(0) && buffer1.isNullAt(0)) {
      buffer1(0) = buffer2.getAs[String](0)
    }
  }

  // This is where you output the final value, given the final value of your bufferSchema.
  override def evaluate(buffer: Row): Any = {
    if(!buffer.isNullAt(0)) {
      buffer.getAs[String](0)
    } else {
      null
    }
  }
}