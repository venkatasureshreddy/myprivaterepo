package com.thalesground.metrics.viewership.calculations

import com.thales.avionics.ife.tvs.etl.ETLContext
import com.thalesground.metrics.viewership.utils.CustomDebugUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType

class ChannelCalculation(val etlContext: ETLContext, val debugFlag: Boolean) extends BaseCalculation {
  val logger = Logger.getLogger(getClass().getName())
  val customDebugUtils = new CustomDebugUtils()

  // Phoenix output columns
  val columns = Seq[String](
    "flight_id",
    "airline_id",
    "seat_class",
    "flight_takeoff_time",
    "flight_type",
    "flight_day_period",
    "flight_duration",
    "tail_number",
    "flight_airport_origin",
    "flight_airport_dest",
    "flight_number",
    "channel_id",
    "channel_name",
    "channel_metric_id",
    "channel_metric_value"
  )
  val outputColumns = columns.map(name => col(name))

  def compute(instantaneousEventsDF: DataFrame, transitionEventsDF: DataFrame, channelDwellTime: Int, pctOfCompletion: Float) {
    if (!instantaneousEventsDF.filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null").head(1).isEmpty) {
      val channelTotalDwellTimeDF = calculateChannelTotalDwellTime(instantaneousEventsDF)
      etlContext.phoenix.save(channelTotalDwellTimeDF, "viewership_metrics_by_channel")

      val channel_average_time_viewed_df = calculateAvgSecondsViewedPerChannel(instantaneousEventsDF, channelTotalDwellTimeDF)
      etlContext.phoenix.save(channel_average_time_viewed_df, "viewership_metrics_by_channel")

      val channel_unique_nb_views_df = calculateNbUniqueViewsPerChannel(instantaneousEventsDF, channelDwellTime)
      etlContext.phoenix.save(channel_unique_nb_views_df, "viewership_metrics_by_channel")

      val channel_unique_view_count_df = calculateProgramUniqueViewCountByChannel(instantaneousEventsDF)
      etlContext.phoenix.save(channel_unique_view_count_df, "viewership_metrics_by_channel")

      val channel_average_completion_df = calculateChannelAvgCompletionRate(instantaneousEventsDF, pctOfCompletion)
      etlContext.phoenix.save(channel_average_completion_df, "viewership_metrics_by_channel")

      val channel_total_denied_count_metrics_df = calculateNbDeniedChannels(instantaneousEventsDF, transitionEventsDF)
      etlContext.phoenix.save(channel_total_denied_count_metrics_df, "viewership_metrics_by_channel")
    } else {
      logger.info("No Channel Data Found. Skipping Calculations...")
    }
  }

  def calculateChannelTotalDwellTime(instantaneousEventsDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    // Amount of time channel was viewed by all passengers
    val channelTotalDwellTimeDF = instantaneousEventsDF.filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .filter("channel_id is not null and length(channel_id) > 0 and channel_name is not null and length(channel_name) > 0")
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name"
      )
      .agg(
        expr("sum(time_viewed) as total_time_viewed")
      )
      .withColumn("channel_metric_id", lit("channel_total_dwell_time"))
      .withColumn("channel_metric_value", coalesce(round($"total_time_viewed", 2), lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("CHANNEL TOTAL DWELL TIME DF", channelTotalDwellTimeDF, debugFlag)

    channelTotalDwellTimeDF
  }

  def calculateAvgSecondsViewedPerChannel(instantaneousEventsDF: DataFrame, channelTotalDwellTimeDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    /**
      * SPARK-14948
      * https://issues.apache.org/jira/browse/SPARK-14948?focusedCommentId=15497086&page=com.atlassian.jira.plugin.system.issuetabpanels%3Acomment-tabpanel#comment-15497086
      */
    val cleansedChannelTotalDwellTimeDF = channelTotalDwellTimeDF
      .filter("channel_id is not null and length(channel_id) > 0 and channel_name is not null and length(channel_name) > 0")
      .select(outputColumns: _*)
      .toDF(columns: _*)

    //Number of passengers that viewed this channel during the flight
    val numPassengersPerChannelDF = instantaneousEventsDF.filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .filter("channel_id is not null and length(channel_id) > 0 and channel_name is not null and length(channel_name) > 0")
      .groupBy(
        "airline_id",
        "flight_id",
        "seat_class",
        "channel_id"
      )
      .agg(
        expr("count(distinct seat_id) as num_passengers")
      )
      .select(
        $"flight_id",
        $"airline_id",
        $"seat_class",
        $"channel_id",
        $"num_passengers"
      )

    customDebugUtils.custom_debug_info("CHANNEL NUMBER OF PASSENGERS DF", numPassengersPerChannelDF, debugFlag)

    val seatSessionWithNumPassengersPerChannelDF = cleansedChannelTotalDwellTimeDF.join(numPassengersPerChannelDF, Seq("flight_id", "airline_id", "seat_class", "channel_id"))
    customDebugUtils.custom_debug_info("CHANNEL JOINED WITH NUM PASSENGERS DF", seatSessionWithNumPassengersPerChannelDF, debugFlag)

    //Average seconds viewed per channel=(Channel Dwell Time/Num of Passengers viewed that channel)
    val resultDF = seatSessionWithNumPassengersPerChannelDF
      .withColumn("channel_metric_id", lit("channel_average_time_viewed"))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("CHANNEL AVERAGE TIME PER CHANNEL DF", resultDF, debugFlag)

    resultDF
  }

  def calculateNbUniqueViewsPerChannel(instantaneousEventsDF: DataFrame, channelDwellTime: Int): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = instantaneousEventsDF.filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .filter("channel_id is not null and length(channel_id) > 0 and channel_name is not null and length(channel_name) > 0")
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name"
      )
      .agg(
        expr("sum(time_viewed) as total_time_viewed")
      )
      .filter($"total_time_viewed" > channelDwellTime)
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name"
      )
      .agg(
        expr("count(distinct seat_id) as unique_views")
      )
      .withColumn("channel_metric_id", lit("channel_unique_views"))
      .withColumn("channel_metric_value", coalesce($"unique_views", lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("CHANNEL NUMBER OF UNIQUE VIEWS DF", resultDF, debugFlag)

    resultDF
  }

  def calculateProgramUniqueViewCountByChannel(instantaneousEvents: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = instantaneousEvents.filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .filter("channel_id is not null and length(channel_id) > 0 and channel_name is not null and length(channel_name) > 0")
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_title",
        "program_title_ext"
      )
      .agg(
        expr("sum(time_viewed) as total_time_viewed")
      )
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name"
      )
      .agg(
        expr("count(total_time_viewed) as unique_views")
      )
      .withColumn("channel_metric_id", lit("channel_unique_views_count"))
      .withColumn("channel_metric_value", coalesce($"unique_views", lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("CHANNEL NUMBER OF UNIQUE VIEWS DF", resultDF, debugFlag)

    resultDF
  }

  def calculateChannelAvgCompletionRate(seatSessionDerivedDF: DataFrame, pctOfCompletion: Float): DataFrame = {
    import etlContext.sqlContext.implicits._

    //Channel average completion rate=Sum(Average completion rate of each program for this channel)/Total num of programs viewed on a channel
    val programViewCountDF = seatSessionDerivedDF.filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .filter("channel_id is not null and length(channel_id) > 0 and channel_name is not null and length(channel_name) > 0")
      .select(
        $"flight_id",
        $"airline_id",
        $"seat_id",
        $"channel_id",
        $"program_title",
        $"program_title_ext"
      ).distinct()
      .groupBy(
        $"flight_id",
        $"airline_id",
        $"channel_id",
        $"program_title",
        $"program_title_ext"
      )
      .agg(
        expr("count(program_title) as program_view_count")
      )
      .select(
        "flight_id",
        "airline_id",
        "channel_id",
        "program_title",
        "program_title_ext",
        "program_view_count"
      )
    customDebugUtils.custom_debug_info("CHANNEL PROGRAM VIEW COUNT", programViewCountDF, debugFlag)

    val completeDF = seatSessionDerivedDF.filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .filter("channel_id is not null and length(channel_id) > 0 and channel_name is not null and length(channel_name) > 0")
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_title",
        "program_title_ext",
        "program_length"
      )
      .agg(
        expr("sum(time_viewed) as total_time_viewed")
      )
      .filter($"total_time_viewed" / $"program_length" >= pctOfCompletion)
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_title",
        "program_title_ext",
        "program_length"
      )
      .agg(
        expr("count(program_title) as program_viewed_to_completion")
      )
      .select(
        "flight_id",
        "airline_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_title",
        "program_length",
        "program_title_ext",
        "program_viewed_to_completion"
      )

    customDebugUtils.custom_debug_info("CHANNEL PROGRAMS VIEWED TO COMPLETION", completeDF, debugFlag)

    val incompleteDF = seatSessionDerivedDF.filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .filter("channel_id is not null and length(channel_id) > 0 and channel_name is not null and length(channel_name) > 0")
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_title",
        "program_title_ext",
        "program_length"
      )
      .agg(
        expr("sum(time_viewed) as total_time_viewed")
      )
      .filter($"total_time_viewed" / $"program_length" < pctOfCompletion)
      .select(
        $"flight_id",
        $"airline_id",
        $"seat_id",
        $"seat_class",
        $"flight_takeoff_time",
        $"flight_type",
        $"flight_day_period",
        $"flight_duration",
        $"tail_number",
        $"flight_airport_origin",
        $"flight_airport_dest",
        $"flight_number",
        $"channel_id",
        $"channel_name",
        $"program_title",
        $"program_length",
        $"program_title_ext",
        lit(0).as("program_viewed_to_completion")
      )

    customDebugUtils.custom_debug_info("CHANNEL PROGRAMS NOT VIEWED TO COMPLETION", incompleteDF, debugFlag)

    val programCompletionInfoDF = completeDF.unionAll(incompleteDF)
    customDebugUtils.custom_debug_info("ALL CHANNEL PROGRAMS WITH PROGRAM COMPLETION COUNT", programCompletionInfoDF, debugFlag)

    val programCompletionInfoWithViewCountDF = programCompletionInfoDF.join(programViewCountDF, Seq("flight_id", "airline_id", "channel_id", "program_title", "program_title_ext"))
      .filter("channel_id IS NOT NULL")
      .withColumn("average_program_completion_rate", ($"program_viewed_to_completion" / $"program_view_count") * 100)

    customDebugUtils.custom_debug_info("AVERAGE COMPLETION RATE PER PROGRAM", programCompletionInfoWithViewCountDF, debugFlag)

    val resultDF = programCompletionInfoWithViewCountDF
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name"
      )
      .agg(
        expr("sum(program_viewed_to_completion) as channel_metric_value")
      )
      .withColumn("channel_metric_id", lit("channel_viewed_to_completion"))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("CHANNEL COMPLETION", resultDF, debugFlag)

    resultDF
  }

  def calculateNbDeniedChannels(instantaneousEventsDF: DataFrame, transitionEventsDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val channelsDF = instantaneousEventsDF.filter("media_type='TV_CHANNEL' OR cast(channel_id as int) is not null")
      .filter("channel_id is not null and length(channel_id) > 0 and channel_name is not null and length(channel_name) > 0")
      .select(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "flight_aircraft_type",
        "channel_id",
        "channel_name"
      )
      .distinct()

    //Channel Total Denied count
    val deniedDF = transitionEventsDF.filter("media_type IN ('TV_CHANNEL') AND channel_id is not null AND length(channel_id) > 0 AND channel_name is not null AND length(channel_name) > 0")
      .withColumn("channel_denied_indicator", when($"channel_denied".equalTo("NO_AVAILABLE_TUNER"), lit(1)).otherwise(lit(0)))
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "channel_id"
      )
      .agg(
        expr("sum(channel_denied_indicator) as channel_denied_indicator_sum")
      )

    val resultDF = channelsDF.join(deniedDF, Seq("flight_id", "airline_id", "seat_class", "channel_id"), "left_outer")
      .withColumn("channel_metric_id", lit("channel_denied_count"))
      .withColumn("channel_metric_value", coalesce($"channel_denied_indicator_sum", lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("channel_total_denied_count_query", resultDF, debugFlag)

    resultDF
  }
}
