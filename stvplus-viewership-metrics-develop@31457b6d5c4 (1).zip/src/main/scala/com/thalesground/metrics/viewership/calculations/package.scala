package com.thalesground.metrics.viewership

import java.security.MessageDigest
import java.sql.Timestamp

package object calculations {

  def getCategory(str: String): Array[String] = {
    if (str == null) null
    else {
      str.split(",").map(_.capitalize)
    }
  }

  def getAdvertisementTitle: ((String, String) => String) = {
    (programTitleExt: String, mediaType: String) =>
    {
      if (mediaType == "ROADBLOCK") {
        if (programTitleExt == null || programTitleExt.trim.length == 0 || programTitleExt.isEmpty) {
          null
        } else {
          programTitleExt
        }
      } else null
    }
  }

  def getAdvertisementHashId: ((String, String) => String) = {
    (programTitle: String, programTitleExt: String) =>
    {
      val s = programTitle + programTitleExt
      MessageDigest.getInstance("MD5").digest(s.getBytes()).map(0xFF & _).map { "%02x".format(_) }.foldLeft(""){_ + _}
    }
  }

  def timeDelta: ((Timestamp, Timestamp) => Long) = {
    (startTime: Timestamp, endTime: Timestamp) =>
    {
      (endTime.getTime - startTime.getTime) / 1000
    }
  }
}
