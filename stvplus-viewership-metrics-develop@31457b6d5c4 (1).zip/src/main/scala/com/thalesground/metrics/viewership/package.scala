package com.thalesground.metrics

import java.text.{Normalizer, SimpleDateFormat}
import java.util.regex.Pattern

import org.apache.log4j.Logger

package object viewership {
  val logger = Logger.getLogger(getClass().getName())

  val format = "yyyy-MM-dd HH:mm:ss.SSS"


  def flight_day_period(hour: Int): String = hour match {
    case hour if hour >= 0 && hour < 12  => "Morning"
    case hour if hour >= 12 && hour < 18 => "Noon"
    case hour if hour >= 18 && hour < 24 => "Night"
    case _                               => "Unknown"
  }

  def flight_duration(originTime: Long, destinationTime: Long): Long = {
    val diff = destinationTime - originTime
    diff / 60
  }

  def flight_type(origin_country_code: String, destination_country_code: String): String = {
    if (origin_country_code != null && destination_country_code != null && !origin_country_code.isEmpty && !destination_country_code.isEmpty) {
      if (origin_country_code.toLowerCase == destination_country_code.toLowerCase) {
        "Domestic"
      } else
        "International"
    } else
      "N/A"
  }

  def deAccent: ((String) => String) = {
    (Input: String) =>
    {
      if (Input == null || Input.isEmpty) {
        ""
      } else {
        val nfdNormalizedString: String = Normalizer.normalize(Input, Normalizer.Form.NFD)
        val pattern: Pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+")
        pattern.matcher(nfdNormalizedString).replaceAll("")
      }
    }
  }

  def getCustomUniqueString(input: String): Long = {
    input.hashCode()
  }
}
