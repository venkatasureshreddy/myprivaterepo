package com.thalesground.metrics.viewership

import com.thales.avionics.ife.tvs.etl.ETLContext
import com.thales.avionics.ife.tvs.etl.hivecompaction.{HiveCompactor, HiveCompactorOptions}
import com.thalesground.metrics.viewership.calculations._
import com.thalesground.metrics.viewership.utils._
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class Viewership(etlContext: ETLContext, hiveCompactorOptions: HiveCompactorOptions, debugFlag: Boolean) {

  private val logger = Logger.getLogger(getClass().getName())
  private val customDebugUtils = new CustomDebugUtils()

  // UDFs
  val deAccentInput = udf(deAccent(_: String))
  val flightDayPeriodUDF = udf(flight_day_period(_: Int))
  val flightDurationUDF = udf(flight_duration(_: Long, _: Long))
  val flightTypeUDF = udf(flight_type(_: String, _: String))
  val getCustomUniqueStringUDF = udf(getCustomUniqueString(_: String))

  private def loadSeatSessionDF(logFlightIdString: String): DataFrame = {
    etlContext.selectLogs("stvplus_seatsession", logFlightIdString).withColumn("airline_id", lower(col("airline_id")))
  }

  private def loadFlightsDF(flightIdString: String): DataFrame = {
    import etlContext.sqlContext.implicits._

    val flightsDF = etlContext.phoenix.load("flights").where(s"id in (${flightIdString}) AND log_departure_time is not null AND log_arrival_time is not null")

    val flightsDerivedDF = flightsDF
        .select(
          $"id".as("flight_id"),
          $"airline_id",
          $"log_departure_time".as("flight_takeoff_time"),
          flightTypeUDF($"origin_country_code", $"destination_country_code").as("flight_type"),
          flightDayPeriodUDF(hour($"log_departure_time")).as("flight_day_period"),
          flightDurationUDF(unix_timestamp($"log_departure_time", format), unix_timestamp($"log_arrival_time", format)).as("flight_duration"),
          $"tail_number",
          $"log_arrival_time".as("flight_date_arrival"),
          $"origin_airport".as("flight_airport_origin"),
          $"destination_airport".as("flight_airport_dest"),
          $"flight_number",
          $"aircraft_type".as("flight_aircraft_type")
        )

    customDebugUtils.custom_debug_info("FLIGHTS DERIVED DF", flightsDerivedDF, debugFlag)

    flightsDerivedDF
  }

  def run(channelDwellTime: Int,  avodDwellTime: Int, pctOfCompletion: Float, flightsPerBatch: Int): Unit = {
    import etlContext.sqlContext.implicits._

    var flights = etlContext.flightProductStatus.getFiltered()

    var inputSize = flights.count()
    logger.info("Count of unprocessed flights: " + inputSize)

    if (inputSize > 0) {
      compact

      while (inputSize > 0) {
        val currentFlightBatch = flights.limit(flightsPerBatch)

        val flightIdList = currentFlightBatch.select("flight_id").filter("flight_id IS NOT NULL").dropDuplicates().map(line => line).collect().map(_(0)).toList
        val flightIdString = s"'${flightIdList.mkString("','")}'"

        val logFlightIdList = currentFlightBatch.select("log_flight_id").filter("log_flight_id IS NOT NULL").dropDuplicates().map(line => line).collect().map(_(0)).toList
        val logFlightIdString = s"'${logFlightIdList.mkString("','")}'"

        runWithTableCompactionReadLock(() => {
          // Load flight metadata
          val flightsDF = loadFlightsDF(flightIdString)

          // Load seat session hive table
          val seatSessionRawDF = loadSeatSessionDF(logFlightIdString)

          // Get only data for instantaneous and transition events
          val sanitizedSeatSessionDF = seatSessionRawDF.where("msg_type IN ('InstantaneousEvent_json','TransitionEvent_json')").withColumn("msg_data", deAccentInput($"msg_data"))

          val instantaneousEventsDF = DataComposer.getInstantaneousEvents(etlContext.sqlContext, sanitizedSeatSessionDF, flightsDF, debugFlag)
          instantaneousEventsDF.cache()

          val transitionEvents = DataComposer.getTransitionEvents(etlContext.sqlContext, sanitizedSeatSessionDF, flightsDF, debugFlag)
          transitionEvents.cache()

          // TODO see if possible to run these operations in parallel (non-blocking)
          flightMetrics(sanitizedSeatSessionDF, flightsDF, instantaneousEventsDF, channelDwellTime, avodDwellTime)
          channelMetrics(instantaneousEventsDF, transitionEvents, channelDwellTime, pctOfCompletion)
          programMetrics(instantaneousEventsDF, channelDwellTime, pctOfCompletion)
          vodMetrics(instantaneousEventsDF, avodDwellTime, pctOfCompletion)
          categoryMetrics(instantaneousEventsDF)
          advertisementMetrics(instantaneousEventsDF)

          instantaneousEventsDF.unpersist()
          transitionEvents.unpersist()
        })

        updateToFlightProductStatus(logFlightIdString, currentFlightBatch)

        flights = flights.except(currentFlightBatch)
        inputSize = inputSize - flightsPerBatch
      }
    }
  }

  def compact() = HiveCompactor.compact(hiveCompactorOptions, etlContext.sqlContext)

  def runWithTableCompactionReadLock(callable: () => Unit) = HiveCompactor.runWithTableCompactionReadLock(hiveCompactorOptions.lockOptions, hiveCompactorOptions.hiveTables.map(ht => ht.name).toSet, callable)

  private def channelMetrics(instantaneousSummaryDF: DataFrame, transitionEventsDF: DataFrame, channelDwellTime: Int, pctOfCompletion: Float) {
    val channel = new ChannelCalculation(etlContext, debugFlag)
    channel.compute(instantaneousSummaryDF, transitionEventsDF, channelDwellTime, pctOfCompletion)
  }

  private def advertisementMetrics(instantaneousSummaryDF: DataFrame) {
    val advertisement = new AdvertisementCalculation(etlContext, debugFlag)
    advertisement.compute(instantaneousSummaryDF)
  }

  private def flightMetrics(seatSessionDF: DataFrame, flightsDF: DataFrame, instantaneousSummaryDF: DataFrame, channelDwellTime :Int, avodDwellTime: Int) {
    val flight = new FlightCalculation(etlContext, debugFlag)
    flight.compute(seatSessionDF, flightsDF, instantaneousSummaryDF, channelDwellTime, avodDwellTime)
  }

  private def vodMetrics(instantaneousSummaryDF: DataFrame, avodDwellTime: Int, pctOfCompletion: Float) {
    val vod = new VodCalculation(etlContext, debugFlag)
    vod.compute(instantaneousSummaryDF, avodDwellTime, pctOfCompletion)
  }

  private def programMetrics(instantaneousSummaryDF: DataFrame, channelDwellTime: Int, pctOfCompletion: Float) {
    val program = new ProgramCalculation(etlContext, debugFlag)
    program.compute(instantaneousSummaryDF, channelDwellTime, pctOfCompletion)
  }

  private def categoryMetrics(instantaneousSummaryDF: DataFrame) {
    val category = new CategoryCalculation(etlContext, debugFlag)
    category.compute(instantaneousSummaryDF)
  }

  def getFlightsHashDataFrame(flightsDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    flightsDF
      .select(
        $"flight_id",
        $"modified_date_time",
        $"modified_by",
        getCustomUniqueStringUDF(concat_ws("-",$"flight_id",$"modified_date_time",$"modified_by")).as("unique_string")
      )
  }

  def getUnchangedFlightIdsString(flightsAtBeginningHashDF: DataFrame, flightsBeforeUpdatingFPSHashDF: DataFrame): String = {
    val unchangedFlightsHashDF = flightsAtBeginningHashDF.join(flightsBeforeUpdatingFPSHashDF, Seq("flight_id", "unique_string"))
    val flightsList = unchangedFlightsHashDF.select("FLIGHT_ID").dropDuplicates().rdd.collect().map(_(0).toString()).toList
    val flightIdsString = s"'${flightsList.mkString("','")}'"

    logger.info("UNCHANGED FLIGHT IDS DURING VIEWERSHIP CALCULATIONS = " + flightIdsString)

    flightIdsString
  }

  def updateToFlightProductStatus(logFlightIdsString: String, flightsDFAtBeginning: DataFrame) = {
    val flightsBeforeUpdatingFPSDataFrame = etlContext.flightProductStatus.getUnfiltered().where ("log_flight_id IN ( " + logFlightIdsString + " )").filter ("PRODUCT_ID = 'stvplus'").filter ("LOGS_RECEIVED = true").filter ("VIEWERSHIP_CALCULATED = false")

    val flightsAtBeginningHashDF = getFlightsHashDataFrame(flightsDFAtBeginning)
    val flightsBeforeUpdatingFPSHashDF = getFlightsHashDataFrame(flightsBeforeUpdatingFPSDataFrame)

    val unChangedFlights = getUnchangedFlightIdsString(flightsAtBeginningHashDF, flightsBeforeUpdatingFPSHashDF)

    val finalFpsFlightsDF = flightsBeforeUpdatingFPSDataFrame.filter(s"FLIGHT_ID IN (${unChangedFlights})")
      .select(
        "product_id",
        "flight_id"
      )
      .withColumn("viewership_calculated", lit(true))
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    etlContext.phoenix.save(finalFpsFlightsDF, "flight_product_status")
    logger.info ("Updated viewership metrics flag  to true for flights - " + unChangedFlights)
  }
}