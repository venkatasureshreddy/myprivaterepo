package com.thalesground.metrics.viewership.calculations

import com.thales.avionics.ife.tvs.etl.ETLContext
import com.thalesground.metrics.viewership.utils.CustomDebugUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType

class VodCalculation(val etlContext: ETLContext, val debugFlag:Boolean) extends BaseCalculation {
  val logger = Logger.getLogger(getClass().getName())
  val customDebugUtils = new CustomDebugUtils()

  val columns = Seq[String](
    "flight_id",
    "airline_id",
    "seat_class",
    "flight_takeoff_time",
    "flight_type",
    "flight_day_period",
    "flight_duration",
    "tail_number",
    "flight_airport_origin",
    "flight_airport_dest",
    "flight_number",
    "vod_id",
    "vod_name",
    "vod_studio_source",
    "vod_category",
    "vod_duration",
    "vod_type",
    "vod_metric_id",
    "vod_metric_value"
  )
  val outputColumns = columns.map(name => col(name))

  def compute(seatSessionDerivedDF: DataFrame, avodDwellTime: Int, pctOfCompletion: Float) {
    val vodContentDF = getVodContent(seatSessionDerivedDF)

    if (!vodContentDF.head(1).isEmpty) {
      val vod_total_time_viewed_df = calculateVodTotalSecondsViewed(vodContentDF)
      etlContext.phoenix.save(vod_total_time_viewed_df, "viewership_metrics_by_vod_content")

      val vod_nb_unique_views_df = calculateVodUniqueView(vodContentDF, avodDwellTime)
      etlContext.phoenix.save(vod_nb_unique_views_df, "viewership_metrics_by_vod_content")

      val vod_nb_completed_views_df = calculateCompletionViews(vodContentDF, pctOfCompletion)
      etlContext.phoenix.save(vod_nb_completed_views_df, "viewership_metrics_by_vod_content")
    } else {
     logger.info("No AVOD Data Found. Skipping Calculations...")
    }
  }

  def getVodContent(seatSessionDerivedDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val compute_vod_type_df = seatSessionDerivedDF.filter("media_type='AVOD' OR content_type='TV Series'")
      .groupBy(
        "airline_id",
        "flight_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "program_title",
        "program_length",
        "content_type",
        "category"
      )
      .agg(
        expr("sum(time_viewed) as total_time_viewed")
      )
      .withColumn("vod_duration", $"program_length".cast(IntegerType))
      .withColumnRenamed("content_type", "vod_type")
      .withColumnRenamed("category", "vod_category")
      .withColumn("vod_id", $"program_title")
      .withColumn("vod_name", $"program_title")
      .withColumn("vod_studio_source", $"program_title")
      .select(
        "airline_id",
        "flight_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "vod_id",
        "vod_name",
        "vod_studio_source",
        "vod_category",
        "vod_duration",
        "vod_type",
        "total_time_viewed"
      )

    customDebugUtils.custom_debug_info("VOD CONTENT DF", compute_vod_type_df, debugFlag)

    compute_vod_type_df
  }

  //vod total secs viewed metric calculation
  def calculateVodTotalSecondsViewed(vodContentDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = vodContentDF
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "vod_id",
        "vod_name",
        "vod_studio_source",
        "vod_duration",
        "vod_type",
        "vod_category"
      )
      .agg(
        expr("sum(total_time_viewed) as total_time_viewed_sum")
      )
      .withColumn("vod_metric_id", lit("vod_total_time_viewed"))
      .withColumn("vod_metric_value", coalesce(round($"total_time_viewed_sum", 2), lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("VOD TOTAL TIME VIEWED",  resultDF, debugFlag)

    resultDF
  }

  def calculateVodUniqueView(vodContentDF: DataFrame, avodDwellTime: Int): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = vodContentDF.filter($"total_time_viewed" >= avodDwellTime)
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "vod_id",
        "vod_name",
        "vod_studio_source",
        "vod_duration",
        "vod_type",
        "vod_category"
      )
      .agg(
        expr("count(distinct seat_id) as distinct_seat_count")
      )
      .withColumn("vod_metric_id", lit("vod_nb_unique_views"))
      .withColumn("vod_metric_value", coalesce($"distinct_seat_count", lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("VOD UNIQUE VIEWS", resultDF, debugFlag)

    resultDF
  }

  def calculateCompletionViews(vodContentDF: DataFrame, pctOfCompletion: Float): DataFrame = {
    import etlContext.sqlContext.implicits._

    val completeDF = vodContentDF.filter($"total_time_viewed" / $"vod_duration" >= pctOfCompletion)
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "vod_id",
        "vod_name",
        "vod_studio_source",
        "vod_duration",
        "vod_type",
        "vod_category"
      )
      .agg(
        expr("count(distinct seat_id) as distinct_seat_count")
      )
      .withColumn("vod_metric_id", lit("nb_completed_views"))
      .withColumn("vod_metric_value", coalesce($"distinct_seat_count", lit(0)))
      .select(outputColumns: _*)

    customDebugUtils.custom_debug_info("VOD CONTENT VIEWED TO COMPLETION", completeDF, debugFlag)

    val incompleteDF = vodContentDF.filter($"total_time_viewed" / $"vod_duration" < pctOfCompletion)
      .withColumn("vod_metric_id", lit("nb_completed_views"))
      .withColumn("vod_metric_value", lit(0))
      .select(outputColumns: _*)
    customDebugUtils.custom_debug_info("VOD CONTENT INCOMPLETE", incompleteDF, debugFlag)

    val resultDF = completeDF.unionAll(incompleteDF).transform(etlContext.transformations.addModifiedByAndDateTimeFields())
    customDebugUtils.custom_debug_info("VOD COMPLETIONS FINAL", resultDF, debugFlag)

    resultDF
  }
}