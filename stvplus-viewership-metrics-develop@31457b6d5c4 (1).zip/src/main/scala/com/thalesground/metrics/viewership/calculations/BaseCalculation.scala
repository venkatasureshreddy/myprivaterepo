package com.thalesground.metrics.viewership.calculations

trait BaseCalculation {

}
