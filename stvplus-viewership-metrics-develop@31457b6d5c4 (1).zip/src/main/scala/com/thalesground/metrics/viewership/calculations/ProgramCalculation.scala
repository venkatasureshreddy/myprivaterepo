package com.thalesground.metrics.viewership.calculations

import com.thales.avionics.ife.tvs.etl.ETLContext
import com.thalesground.metrics.viewership.utils.{CsvUnionAggregate, CustomDebugUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType

class ProgramCalculation(etlContext: ETLContext, val debugFlag: Boolean) extends BaseCalculation {

  val logger = Logger.getLogger(getClass().getName())
  val customDebugUtils = new CustomDebugUtils()

  val columns = Seq[String](
    "flight_id",
    "airline_id",
    "seat_class",
    "flight_takeoff_time",
    "flight_type",
    "flight_day_period",
    "flight_duration",
    "tail_number",
    "flight_airport_origin",
    "flight_airport_dest",
    "flight_number",
    "channel_id",
    "channel_name",
    "program_id",
    "program_name",
    "program_origin",
    "program_duration",
    "program_metric_id",
    "program_metric_value"
  )
  val outputColumns = columns.map(name => col(name))

  // UDFs
  val csvUnionUDF = new CsvUnionAggregate

  def compute(seatSessionDerivedDF: DataFrame, channelDwellTime: Int, pctOfCompletion: Float): Unit = {
    val programDerivedDF = calculateProgramDerived(seatSessionDerivedDF)

    if (!programDerivedDF.head(1).isEmpty) {
      // program_total_time_viewed
      val pgm_total_time_viewed_df = calculateTotalTimeViewedPerProgram(programDerivedDF)
      etlContext.phoenix.save(pgm_total_time_viewed_df, "viewership_metrics_by_program")

      // program_nb_unique_views
      val pgm_unique_viewed_query_df = calculateNbUniqueViewsPerProgram(programDerivedDF, channelDwellTime)
      etlContext.phoenix.save(pgm_unique_viewed_query_df, "viewership_metrics_by_program")

      val viewedToCompletionDF = calculateProgramsViewedToCompletion(programDerivedDF, pctOfCompletion)
      etlContext.phoenix.save(viewedToCompletionDF, "viewership_metrics_by_program")

      val uniqueViews = calculateProgramUniqueViews(programDerivedDF)
      etlContext.phoenix.save(uniqueViews, "viewership_metrics_by_program")
    } else {
      logger.info("No Program Data Found. Skipping Calculations...")
    }
  }

  def calculateProgramDerived(seatSessionDerivedDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = seatSessionDerivedDF.filter("media_type = 'TV_CHANNEL' OR cast(channel_id as int) is not null")
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_title",
        "program_title_ext",
        "program_length"
      )
      .agg(
        expr("sum(time_viewed) as total_time_viewed")
      )
      .withColumn("program_id", $"program_title")
      .withColumn("program_name", $"program_title")
      .withColumn("program_origin", $"program_title")
      .withColumn("program_duration", $"program_length".cast(IntegerType))
      .select(
        "flight_id",
        "airline_id",
        "seat_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_id",
        "program_name",
        "program_origin",
        "program_duration",
        "total_time_viewed"
      )

    customDebugUtils.custom_debug_info("PROGRAM DERIVED DF", resultDF, debugFlag)

    resultDF
  }

  def calculateTotalTimeViewedPerProgram(programDerivedDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = programDerivedDF
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_id",
        "program_name",
        "program_origin",
        "program_duration"
      )
      .agg(
        expr("sum(total_time_viewed) as total_time_viewed_sum")
      )
      .withColumn("program_metric_id", lit("program_total_time_viewed"))
      .withColumn("program_metric_value", coalesce(round($"total_time_viewed_sum", 2), lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("PROGRAM TOTAL TIME VIEWED DF", resultDF, debugFlag)

    resultDF
  }

  def calculateNbUniqueViewsPerProgram(programDerivedDF: DataFrame, channelDwellTime: Int): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = programDerivedDF.filter($"total_time_viewed" > channelDwellTime)
        .groupBy(
          "flight_id",
          "airline_id",
          "seat_class",
          "flight_takeoff_time",
          "flight_type",
          "flight_day_period",
          "flight_duration",
          "tail_number",
          "flight_airport_origin",
          "flight_airport_dest",
          "flight_number",
          "program_id",
          "program_name",
          "program_origin",
          "program_duration"
        )
      .agg(
        expr("count(distinct seat_id) as program_unique_views_value")
      )
      .withColumn("program_metric_id", lit("program_nb_unique_views"))
      .withColumn("program_metric_value", coalesce($"program_unique_views_value", lit(0)))
      .withColumn("channel_id", lit(""))
      .withColumn("channel_name", lit(""))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("PROGRAM UNIQUE VIEWS DF", resultDF, debugFlag)

    resultDF
  }

  // TODO Might be possible to merge these calculations with the completion metrics done on the channel level to avoid duplicate work
  def calculateProgramsViewedToCompletion(programDerivedDF: DataFrame, pctOfCompletion: Float): DataFrame = {
    import etlContext.sqlContext.implicits._

    val completeDF = programDerivedDF.filter($"total_time_viewed" / $"program_duration" >= pctOfCompletion)
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "program_id",
        "program_name",
        "program_origin",
        "program_duration"
      )
      .agg(
        expr("count(total_time_viewed) as times_viewed_to_completion")
      )
      .withColumn("channel_id", lit(""))
      .withColumn("channel_name", lit(""))
      .withColumn("program_metric_id", lit("program_viewed_to_completion"))
      .withColumn("program_metric_value", coalesce($"times_viewed_to_completion", lit(0)))
      .select(outputColumns: _*)

    customDebugUtils.custom_debug_info("PROGRAMS VIEWED TO COMPLETION DF", completeDF, debugFlag)

    val incompleteDF = programDerivedDF.filter($"total_time_viewed" / $"program_duration" < pctOfCompletion)
      .withColumn("channel_id", lit(""))
      .withColumn("channel_name", lit(""))
      .withColumn("program_metric_id", lit("program_viewed_to_completion"))
      .withColumn("program_metric_value", lit(0))
      .select(outputColumns: _*)

    customDebugUtils.custom_debug_info("PROGRAMS NOT VIEWED TO COMPLETION DF", incompleteDF, debugFlag)

    val resultDF = completeDF.unionAll(incompleteDF)
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_id",
        "program_name",
        "program_origin",
        "program_duration",
        "program_metric_id"
      )
      .agg(
        expr("sum(program_metric_value) as program_metric_value")
      )
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())


    customDebugUtils.custom_debug_info("PROGRAM COMPLETION DF", resultDF, debugFlag)

    resultDF
  }

  def calculateProgramUniqueViews(programDerivedDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val resultDF = programDerivedDF
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "channel_id",
        "channel_name",
        "program_id",
        "program_name",
        "program_origin",
        "program_duration"
      )
      .agg(
        expr("count(total_time_viewed) as program_unique_views_value")
      )
      .withColumn("program_metric_id", lit("program_unique_views"))
      .withColumn("program_metric_value", coalesce($"program_unique_views_value", lit(0)))
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("PROGRAM TIMES VIEWED", resultDF, debugFlag)

    resultDF
  }
}
