package com.thalesground.metrics.viewership.utils

import org.apache.spark.sql.DataFrame

class CustomDebugUtils {

  def custom_debug_info(description: String, df: DataFrame, debugFlag: Boolean) {
    if (debugFlag) {
      println("")
      println(description)
      if (df == null) {
        println("DataFrame Was Null...")
      } else {
        println("Column Count: " + df.columns.size)
        df.show(200, false)
      }
    }
  }
}