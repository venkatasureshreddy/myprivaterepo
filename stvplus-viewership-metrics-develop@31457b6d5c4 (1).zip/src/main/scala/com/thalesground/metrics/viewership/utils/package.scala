package com.thalesground.metrics.viewership

import java.security.MessageDigest
import java.sql.Timestamp
import java.text.SimpleDateFormat

package object utils {

  def getContentType: ((String, String) => String) = {
    (programTitleExt: String, mediaType: String) =>
    {
      if (mediaType == "AVOD") {
        if (programTitleExt == null ||  programTitleExt.isEmpty || programTitleExt.trim.length <1 || programTitleExt.replace(":","").trim.length < 1) {
          "Movie"
        } else {
          "TV Series"
        }
      } else ""
    }
  }

  def getProgramTitleExt: ((String) => String) = {
    (str: String) =>
    {
      if (str == null || str.isEmpty || str.trim.length < 1 || str.replace(":","").trim.length < 1) {
        null
      } else {
        str
      }
    }
  }

  def getTimestamp: ((String, String) => Long) = {
    (format: String, dateString: String) =>
    {
      val sdf = new SimpleDateFormat(format)
      sdf.parse(dateString.replace("T", " ").replace("Z", "")).getTime
    }
  }

  def getCategoryString: ((String) => String) = {
    (str: String) =>
    {
      if (str == null) "Other"
      else {
        val strTmp = str.replace("[", "").replace("]", "").replace("\"", "")
        strTmp
      }
    }
  }

  def getViewSessionHashId: ((String, String, String, String, Timestamp) => String) = {
    (seatId: String, channelId: String, programTitle: String, programTitleExt: String, timestamp: Timestamp) =>
    {
      val s = seatId + channelId + programTitle + programTitleExt + timestamp.toString
      MessageDigest.getInstance("MD5").digest(s.getBytes()).map(0xFF & _).map { "%02x".format(_) }.foldLeft(""){_ + _}
    }
  }

  def min: ((Integer, Integer) => Integer) = {
    (diff: Integer, length: Integer) =>
    {
      scala.math.min(diff, length)
    }
  }
}
