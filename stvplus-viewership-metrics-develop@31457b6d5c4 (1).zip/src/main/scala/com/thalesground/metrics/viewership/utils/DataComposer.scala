package com.thalesground.metrics.viewership.utils

import java.sql.Timestamp

import org.apache.spark.sql.{DataFrame, SQLContext}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.expressions.Window


object DataComposer {

  val customDebugUtils = new CustomDebugUtils()

  // UDFs
  val getProgramTitleExtUDF = udf(getProgramTitleExt(_: String))
  val getContentUDF = udf(getContentType(_: String, _: String))
  val getTimestampUDF = udf(getTimestamp(_: String, _: String))
  val getCategoryStrUDF = udf(getCategoryString(_: String))
  val getViewSessionHashIdUDF = udf(getViewSessionHashId(_: String, _: String, _: String, _: String, _: Timestamp))
  val minUDF = udf(min(_: Integer, _: Integer))

  def getInstantaneousEvents(sqlContext: SQLContext, seatSessionRawDF: DataFrame, flightsDF: DataFrame, debugFlag: Boolean): DataFrame = {
    import sqlContext.implicits._

    val instantaneousDF = seatSessionRawDF.filter($"msg_type".contains("InstantaneousEvent_json"))
      .withColumn("seat_id", get_json_object(col("msg_data"), "$.seat_id"))
      .withColumn("program_title", get_json_object(col("msg_data"), "$.event.position_update.program_title"))
      .withColumn("program_title_ext", getProgramTitleExtUDF(get_json_object($"msg_data", "$.event.position_update.program_title_ext")))
      .withColumn("channel_id", get_json_object($"msg_data", "$.event.position_update.channel_id"))
      .withColumn("position", get_json_object(col("msg_data"), "$.event.position_update.position").cast(LongType))
      .withColumn("time_stamp_str", get_json_object(col("msg_data"), "$.time_stamp"))
      .withColumn("time_stamp", unix_timestamp(regexp_replace($"time_stamp_str", "\\.[0-9]+", ""),"yyyy-MM-dd'T'HH:mm:ss'Z'").cast("timestamp"))
      .withColumn("update_type", get_json_object($"msg_data", "$.event.position_update.update_type"))
      .withColumn("seat_class", get_json_object(col("msg_data"), "$.cabin_class"))
      .filter($"seat_id".isNotNull && $"time_stamp".isNotNull && $"program_title".isNotNull && length($"program_title") >= 1)
      .filter($"position".isNotNull.and($"update_type".isin("PLAYBACK_START", "PROGRAM_START", "PLAYBACK_END", "PROGRAM_END", "PLAYING", "PLAYBACK_END_BY_INTERRUPT", "PLAYBACK_START_AFTER_INTERRUPT", "PAUSE", "RESUME", "SEEK", "DISMISSED", "STOPPED")).and($"program_title".isNotNull))
      .withColumn("is_start", when(col("update_type").isin("PLAYBACK_START", "PROGRAM_START", "PLAYBACK_START_AFTER_INTERRUPT","PLAYING", "RESUME", "SEEK"), 0).otherwise(1))
      .select(
        "flight_id",
        "airline_id",
        "seat_id",
        "seat_class",
        "program_title",
        "program_title_ext",
        "channel_id",
        "position",
        "time_stamp",
        "update_type",
        "is_start"
      )
      .orderBy($"airline_id".asc, $"flight_id".asc, $"seat_id".asc, $"time_stamp".asc, $"is_start".asc)

    customDebugUtils.custom_debug_info("ORIGINAL INSTANTANEOUS EVENTS FROM HIVE", instantaneousDF, debugFlag)

    // Get a list of metadata for all content viewed as relying on instantaneous isn't sufficient
    val instantaneousProgramDetailsDF = seatSessionRawDF.filter($"msg_type".contains("InstantaneousEvent_json"))
      .where(get_json_object($"msg_data", "$.event.position_update.program_details").isNotNull)
      .withColumn("program_title", get_json_object(col("msg_data"), "$.event.position_update.program_title"))
      .withColumn("program_title_ext", getProgramTitleExtUDF(get_json_object($"msg_data", "$.event.position_update.program_details.program_title_ext")))
      .withColumn("program_length", get_json_object($"msg_data", "$.event.position_update.program_details.program_length"))
      .withColumn("program_type", get_json_object($"msg_data", "$.event.position_update.program_details.program_type"))
      .withColumn("channel_id", get_json_object($"msg_data", "$.event.position_update.program_details.channel_id"))
      .withColumn("channel_number", get_json_object($"msg_data", "$.event.position_update.program_details.channel_number"))
      .withColumn("channel_name", get_json_object($"msg_data", "$.event.position_update.program_details.channel_name"))
      .withColumn("category", get_json_object($"msg_data", "$.event.position_update.program_details.category"))
      .withColumn("media_type",when(get_json_object($"msg_data","$.event.position_update.program_details.media_type") === null, get_json_object($"msg_data","$.event.interrupt_media.media_type")).otherwise(get_json_object($"msg_data","$.event.position_update.program_details.media_type")))
      .withColumn("roadblock_type", get_json_object($"msg_data", "$.event.position_update.program_details.roadblock_type"))
      .withColumn("update_type", get_json_object($"msg_data", "$.event.position_update.update_type"))
      .withColumn("content_type", getContentUDF($"program_title_ext", $"media_type"))
      .filter($"program_title".isNotNull && length($"program_title") >= 1 && $"program_length".isNotNull)
      .filter($"update_type".isin("PROGRAM_START", "PROGRAM_END").and($"program_title".isNotNull))
      .select(
        "flight_id",
        "airline_id",
        "program_title",
        "program_title_ext",
        "program_length",
        "program_type",
        "channel_id",
        "channel_number",
        "channel_name",
        "category",
        "media_type",
        "content_type",
        "roadblock_type"
      )
      .filter($"program_title".isNotNull.and(!$"program_title".isNaN) and ($"program_length".isNotNull))
      .distinct()

    customDebugUtils.custom_debug_info("CONTENT METADATA FROM INSTANTANEOUS EVENTS", instantaneousProgramDetailsDF,debugFlag)

    def getTransitionProgramDetailsDf(stateField: String) = {
      seatSessionRawDF.filter($"msg_type".contains("TransitionEvent_json"))
        .where(get_json_object($"msg_data", "$." + stateField + ".access_media").isNotNull)
        .withColumn("program_title", get_json_object(col("msg_data"), "$." + stateField + ".access_media.program_title"))
        .withColumn("program_title_ext", getProgramTitleExtUDF(get_json_object($"msg_data", "$." + stateField + ".access_media.program_title_ext")))
        .withColumn("program_length", get_json_object($"msg_data", "$." + stateField + ".access_media.program_length"))
        .withColumn("program_type", get_json_object($"msg_data", "$." + stateField + ".access_media.program_type"))
        .withColumn("channel_id", get_json_object($"msg_data", "$." + stateField + ".access_media.channel_id"))
        .withColumn("channel_number", get_json_object($"msg_data", "$." + stateField + ".access_media.channel_number"))
        .withColumn("channel_name", get_json_object($"msg_data", "$." + stateField + ".access_media.channel_name"))
        .withColumn("category", get_json_object($"msg_data", "$." + stateField + ".access_media.category"))
        .withColumn("media_type", get_json_object($"msg_data", "$." + stateField + ".access_media.media_type"))
        .withColumn("roadblock_type", get_json_object($"msg_data", "$." + stateField + ".access_media.roadblock_type"))
        .withColumn("content_type", getContentUDF($"program_title_ext", $"media_type"))
        .filter($"program_title".isNotNull && length($"program_title") >= 1 && $"program_length".isNotNull)
        .select(
          "flight_id",
          "airline_id",
          "program_title",
          "program_title_ext",
          "program_length",
          "program_type",
          "channel_id",
          "channel_number",
          "channel_name",
          "category",
          "media_type",
          "content_type",
          "roadblock_type"
        )
    }

    val transitionProgramDetailsDF = getTransitionProgramDetailsDf("new_state").unionAll(getTransitionProgramDetailsDf("old_state")).distinct()
    customDebugUtils.custom_debug_info("CONTENT METADATA FROM TRANSITION EVENTS", transitionProgramDetailsDF, debugFlag)

    val firstNonNull = new FirstNonNullStringAggregate
    /*
    This weird sql is because various log entries have null and non-null values for the same program
    This sql finds the first non-null value for particular program, and prevents duplicate rows for the same program
    For example:
    program_name: "Gumball", category: null, program_name: "Gumball", category = ["Kids"]
    should generate 1 row:
    program_name: "Gumball", category = ["Kids"]
     */
    val combinedProgramDetailsDF = instantaneousProgramDetailsDF
      .join(transitionProgramDetailsDF, Seq("flight_id", "airline_id", "media_type", "channel_id", "program_title", "program_title_ext"), "full_outer")
      .select(
        $"flight_id",
        $"airline_id",
        $"program_title",
        $"program_title_ext",
        coalesce(transitionProgramDetailsDF.col("program_length"), instantaneousProgramDetailsDF.col("program_length")).as("program_length"),
        coalesce(transitionProgramDetailsDF.col("program_type"), instantaneousProgramDetailsDF.col("program_type")).as("program_type"),
        $"channel_id",
        coalesce(transitionProgramDetailsDF.col("channel_number"), instantaneousProgramDetailsDF.col("channel_number")).as("channel_number"),
        coalesce(transitionProgramDetailsDF.col("channel_name"), instantaneousProgramDetailsDF.col("channel_name")).as("channel_name"),
        coalesce(transitionProgramDetailsDF.col("category"), instantaneousProgramDetailsDF.col("category")).as("category"),
        $"media_type",
        coalesce(transitionProgramDetailsDF.col("content_type"), instantaneousProgramDetailsDF.col("content_type")).as("content_type"),
        coalesce(transitionProgramDetailsDF.col("roadblock_type"), instantaneousProgramDetailsDF.col("roadblock_type")).as("roadblock_type")
      )
      .groupBy("flight_id", "airline_id", "media_type", "channel_id", "program_title", "program_title_ext")
      .agg(
        firstNonNull($"program_length").as("program_length"),
        firstNonNull($"program_type").as("program_type"),
        firstNonNull($"channel_number").as("channel_number"),
        firstNonNull($"channel_name").as("channel_name"),
        firstNonNull($"category").as("category"),
        firstNonNull($"content_type").as("content_type"),
        firstNonNull($"roadblock_type").as("roadblock_type")
      )

    customDebugUtils.custom_debug_info("COMBINED PROGRAM DETAILS", combinedProgramDetailsDF, debugFlag)

    // Some episodes of a program may be missing category information. Attempt to fill-in if available for other episodes
    val categoriesByProgramDF = combinedProgramDetailsDF.filter($"category".isNotNull)
      .select(
        "flight_id",
        "media_type",
        "channel_id",
        "program_title",
        "category"
      )
      .distinct()
      .groupBy(
        "flight_id",
        "media_type",
        "channel_id",
        "program_title"
      )
      .agg(
        first("category").as("category_merged")
      )

    customDebugUtils.custom_debug_info("CATEGORIES BY PROGRAM", categoriesByProgramDF, debugFlag)

    val programDetailsDF = combinedProgramDetailsDF
      .select(
        $"flight_id",
        $"airline_id",
        $"channel_id",
        $"program_title",
        $"program_title_ext",
        $"program_length",
        $"program_type",
        $"channel_number",
        $"channel_name",
        $"media_type",
        $"content_type",
        $"roadblock_type"
      )
      .join(
        categoriesByProgramDF,
        combinedProgramDetailsDF("flight_id") === categoriesByProgramDF("flight_id") &&
          combinedProgramDetailsDF("media_type") === categoriesByProgramDF("media_type") &&
          combinedProgramDetailsDF("channel_id") <=> categoriesByProgramDF("channel_id") &&
          combinedProgramDetailsDF("program_title") === categoriesByProgramDF("program_title"),
        "left_outer"
      )
      .select(
        combinedProgramDetailsDF("flight_id"),
        $"airline_id",
        combinedProgramDetailsDF("channel_id"),
        combinedProgramDetailsDF("program_title"),
        $"program_title_ext",
        $"program_length",
        $"program_type",
        $"channel_number",
        $"channel_name",
        combinedProgramDetailsDF("media_type"),
        getCategoryStrUDF($"category_merged").as("category"),
        $"content_type",
        $"roadblock_type"
      )
      .orderBy($"airline_id".asc, $"flight_id".asc, $"channel_id".asc, $"program_title".asc, $"program_title_ext".asc)

    customDebugUtils.custom_debug_info("METADATA FOR ALL VIEWED CONTENT", programDetailsDF, debugFlag)

    // Join program meta data with existing data
    val decoratedInstantaneousEventsDF = instantaneousDF
      .join(
        programDetailsDF,
        instantaneousDF("flight_id") === programDetailsDF("flight_id") &&
          instantaneousDF("airline_id") === programDetailsDF("airline_id") &&
          instantaneousDF("program_title") === programDetailsDF("program_title") &&
          (instantaneousDF("program_title_ext") === programDetailsDF("program_title_ext") || (instantaneousDF("program_title_ext").isNull && programDetailsDF("program_title_ext").isNull) || (instantaneousDF("program_title_ext").isNull && programDetailsDF("program_title_ext").isNotNull)) &&
          (instantaneousDF("channel_id") === programDetailsDF("channel_id") || (instantaneousDF("channel_id").isNull && programDetailsDF("channel_id").isNull))
      )
      .select(
        instantaneousDF("flight_id"),
        instantaneousDF("airline_id"),
        instantaneousDF("seat_id"),
        instantaneousDF("seat_class"),
        instantaneousDF("program_title"),
        programDetailsDF("program_title_ext"),
        instantaneousDF("channel_id"),
        instantaneousDF("position"),
        instantaneousDF("time_stamp"),
        instantaneousDF("update_type"),
        instantaneousDF("is_start"),
        programDetailsDF("program_length"),
        programDetailsDF("program_type"),
        programDetailsDF("channel_number"),
        programDetailsDF("channel_name"),
        programDetailsDF("media_type"),
        programDetailsDF("category"),
        programDetailsDF("content_type"),
        programDetailsDF("roadblock_type")
      )
      .orderBy($"airline_id".asc, $"flight_id".asc, $"seat_id".asc, $"time_stamp".asc, $"is_start".desc)
    customDebugUtils.custom_debug_info("INSTANTANEOUS EVENTS WITH METADATA ADDED", decoratedInstantaneousEventsDF, debugFlag)

    // Find the next program/content watched by each passenger.
    // PLAYBACK_START_AFTER_INTERRUPT was included here as this has been observed as a start point on some flights
    val nextProgramSpec = Window.partitionBy("flight_id", "seat_id").orderBy($"time_stamp".asc)
    val nextProgramInfoDF = decoratedInstantaneousEventsDF.filter("update_type IN('PROGRAM_START','PLAYBACK_START','PLAYBACK_START_AFTER_INTERRUPT')")
      .select(
        "airline_id",
        "flight_id",
        "seat_id",
        "media_type",
        "channel_id",
        "program_title",
        "program_title_ext",
        "time_stamp"
      )
      .distinct()
      .withColumn("current_program_start_time_stamp", $"time_stamp")
      .withColumn("next_media_type",lead("media_type",1,"NOT_AVAILABLE").over(nextProgramSpec))
      .withColumn("next_channel_id",lead("channel_id",1,"NOT_AVAILABLE").over(nextProgramSpec))
      .withColumn("next_program_title",lead("program_title",1,"NOT_AVAILABLE").over(nextProgramSpec))
      .withColumn("next_program_title_ext",lead("program_title_ext",1,"NOT_AVAILABLE").over(nextProgramSpec))
      .withColumn("next_program_start_time_stamp",lead("time_stamp",1,"NOT_AVAILABLE").over(nextProgramSpec))
      .select(
        "airline_id",
        "flight_id",
        "seat_id",
        "media_type",
        "channel_id",
        "program_title",
        "program_title_ext",
        "current_program_start_time_stamp",
        "next_media_type",
        "next_channel_id",
        "next_program_title",
        "next_program_title_ext",
        "next_program_start_time_stamp"
      )

    customDebugUtils.custom_debug_info("NEXT CONTENT WATCHED", nextProgramInfoDF, debugFlag)

    val instantaneousEventsWithNextProgramInfoDF = decoratedInstantaneousEventsDF
      .join(
        nextProgramInfoDF,
        decoratedInstantaneousEventsDF("flight_id") === nextProgramInfoDF("flight_id") &&
          decoratedInstantaneousEventsDF("airline_id") === nextProgramInfoDF("airline_id") &&
          decoratedInstantaneousEventsDF("seat_id") === nextProgramInfoDF("seat_id") &&
          decoratedInstantaneousEventsDF("media_type") === nextProgramInfoDF("media_type") &&
          decoratedInstantaneousEventsDF("program_title") === nextProgramInfoDF("program_title") &&
          (decoratedInstantaneousEventsDF("program_title_ext") === nextProgramInfoDF("program_title_ext") || (decoratedInstantaneousEventsDF("program_title_ext").isNull && nextProgramInfoDF("program_title_ext").isNull)) &&
          (decoratedInstantaneousEventsDF("channel_id") === nextProgramInfoDF("channel_id") || (decoratedInstantaneousEventsDF("channel_id").isNull && nextProgramInfoDF("channel_id").isNull)) &&
          decoratedInstantaneousEventsDF("time_stamp") >= nextProgramInfoDF("current_program_start_time_stamp") &&
          (nextProgramInfoDF("next_program_start_time_stamp").isNull || decoratedInstantaneousEventsDF("time_stamp") <= nextProgramInfoDF("next_program_start_time_stamp")),
        "left_outer"
      )
      .select(
        decoratedInstantaneousEventsDF("flight_id"),
        decoratedInstantaneousEventsDF("airline_id"),
        decoratedInstantaneousEventsDF("seat_id"),
        decoratedInstantaneousEventsDF("seat_class"),
        decoratedInstantaneousEventsDF("program_title"),
        decoratedInstantaneousEventsDF("program_title_ext"),
        decoratedInstantaneousEventsDF("channel_id"),
        decoratedInstantaneousEventsDF("position"),
        decoratedInstantaneousEventsDF("time_stamp"),
        decoratedInstantaneousEventsDF("update_type"),
        decoratedInstantaneousEventsDF("is_start"),
        decoratedInstantaneousEventsDF("program_length"),
        decoratedInstantaneousEventsDF("program_type"),
        decoratedInstantaneousEventsDF("channel_number"),
        decoratedInstantaneousEventsDF("channel_name"),
        decoratedInstantaneousEventsDF("media_type"),
        decoratedInstantaneousEventsDF("category"),
        decoratedInstantaneousEventsDF("content_type"),
        decoratedInstantaneousEventsDF("roadblock_type"),
        nextProgramInfoDF("next_media_type"),
        nextProgramInfoDF("next_channel_id"),
        nextProgramInfoDF("next_program_title"),
        nextProgramInfoDF("next_program_title_ext"),
        nextProgramInfoDF("next_program_start_time_stamp")
      )
      .orderBy($"airline_id".asc, $"flight_id".asc, $"seat_id".asc, $"time_stamp".asc, $"is_start".asc)

    customDebugUtils.custom_debug_info("INSTANTANEOUS EVENTS WITH NEXT CONTENT WATCHED", instantaneousEventsWithNextProgramInfoDF, debugFlag)

    // Add in flight meta data
    val instantaneousEventsWithNextProgramInfoAndFlightInfoDF = instantaneousEventsWithNextProgramInfoDF.join(flightsDF, Seq("airline_id", "flight_id"))
      .withColumn("flight_start_time", $"flight_takeoff_time")
      .withColumn("flight_end_time", $"flight_date_arrival")

    customDebugUtils.custom_debug_info("INSTANTANEOUS EVENTS WITH FLIGHT METADATA", instantaneousEventsWithNextProgramInfoAndFlightInfoDF, debugFlag)

    val contentDurationSpec = Window.partitionBy("airline_id", "flight_id", "seat_id", "media_type", "channel_id", "program_title", "program_title_ext").orderBy($"time_stamp".asc, $"is_start".desc)
    val positionDeltaDF = instantaneousEventsWithNextProgramInfoAndFlightInfoDF
      .withColumn("next_time_stamp", lead("time_stamp", 1, null).over(contentDurationSpec))
      .withColumn("next_position", lead("position", 1, null).over(contentDurationSpec))
      .withColumn("next_update_type", lead("update_type", 1, "NOT_AVAILABLE").over(contentDurationSpec))
      .withColumn("next_is_start", lead("is_start", 1, null).over(contentDurationSpec))
      .withColumn("prev_position", lag("position", 1, null).over(contentDurationSpec))
      .orderBy($"airline_id".asc, $"flight_id".asc, $"seat_id".asc, $"time_stamp".asc, $"is_start".desc)
      .withColumn("position_seconds_duration",
        when($"prev_position".isNull.and($"next_position".isNull).and($"update_type".isin("PLAYBACK_END", "PROGRAM_END", "PLAYBACK_END_BY_INTERRUPT")), $"position".cast(IntegerType))
          .when($"next_position".isNull.and($"update_type".isin("PROGRAM_START", "PLAYBACK_START", "PLAYBACK_START_AFTER_INTERRUPT", "PLAYING", "RESUME", "SEEK")).and($"next_program_title" === "NOT_AVAILABLE"), minUDF((unix_timestamp($"flight_end_time") - unix_timestamp($"time_stamp")).cast(IntegerType), ($"program_length" - $"position").cast(IntegerType)))
          .when($"next_position".isNull.and($"update_type".isin("PROGRAM_START", "PLAYBACK_START", "PLAYBACK_START_AFTER_INTERRUPT")).and($"next_program_title" !== "NOT_AVAILABLE"), minUDF((unix_timestamp($"next_program_start_time_stamp") - unix_timestamp($"time_stamp")).cast(IntegerType), ($"program_length" - $"position").cast(IntegerType)))
          .when($"prev_position".isNotNull.and($"next_position".isNotNull).and($"update_type".isin("PROGRAM_START", "PLAYBACK_START", "PLAYBACK_START_AFTER_INTERRUPT", "PLAYING", "RESUME")).and($"next_update_type".isin("PROGRAM_END", "PLAYBACK_END", "PLAYBACK_END_BY_INTERRUPT", "PLAYING", "PAUSE", "DISMISSED", "STOPPED")), ($"next_position"  - $"position").cast(IntegerType))
          .when($"update_type".isin("PROGRAM_START", "PLAYBACK_START", "PLAYBACK_START_AFTER_INTERRUPT", "PLAYING", "RESUME").and($"next_update_type".isin("PROGRAM_START", "PLAYBACK_START", "PLAYBACK_START_AFTER_INTERRUPT", "PROGRAM_END", "PLAYBACK_END", "PLAYBACK_END_BY_INTERRUPT", "PLAYING", "PAUSE", "DISMISSED", "STOPPED")), ($"next_position" - $"position").cast(IntegerType))
          .when(($"update_type" === "PLAYING").and($"next_update_type" === "NOT_AVAILABLE"), lit(0))
          .when($"update_type".isin("PROGRAM_START", "PLAYBACK_START", "PLAYBACK_START_AFTER_INTERRUPT", "PLAYING", "RESUME").and($"next_update_type" === "SEEK"), (unix_timestamp($"next_time_stamp") - unix_timestamp($"time_stamp")).cast(IntegerType))
          .when(($"update_type" === "SEEK").and($"next_update_type".isin("PLAYING", "PAUSE", "PROGRAM_END", "PLAYBACK_END", "PLAYBACK_END_BY_INTERRUPT")).and($"next_position" >= $"position"), ($"next_position" - $"position").cast(IntegerType))
          .otherwise(lit(0))
      )

    customDebugUtils.custom_debug_info("INSTANTANEOUS EVENTS WITH POSITION DELTA", positionDeltaDF, debugFlag)

    val resultDF = positionDeltaDF
      .filter($"position_seconds_duration".isNotNull && $"position_seconds_duration" > 0)
      .withColumn("end_time_stamp", coalesce($"next_time_stamp", $"next_program_start_time_stamp", $"flight_end_time"))
      .filter($"end_time_stamp".isNotNull)
      .withColumn("next_program_start_time_stamp", coalesce($"next_program_start_time_stamp", $"flight_end_time"))
      .filter($"next_program_start_time_stamp".isNotNull)
      .withColumn("view_session_hash_id", getViewSessionHashIdUDF($"seat_id", $"next_channel_id",$"next_program_title",$"next_program_title_ext",$"next_program_start_time_stamp"))
      .select(
        "airline_id",
        "flight_id",
        "flight_takeoff_time",
        "flight_date_arrival",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_aircraft_type",
        "seat_id",
        "seat_class",
        "time_stamp",
        "media_type",
        "channel_id",
        "program_title",
        "program_title_ext",
        "program_length",
        "program_type",
        "channel_number",
        "channel_name",
        "category",
        "content_type",
        "roadblock_type",
        "end_time_stamp",
        "position_seconds_duration",
        "view_session_hash_id"
      )
      .orderBy($"airline_id".asc, $"flight_id".asc, $"seat_id".asc, $"time_stamp".asc)
      .groupBy(
      "airline_id",
      "flight_id",
      "flight_takeoff_time",
      "flight_date_arrival",
      "flight_airport_origin",
      "flight_airport_dest",
      "flight_number",
      "flight_type",
      "flight_day_period",
      "flight_duration",
      "tail_number",
      "flight_aircraft_type",
      "seat_id",
      "seat_class",
      "media_type",
      "channel_id",
      "program_title",
      "program_title_ext",
      "program_length",
      "channel_number",
      "channel_name",
      "category",
      "content_type",
      "roadblock_type",
      "view_session_hash_id"
    )
    .agg(
      expr("min(time_stamp) as view_start_time"),
      expr("max(end_time_stamp) as view_end_time"),
      expr("sum(position_seconds_duration) as time_viewed")
    )
    .select(
      "flight_id",
      "airline_id",
      "seat_id",
      "seat_class",
      "flight_takeoff_time",
      "flight_type",
      "flight_day_period",
      "flight_duration",
      "tail_number",
      "flight_date_arrival",
      "flight_airport_origin",
      "flight_airport_dest",
      "flight_number",
      "flight_aircraft_type",
      "media_type",
      "channel_id",
      "channel_name",
      "channel_number",
      "program_title",
      "program_title_ext",
      "program_length",
      "category",
      "content_type",
      "roadblock_type",
      "view_session_hash_id",
      "view_start_time",
      "view_end_time",
      "time_viewed"
    )
    .orderBy($"airline_id".asc, $"flight_id".asc, $"seat_id".asc, $"view_start_time".asc)

    customDebugUtils.custom_debug_info("INSTANTANEOUS FINAL", resultDF, debugFlag)

    resultDF
  }

  def getTransitionEvents(sqlContext: SQLContext, seatSessionRawDF: DataFrame, flightsDF: DataFrame, debugFlag: Boolean): DataFrame = {
    import sqlContext.implicits._

    val transitionEventsWithFlightInfoDF = seatSessionRawDF.filter($"msg_type".contains("TransitionEvent_json"))
      .withColumn("seat_id", get_json_object(col("msg_data"), "$.seat_id"))
      .withColumn("program_type", get_json_object($"msg_data", "$.new_state.access_media.program_type"))
      .withColumn("channel_id", get_json_object($"msg_data", "$.new_state.access_media.channel_id"))
      .withColumn("channel_name", get_json_object($"msg_data", "$.new_state.access_media.channel_name"))
      .withColumn("channel_denied", get_json_object(col("msg_data"), "$.new_state.access_media.success_false_reason"))
      .withColumn("media_type",when(get_json_object($"msg_data","$.event.position_update.program_details.media_type") === null, get_json_object($"msg_data","$.event.interrupt_media.media_type")).otherwise(get_json_object($"msg_data","$.event.position_update.program_details.media_type")))
      .withColumn("seat_class", get_json_object(col("msg_data"), "$.cabin_class"))
      .select(
        $"flight_id",
        $"airline_id",
        $"seat_id",
        $"seat_class",
        $"media_type",
        $"program_type",
        $"channel_id",
        $"channel_name",
        $"channel_denied"
      )
      .join(flightsDF, Seq("airline_id", "flight_id"))
      .select(
        $"flight_id",
        $"airline_id",
        $"seat_id",
        $"seat_class",
        $"flight_takeoff_time",
        $"flight_type",
        $"flight_day_period",
        $"flight_duration",
        $"tail_number",
        $"flight_date_arrival",
        $"flight_airport_origin",
        $"flight_airport_dest",
        $"flight_number",
        $"flight_aircraft_type",
        $"media_type",
        $"channel_id",
        $"channel_name",
        $"channel_denied"
      )

    customDebugUtils.custom_debug_info("TRANSITION EVENTS FROM HIVE", transitionEventsWithFlightInfoDF, debugFlag)

    transitionEventsWithFlightInfoDF
  }
}
