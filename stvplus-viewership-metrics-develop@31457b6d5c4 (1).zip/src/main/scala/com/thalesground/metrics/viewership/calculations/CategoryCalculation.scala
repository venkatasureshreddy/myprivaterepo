package com.thalesground.metrics.viewership.calculations

import com.thales.avionics.ife.tvs.etl.ETLContext
import com.thalesground.metrics.viewership.utils.CustomDebugUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class CategoryCalculation(val etlContext: ETLContext, val debugFlag: Boolean) extends BaseCalculation {
  val logger = Logger.getLogger(getClass().getName())
  val customDebugUtils = new CustomDebugUtils()

  // UDFs
  val getCategoryUDF = udf(getCategory(_: String))

  // Phoenix output columns
  val columns = Seq[String](
    "flight_id",
    "airline_id",
    "seat_class",
    "flight_takeoff_time",
    "flight_type",
    "flight_day_period",
    "flight_duration",
    "tail_number",
    "flight_airport_origin",
    "flight_airport_dest",
    "flight_number",
    "media_type",
    "category_id",
    "content_type",
    "category_metric_id",
    "category_metric_value"
  )
  val outputColumns = columns.map(name => col(name))

  def compute(seatSessionDerivedDF: DataFrame) {
    val categoryDerivedDF = calculateCategoryDerived(seatSessionDerivedDF)

    if (!categoryDerivedDF.head(1).isEmpty) {
      val category_total_time_viewed_df = calculateCategoryTotalTimeViewed(categoryDerivedDF)
      etlContext.phoenix.save(category_total_time_viewed_df, "viewership_metrics_by_category")

      val category_unique_viewed_df = calculateCategoryUniqueViews(categoryDerivedDF)
      etlContext.phoenix.save(category_unique_viewed_df, "viewership_metrics_by_category")
    } else {
     logger.info("No Category Data Found. Skipping Calculations...")
    }
  }

  def calculateCategoryDerived(seatSessionDerivedDF: DataFrame):DataFrame = {
    import etlContext.sqlContext.implicits._

    val seatSessionDerivedTableCategoryDf = seatSessionDerivedDF
      .withColumn("category", explode(getCategoryUDF($"category")))
      .select(
        $"flight_id",
        $"airline_id",
        $"seat_id",
        $"seat_class",
        $"program_title",
        $"program_length",
        $"channel_id",
        $"channel_number",
        $"channel_name",
        $"media_type",
        $"category",
        $"time_viewed",
        $"flight_takeoff_time",
        $"flight_type",
        $"flight_day_period",
        $"flight_duration",
        $"tail_number",
        $"flight_airport_origin",
        $"flight_airport_dest",
        $"flight_number",
        $"content_type"
      )
    
    customDebugUtils.custom_debug_info("CATEGORY DERIVED DF ", seatSessionDerivedTableCategoryDf, debugFlag)

    seatSessionDerivedTableCategoryDf
  }

  def calculateCategoryTotalTimeViewed(categoryDerivedDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val category_total_time_viewed_df = categoryDerivedDF
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "category",
        "media_type",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number",
        "content_type"
      )
      .agg(
        expr("sum(time_viewed) as total_time_viewed")
      )
      .withColumn("category_metric_id", lit("category_total_time_viewed"))
      .withColumn("category_metric_value", coalesce(round($"total_time_viewed", 2), lit(0)))
      .withColumnRenamed("category", "category_id")
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info ("CATEGORY TOTAL TIME VIEWED DF", category_total_time_viewed_df, debugFlag)

    category_total_time_viewed_df
  }

  def calculateCategoryUniqueViews(categoryDerivedDF: DataFrame): DataFrame = {
    import etlContext.sqlContext.implicits._

    val category_unique_viewed_df  = categoryDerivedDF
      .groupBy(
        "flight_id",
        "airline_id",
        "seat_class",
        "flight_takeoff_time",
        "flight_type",
        "flight_day_period",
        "flight_duration",
        "tail_number",
        "flight_airport_origin",
        "flight_airport_dest",
        "flight_number","category",
        "media_type",
        "content_type"
      )
      .agg(
        expr("count(distinct seat_id) as distinct_seat_count")
      )
      .withColumn("category_metric_id", lit("category_nb_unique_views"))
      .withColumn("category_metric_value", coalesce($"distinct_seat_count", lit(0)))
      .withColumnRenamed("category", "category_id")
      .select(outputColumns: _*)
      .transform(etlContext.transformations.addModifiedByAndDateTimeFields())

    customDebugUtils.custom_debug_info("CATEGORY UNIQUE VIEWS DF", category_unique_viewed_df, debugFlag)

    category_unique_viewed_df
  }
}
