package com.thalesground.metrics.viewership

import com.thales.avionics.ife.tvs.etl.{ETLConfig, ETLContext, LogTableConfig, ThalesEmailUtils}
import com.thales.avionics.ife.tvs.etl.ThalesEmailUtils.EmailConfig
import com.thales.avionics.ife.tvs.etl.hivecompaction.{HiveCompactorLockOptions, HiveCompactorOptions}
import org.apache.hadoop.conf.Configuration
import org.apache.log4j.{Level, Logger}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.hadoop.fs.{FileContext, Path}
import com.google.common.base.Charsets
import com.google.common.io.ByteStreams
import java.io.{ByteArrayOutputStream, File}
import java.nio.file.Files

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext

object ViewershipStarter {

  val logger = Logger.getLogger(getClass().getName())

  class Options {
    var zookeeperUrl: Option[String] = None
    var phoenixDatabase: Option[String] = None
    var phoenixZkUrl: Option[String] = None
    var debugFlag: Option[String] = Some("false")
    var logDatabase: String = "logs_tbls"
    var channelDwellTime: Option[Integer] = Some(60)
    var avodDwellTime: Option[Integer] = Some(0)
    var PercOfCompletion: Option[Float] = None
    var numOfFlightsToRun: Option[Integer] = Some(300)
    var flightsPerBatch: Option[Integer] = Some(30)
    var smtpHost: Option[String] = None
    var smtpPort: Option[Int] = None
    var emailFromAddress: String = "spark_fpm_app@us.thalesgroup.com"
    val emailToAddresses = new scala.collection.mutable.ListBuffer[String]
    var smtpConnectTimeoutMillis: Long = 30000L
    var smtpTimeoutMillis: Long = 30000L
    var hiveCompactionOptionsJson: Option[String] = None
    var hiveCompactionOptionsJsonFilePath: Option[String] = None
    var hiveCompactionOptionsJsonHdfsFilePath: Option[String] = None
    var hiveCompactionLockBaseZooKeeperPath: Option[String] = None
    var skipHiveCompaction: Option[Boolean] = None

    def canEqual(other: Any): Boolean = other.isInstanceOf[Options]

    override def equals(other: Any): Boolean = other match {
      case that: Options =>
        (that canEqual this) &&
          phoenixZkUrl == that.phoenixZkUrl &&
          debugFlag == that.debugFlag &&
          channelDwellTime == that.channelDwellTime &&
          avodDwellTime == that.avodDwellTime &&
          PercOfCompletion == that.PercOfCompletion &&
          numOfFlightsToRun == that.numOfFlightsToRun &&
          smtpHost == that.smtpHost &&
          smtpPort == that.smtpPort &&
          emailFromAddress == that.emailFromAddress &&
          emailToAddresses == that.emailToAddresses &&
          smtpConnectTimeoutMillis == that.smtpConnectTimeoutMillis &&
          smtpTimeoutMillis == that.smtpTimeoutMillis
      case _ => false
    }

    override def hashCode(): Int = {
      val state = Seq(phoenixZkUrl, debugFlag, channelDwellTime, avodDwellTime, PercOfCompletion, numOfFlightsToRun, smtpHost, smtpPort, emailFromAddress, emailToAddresses, smtpConnectTimeoutMillis, smtpTimeoutMillis)
      state.map(_.hashCode()).foldLeft(0)((a, b) => 31 * a + b)
    }
  }

  def handleNullEmptyString(s: String): Option[String] = {
    if (s != null && s != "null" && !s.isEmpty) {
      Some(s)
    } else {
      None
    }
  }

  def handleNullEmptyStringInt(s: String): Option[Int] = {
    val resultStr = handleNullEmptyString(s)
    var ret: Option[Int] = None
    if (resultStr.isDefined) {
      ret = Some(resultStr.get.toInt)
    }
    ret
  }

  def handleNullEmptyStringLong(s: String): Option[Long] = {
    val resultStr = handleNullEmptyString(s)
    var ret: Option[Long] = None
    if (resultStr.isDefined) {
      ret = Some(resultStr.get.toLong)
    }
    ret
  }

  def handleNullEmptyStringLongDefault(s: String, defaultVal: Long): Long = {
    var ret = handleNullEmptyStringLong(s)
    if (ret.isEmpty) {
      ret = Some(defaultVal)
    }
    ret.get
  }

  def parseOptions(args: Array[String]): Options = {
    var i = 0
    val options = new Options()
    while (i < args.length) {
      args(i) match {
        case "-phoenixZkUrl"             => options.phoenixZkUrl = Some(args(i + 1))
        case "-phoenixDatabase" => options.phoenixDatabase = Some(args(i + 1).toString)
        case "-debugFlag"                => options.debugFlag = Some(args(i + 1))
        case "-channelDwellTime"         => options.channelDwellTime = Some(Integer.parseInt(args(i + 1)))
        case "-avodDwellTime"            => options.avodDwellTime = Some(Integer.parseInt(args(i + 1)))
        case "-pctOfCompletion"         => options.PercOfCompletion = Some(args(i + 1).toFloat)
        case "-numOfFlightsToRun"        => options.numOfFlightsToRun = Some(Integer.parseInt(args(i + 1)))
        case "-flightsPerBatch"          => options.flightsPerBatch = Some(Integer.parseInt(args(i + 1)))
        case "-zookeeperUrl" => options.zookeeperUrl = Some(args(i + 1).toString)
        case "-smtpHost"                 => options.smtpHost = handleNullEmptyString(args(i + 1))
        case "-smtpPort"                 => options.smtpPort = handleNullEmptyStringInt(args(i + 1))
        case "-emailFromAddress"         => options.emailFromAddress = args(i + 1)
        case "-emailToAddresses"         => args(i + 1).split(",").foreach(address => options.emailToAddresses += address)
        case "-smtpConnectTimeoutMillis" => handleNullEmptyStringLongDefault(args(i + 1), options.smtpConnectTimeoutMillis)
        case "-smtpTimeoutMillis"        => handleNullEmptyStringLongDefault(args(i + 1), options.smtpTimeoutMillis)
        case "-hiveCompactionOptionsJson" => options.hiveCompactionOptionsJson = Some(args(i + 1).toString)
        case "-hiveCompactionOptionsJsonFile" => options.hiveCompactionOptionsJsonFilePath = Some(args(i + 1).toString)
        case "-hiveCompactionOptionsJsonHdfsFilePath" => options.hiveCompactionOptionsJsonHdfsFilePath = Some(args(i + 1).toString)
        case "-hiveCompactionLockBaseZooKeeperPath" => options.hiveCompactionLockBaseZooKeeperPath = Some(args(i + 1).toString)
        case "-skipHiveCompaction" => options.skipHiveCompaction = Some(args(i + 1).toBoolean)
        case _ => {
          throw new IllegalArgumentException(s"Invalid argument ${args(i)}")
        }
      }
      i = i + 2
    }
    if (options.phoenixZkUrl.isEmpty) {
      throw new RuntimeException("Missing argument: phoenixZkUrl")
    }
    if (options.zookeeperUrl.isEmpty) {
      throw new RuntimeException("Missing argument: zookeeperUrl")
    }
    if (options.phoenixDatabase.isEmpty) {
      throw new RuntimeException("Missing argument: phoenixDatabase")
    }
    if (options.channelDwellTime.isEmpty) {
      throw new RuntimeException("Missing argument: channelDwellTime")
    }
    if (options.avodDwellTime.isEmpty) {
      throw new RuntimeException("Missing argument: avodDwellTime")
    }
    if (options.PercOfCompletion.isEmpty) {
      throw new RuntimeException("Missing argument: PercOfCompletion")
    }
    if (options.numOfFlightsToRun.isEmpty) {
      throw new RuntimeException("Missing argument: numOfFlightsToRun")
    }
    if (options.hiveCompactionLockBaseZooKeeperPath.isEmpty) {
      throw new RuntimeException("Missing argument: hiveCompactionLockBaseZooKeeperPath")
    }
    options
  }

  def getHiveCompactorOptions(options: Options): HiveCompactorOptions = {
    var ret: HiveCompactorOptions = null
    val conf = new Configuration()
    if(options.hiveCompactionOptionsJson.isDefined) {
      logger.info("Getting Hive compactor options from json")
      ret = HiveCompactorOptions.fromJson(options.hiveCompactionOptionsJson.get)
    } else if(options.hiveCompactionOptionsJsonHdfsFilePath.isDefined) {
      logger.info("Getting Hive compactor options from hdfs json file")
      val fileContext = FileContext.getFileContext(conf)
      val is = fileContext.open(new Path(options.hiveCompactionOptionsJsonHdfsFilePath.get))
      try {
        val byteOs = new ByteArrayOutputStream()
        ByteStreams.copy(is, byteOs)
        ret = HiveCompactorOptions.fromJson(new String(byteOs.toByteArray, Charsets.UTF_8))
      } finally {
        is.close()
      }
    } else if(options.hiveCompactionOptionsJsonFilePath.isDefined) {
      logger.info("Getting Hive compactor options from local json file")
      ret = HiveCompactorOptions.fromJson(new String(Files.readAllBytes(new File(options.hiveCompactionOptionsJsonFilePath.get).toPath), Charsets.UTF_8))
    } else {
      logger.info("Using default Hive compactor options")
      //use default settings
      ret = new HiveCompactorOptions()
    }
    ret.conf = conf
    ret.hiveDatabase = options.logDatabase
    ret.lockOptions = new HiveCompactorLockOptions()
    ret.lockOptions.lockZooKeeperUrl = options.zookeeperUrl.get
    ret.lockOptions.lockBaseZooKeeperPath = options.hiveCompactionLockBaseZooKeeperPath.get
    logger.info(s"Using HiveCompactorOptions: $ret")
    ret
  }

  def getEtlConfig(options: Options): ETLConfig = {
    ETLConfig(
      applicationName = "STV+ Viewership",
      phoenixDatabase = options.phoenixDatabase.get,
      zookeeperUrl = options.zookeeperUrl.get,
      phoenixZookeeperUrl = options.phoenixZkUrl.get,
      maxNumOfFlightsPerRun = options.numOfFlightsToRun.get,
      logDatabase = Some(options.logDatabase),
      logTables = Array(LogTableConfig(tableName = "stvplus_seatsession", eagerlyCache = false))
    )
  }

  def getFlightProductStatusFilters(): Array[String] = Array(
    "TAIL_ID IS NOT NULL",
    "LOG_DEPARTURE_TIME IS NOT NULL",
    "VIEWERSHIP_CALCULATED = false",
    "PRODUCT_ID = 'stvplus'",
    "LOGS_RECEIVED = true",
    "IS_VALID = true"
  )

  def main(args: Array[String]) {
    val options = parseOptions(args)

    logger.info(s"phoenixZkUrl:${options.phoenixZkUrl.get}")
    val sparkConf = new SparkConf().setAppName("Viewership_Metrics")
    sparkConf.set("spark_phoenix_jdbc_url", options.phoenixZkUrl.get)
    sparkConf.set("spark.driver.allowMultipleContexts", "true")
    sparkConf.set("spark.io.compression.codec", "lzf")
    // .setMaster("local")
    val sc = new SparkContext(sparkConf)
    sc.setLogLevel("INFO")
    val sqlContext = new HiveContext(sc)

    var emailConfig: Option[EmailConfig] = None
    if (options.smtpHost.isDefined) {
      emailConfig = Some(EmailConfig(options.smtpHost.get, options.smtpPort.get, options.emailFromAddress, options.emailToAddresses, options.smtpConnectTimeoutMillis, options.smtpTimeoutMillis))
    }

    Logger.getLogger("org").setLevel(Level.ERROR)
    Logger.getLogger("akka").setLevel(Level.ERROR)
    Logger.getLogger("hive.log").setLevel(Level.ERROR)
    Logger.getLogger("main").setLevel(Level.ERROR)
    Logger.getLogger("client").setLevel(Level.ERROR)

    var dbFlag: Boolean = options.debugFlag.get.toBoolean
    var url: String = options.phoenixZkUrl.get

    val hiveCompactorOptions = getHiveCompactorOptions(options)
    val etlContext = ETLContext.create(sqlContext, getEtlConfig(options), getFlightProductStatusFilters())

    try {
      val viewership = new Viewership(etlContext, hiveCompactorOptions, dbFlag)
      viewership.run(options.channelDwellTime.get, options.avodDwellTime.get, options.PercOfCompletion.get, options.flightsPerBatch.get)
    } catch {
      case e: Exception =>
        logger.error(" ERROR IN STVPLUS VIEWERSHIP APPLICATION " , e )
        val email_subject = "ViewerShip Application Exceptions"
        ThalesEmailUtils.sendEmail(etlContext.flightProductStatus.getFiltered(), e.getClass().getCanonicalName().toString(), e.toString(), email_subject, emailConfig)

        System.exit(1)
    } finally {
      sc.stop()
    }
  }
}
