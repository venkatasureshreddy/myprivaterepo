package com.thalesground.metrics.viewership

import org.scalatest.FunSuite

class ViewerShipStarterTestSuite extends FunSuite {

  test("Test main") {
    val actual = ViewershipStarter.parseOptions(Array(
      "-phoenixZkUrl", "PhoenixZkUrlValue",
      "-zookeeperUrl", "ZkUrlValue",
      "-phoenixDatabase", "PhoenixDatabae",
      "-debugFlag", "false",
      "-channelDwellTime", "0",
      "-avodDwellTime", "1",
      "-pctOfCompletion", "0.85",
      "-numOfFlightsToRun", "1",
      "-smtpHost", "AnSmtpServer",
      "-smtpPort", "25",
      "-emailFromAddress", "a_unit_test_from_address",
      "-emailToAddresses", "a_unit_test_to_address",
      "-smtpConnectTimeoutMillis", "30000",
      "-smtpTimeoutMillis", "30000",
      "-hiveCompactionLockBaseZooKeeperPath", "/path"
    ))
    val expected = new ViewershipStarter.Options()
    expected.phoenixZkUrl = Some("PhoenixZkUrlValue")
    expected.debugFlag = Some("false")
    expected.channelDwellTime = Some(0)
    expected.avodDwellTime = Some(1)
    expected.PercOfCompletion = Some(0.85f)
    expected.numOfFlightsToRun = Some(1)
    expected.smtpHost = Some("AnSmtpServer")
    expected.smtpPort = Some(25)
    expected.emailFromAddress = "a_unit_test_from_address"
    expected.emailToAddresses += "a_unit_test_to_address"
    expected.smtpConnectTimeoutMillis = 30000
    expected.smtpTimeoutMillis = 30000
    assert(expected == actual)
  }

}
