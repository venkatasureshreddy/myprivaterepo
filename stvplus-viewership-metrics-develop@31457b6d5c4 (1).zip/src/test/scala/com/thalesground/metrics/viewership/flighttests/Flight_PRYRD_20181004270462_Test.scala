package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

/**
  * STVPLUS-1515
  */
class Flight_PRYRD_20181004270462_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRD_20181004270462")

  test("Test PRYRD_20181004270462") {
    val results = testFlight("azul", "PRYRD", "DSU01043", "PRYRD_20181004270462", Util.getTime("2018-10-04 12:18:34.243"), Util.getTime("2018-10-04 13:02:30.915"))
    assert(results.contains("viewership_metrics_by_channel"))

    val df = results("viewership_metrics_by_channel")
    assert(!df.head(1).isEmpty)
    assert(df.where("channel_metric_id = 'channel_total_dwell_time' and channel_name = 'GNEWS'").head(1).isEmpty)
    assert(df.where("channel_metric_id = 'channel_unique_views' and channel_name = 'GNEWS'").head(1).isEmpty)
    assert(df.where("channel_metric_id = 'channel_average_time_viewed' and channel_name = 'GNEWS'").head(1).isEmpty)
  }
}
