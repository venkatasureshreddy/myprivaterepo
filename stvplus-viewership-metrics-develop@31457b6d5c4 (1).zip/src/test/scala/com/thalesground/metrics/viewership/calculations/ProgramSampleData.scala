package com.thalesground.metrics.viewership.calculations

import com.thalesground.metrics.viewership.common.{CommonSchema, Util}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row}

class ProgramSampleData(hc: HiveContext) {
  def loadSeatSession(): DataFrame = {
    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "TV_CHANNEL", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), 960.0, 0.5,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380",""),
      Row("PRYRA_20170101130000", "AZUL", "26D", "Economy", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "TV_CHANNEL", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), 960.0, 0.9,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380",""),
      Row("PRYRA_20170101130000", "AZUL", "26E", "Economy", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "TV_CHANNEL", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), 80.0, 0.4,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380",""),

      Row("PRYRA_20170101130000", "AZUL", "26D", "coach", "TEST OUT", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "TV_CHANNEL", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), null, 0.9,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380",""),
      Row("PRYRA_20170101130000", "AZUL", "26E", "coach", "Training Day", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "TV_CHANNEL", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), null, 0.4,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","")

    )

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForSeatSession())
    )
    expectedDF.show(true)
    expectedDF.repartition(1)
  }

  def getProgramAverageCompletionTable(): DataFrame = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("seat_class", StringType, false),
      StructField("flight_takeoff_time", TimestampType, false),
      StructField("flight_type", StringType, false),
      StructField("flight_day_period", StringType, false),
      StructField("flight_duration", IntegerType, false),
      StructField("tail_number", StringType, false),
      StructField("flight_airport_origin", StringType, false),
      StructField("flight_airport_dest", StringType, false),
      StructField("flight_number", StringType, false),
      StructField("channel_id", StringType, false),
      StructField("channel_name", StringType, false),
      StructField("program_title", StringType, false),
      StructField("category", StringType, false),
      StructField("program_length", IntegerType, false),
      StructField("program_viewed_to_completion", IntegerType, false),
      StructField("program_count", IntegerType, false)
    )

    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING",
        7, "N123N", "LAX", "JFK", "AZU123", "5941", "CNN", "Snake on Airplane", "Comedy", 3600,2,3),
      Row("PRYRA_20170101130000", "AZUL", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING",
        7, "N123N", "LAX", "JFK", "AZU123", "5941", "CNN", "Snake on Airplane", "Comedy", 3600, 2,3)
    )
    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(expectedSchema)
    )
    expectedDF.show(true)
    expectedDF.coalesce(1)
  }
}
