package com.thalesground.metrics.viewership.utils

import com.thalesground.metrics.viewership.common.{CommonSchema, Util}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row}

class CommonSampleData (hc: HiveContext) {

  def loadSeatSession(): DataFrame = {

    val expectedData = Seq(
      Row("PRYRD_20090101000409", "STV_AZUL_PRYRD_SBMOSBKP_20090101000409Z_SEATSESSION_ISD29E_PRYRD_20090101000409.csv",
        "2009-01-01T00:04:29.000Z", "STV", "seat_activity", 9999, 9999, 6, 1.1, "InstantaneousEvent_json",
        "{\"time_stamp\": \"2018-03-09T18:32:12Z\", \"seat_id\": \"29E\", \"event\": {\"position_update\": {\"program_details\": {\"category\": [\"CC\", \"Series\", \"Kids\", \"Animation\", \"Kids & Family\", \"Action/Adventure\"], \"program_screen\": \"TV Video Activity\", \"rating_program\": \"TV-PG\", \"close_captioning\": false, \"success\": true, \"program_type\": \"Live TV\", \"display_language\": \"pt\", \"volume_percent\": 46, \"studio_source\": \"296 CNe\", \"program_title_ext\": \"2018-03-09T18:30:00Z\", \"paid_content\": false, \"channel_id\": \"5973\", \"program_length\": 900.0, \"channel_name\": \"CNe\", \"media_type\": \"TV_CHANNEL\", \"program_title\": \"WTA All Access\", \"screen_brightness_percent\": 50, \"channel_number\": 296, \"audio_language\": \"pt\"}, \"program_title_ext\": \"2018-03-09T18:30:00Z\", \"channel_id\": \"5973\", \"update_type\": \"PLAYING\", \"position\": 0.0, \"program_title\": \"WTA All Access\"}, \"event_type\": \"POSITION_UPDATE\"}, \"cabin_class\": \"COACH\"}",
        "AZUL", "2009", "1", "1"),
      Row("PRYRD_20090101000409", "STV_AZUL_PRYRD_SBMOSBKP_20090101000409Z_SEATSESSION_ISD29E_PRYRD_20090101000409.csv",
        "2009-01-01T00:04:29.000Z", "STV", "seat_activity", 9999, 9999, 6, 1.1, "InstantaneousEvent_json",
        "{\"time_stamp\": \"2018-03-09T18:32:12Z\", \"seat_id\": \"29E\", \"event\": {\"position_update\": {\"program_details\": {\"category\": [\"CC\", \"Series\", \"Kids\", \"Animation\", \"Kids & Family\", \"Action/Adventure\"], \"program_screen\": \"TV Video Activity\", \"rating_program\": \"TV-PG\", \"close_captioning\": false, \"success\": true, \"program_type\": \"Live TV\", \"display_language\": \"pt\", \"volume_percent\": 46, \"studio_source\": \"296 CNe\", \"program_title_ext\": \"2018-03-09T18:30:00Z\", \"paid_content\": false, \"channel_id\": \"5973\", \"program_length\": 900.0, \"channel_name\": \"CNe\", \"media_type\": \"TV_CHANNEL\", \"program_title\": \"WTA All Access\", \"screen_brightness_percent\": 50, \"channel_number\": 296, \"audio_language\": \"pt\"}, \"program_title_ext\": \"2018-03-09T18:30:00Z\", \"channel_id\": \"5973\", \"update_type\": \"PROGRAM_START\", \"position\": 1810, \"program_title\": \"WTA All Access\"}, \"event_type\": \"POSITION_UPDATE\"}, \"cabin_class\": \"COACH\"}",
        "AZUL", "2009", "1", "1"),
      Row("PRYRD_20090101000409", "STV_AZUL_PRYRD_SBMOSBKP_20090101000409Z_SEATSESSION_ISD29E_PRYRD_20090101000409.csv",
        "2009-01-01T00:04:44.000Z", "STV", "seat_activity", 9999, 9999, 6, 1.1, "InstantaneousEvent_json",
        "{\"time_stamp\": \"2018-03-09T18:45:12Z\", \"seat_id\": \"29E\", \"event\": {\"position_update\": {\"program_details\": {\"category\": [\"CC\", \"Series\", \"Kids\", \"Animation\", \"Kids & Family\", \"Action/Adventure\"], \"program_screen\": \"TV Video Activity\", \"rating_program\": \"TV-PG\", \"close_captioning\": false, \"success\": true, \"program_type\": \"Live TV\", \"display_language\": \"pt\", \"volume_percent\": 46, \"studio_source\": \"296 CNe\", \"program_title_ext\": \"2018-03-09T18:30:00Z\", \"paid_content\": false, \"channel_id\": \"5973\", \"program_length\": 900.0, \"channel_name\": \"CNe\", \"media_type\": \"TV_CHANNEL\", \"program_title\": \"WWF\", \"screen_brightness_percent\": 50, \"channel_number\": 296, \"audio_language\": \"pt\"}, \"program_title_ext\": \"2018-03-09T18:30:00Z\", \"channel_id\": \"5973\", \"update_type\": \"PROGRAM_END\", \"position\": 3000, \"program_title\": \"WTA All Access\"}, \"event_type\": \"POSITION_UPDATE\"}, \"cabin_class\": \"COACH\"}",
        "AZUL", "2009", "1", "1"),
      Row("PRYRD_20090101000409", "STV_AZUL_PRYRD_SBMOSBKP_20090101000409Z_SEATSESSION_ISD29E_PRYRD_20090101000409.csv",
        "2009-01-01T00:04:29.000Z", "STV", "seat_activity", 9999, 9999, 6, 1.1, "InstantaneousEvent_json",
        "{\"time_stamp\": \"2018-03-09T18:50:12Z\", \"seat_id\": \"29E\", \"event\": {\"position_update\": {\"program_details\": {\"category\": [\"CC\", \"Series\", \"Kids\", \"Animation\", \"Kids & Family\", \"Action/Adventure\"], \"program_screen\": \"TV Video Activity\", \"rating_program\": \"TV-PG\", \"close_captioning\": false, \"success\": true, \"program_type\": \"Live TV\", \"display_language\": \"pt\", \"volume_percent\": 46, \"studio_source\": \"296 CNe\", \"program_title_ext\": \"2018-03-09T18:30:00Z\", \"paid_content\": false, \"channel_id\": \"5973\", \"program_length\": 900.0, \"channel_name\": \"CNe\", \"media_type\": \"TV_CHANNEL\", \"program_title\": \"WWF\", \"screen_brightness_percent\": 50, \"channel_number\": 296, \"audio_language\": \"pt\"}, \"program_title_ext\": \"2018-03-09T18:30:00Z\", \"channel_id\": \"5973\", \"update_type\": \"PROGRAM_END\", \"position\": 0.0, \"program_title\": \"WTA\"}, \"event_type\": \"POSITION_UPDATE\"}, \"cabin_class\": \"COACH\"}",
        "AZUL", "2009", "1", "1"),
      Row("PRYRD_20090101000409", "STV_AZUL_PRYRD_SBMOSBKP_20090101000409Z_SEATSESSION_ISD29E_PRYRD_20090101000409.csv",
        "2009-01-01T00:04:29.000Z", "STV", "seat_activity", 9999, 9999, 6, 1.1, "TransitionEvent_json",
        "{\"new_state\":{\"access_media\":{\"media_type\":\"TV_CHANNEL\",\"success\":true,\"paid_content\":false,\"channel_id\":\"6060\",\"channel_number\":6060,\"channel_name\":\"SPORTSNSTUFF\",\"program_type\":\"live\",\"program_title\":\"WTA All Access\",\"program_length\":3600,\"category\":[\"Sports\"],\"rating_program\":\"unknown\",\"audio_language\":\"English\",\"display_language\":\"English\",\"volume_percent\":75,\"screen_brightness_percent\":50,\"close_captioning\":true,\"program_title_ext\":\"2009-01-01T01:00:00.000Z\"},\"event_type\":\"ACCESS_MEDIA\"},\"old_state\":{\"access_media\":{\"media_type\":\"HOME\",\"success\":true,\"paid_content\":false,\"program_type\":\"none\"},\"event_type\":\"ACCESS_MEDIA\"},\"time_stamp\":\"2009-01-01T01:38:09.000Z\",\"duration_in_seconds\":0,\"seat_id\":\"30E\",\"cabin_class\":\"Economy\"}",
        "AZUL", "2009", "1", "1"),
      Row("PRYRD_20090101000409", "STV_AZUL_PRYRD_SBMOSBKP_20090101000409Z_SEATSESSION_ISD29E_PRYRD_20090101000409.csv",
        "2009-01-01T00:04:29.000Z", "STV", "seat_activity", 9999, 9999, 6, 1.1, "TransitionEvent_json",
        "{\"old_state\":{\"access_media\":{\"media_type\":\"BOOT\",\"success\":true,\"paid_content\":false,\"program_type\":\"startup\"},\"event_type\":\"ACCESS_MEDIA\"},\"new_state\":{\"access_media\":{\"media_type\":\"HOME\",\"success\":true,\"paid_content\":false,\"program_type\":\"landing page\"},\"event_type\":\"ACCESS_MEDIA\"},\"time_stamp\":\"2009-01-01T00:04:29.000Z\",\"duration_in_seconds\":0,\"seat_id\":\"29E\",\"cabin_class\":\"Economy\"}",
        "AZUL", "2009", "1", "1")
    )

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForSeatSessionHive())
    )

    expectedDF.show(true)
    expectedDF
  }

  def loadSeatSessionAccentInput(): DataFrame = {

    val expectedData = Seq(
      Row("PRYRD_20090101000409", "STV_AZUL_PRYRD_SBMOSBKP_20090101000409Z_SEATSESSION_ISD29E_PRYRD_20090101000409.csv",
        "2009-01-01T00:04:29.000Z", "STV", "seat_activity", 9999, 9999, 6, 1.1, "InstantaneousEvent_json",
        "{\"event\":{\"position_update\":{\"update_type\":\"PLAYBACK_START\",\"program_title\":\"Ambiancé\",\"position\":1869,\"program_title_ext\":\"2009-01-01T01:00:00.000Z\"},\"event_type\":\"POSITION_UPDATE\"},\"time_stamp\":\"2009-01-01T01:31:09.000Z\",\"seat_id\":\"29E\",\"cabin_class\":\"Economy\"}",
        "AZUL", "2009", "1", "1")
    )

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForSeatSessionHive())
    )

    expectedDF.show(true)
    expectedDF
  }

  def loadSvcStates(): DataFrame = {

    val svcStatesRows = Seq(
      Row("PRYRD_20090101000409", "STV_AZUL_PRYRD_SBMOSBKP_20090101000409Z_SEATSESSION_ISD29E_PRYRD_20090101000409.csv",
        "2009-01-01T00:04:29.000Z", "STV+VM", "service_announcer_logger", 9999, 9999, 6, 1.1, "StartOfFlight_json",
        "{\"start_of_flight\":{\"tail_number\":\"PRYRE\",\"flight_number\":\"5941\",\"origination\":{\"icao\":\"LAX\",\"latitude\":0.0,\"longitude\":0.0},\"destination\":{\"icao\":\"JFK\",\"latitude\":0.0,\"longitude\":0.0},\"date_time\":\"2009-01-01T01:01:48.228Z\"}}",
        "AZUL", "2009", "1", "1"),
      Row("PRYRD_20090101000409", "STV_AZUL_PRYRD_SBMOSBKP_20090101000409Z_SEATSESSION_ISD29E_PRYRD_20090101000409.csv",
        "2009-01-01T00:04:29.000Z", "STV+VM", "service_announcer_logger", 9999, 9999, 6, 1.1, "EndOfFlight_json",
        "{\"end_of_flight\":{\"tail_number\":\"PRYRE\",\"flight_number\":\"5941\",\"origination\":{\"icao\":\"LAX\",\"latitude\":0.0,\"longitude\":0.0},\"destination\":{\"icao\":\"JFK\",\"latitude\":0.0,\"longitude\":0.0},\"date_time\":\"2009-01-01T01:15:48.228Z\"}}",
        "AZUL", "2009", "1", "1")
    )

    //the schema for svc states is same as seat session
    val svcStatesDf = hc.createDataFrame(
      hc.sparkContext.parallelize(svcStatesRows),
      StructType(CommonSchema.getSchemaForSeatSessionHive())
    )

    svcStatesDf.show(true)
    svcStatesDf
  }


  def loadFlightData(): DataFrame = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("flight_takeoff_time", TimestampType, false),
      StructField("flight_type", StringType, false),
      StructField("flight_day_period", StringType, false),
      StructField("flight_duration", IntegerType, false),
      StructField("tail_number", StringType, false),
      StructField("flight_date_arrival", TimestampType, false),
      StructField("flight_airport_origin", StringType, false),
      StructField("flight_airport_dest", StringType, false),
      StructField("flight_number", IntegerType, false),
      StructField("flight_aircraft_type", StringType, false)
    )

    val expectedData = Seq(Row("PRYRD_20090101000409", "Economy", Util.getTime("2009-01-01 01:00:00.0"), "DOMESTIC", "MORNING", 7, "N123N",
      Util.getTime("2009-01-01 01:00:00.0"), "LAX", "JFK", 5941, "AZU123"))
    val expectedDF = hc.createDataFrame(hc.sparkContext.parallelize(expectedData),
      StructType(expectedSchema)
    )
    expectedDF.show(true)
    expectedDF.coalesce(1)
  }

}
