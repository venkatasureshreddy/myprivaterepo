package com.thalesground.metrics.viewership

import com.thales.avionics.ife.tvs.etl.ETLTestBase
import org.apache.spark.sql.DataFrame
import org.mockito.Matchers._
import org.mockito.Mockito._
import org.mockito.invocation.InvocationOnMock
import org.mockito.stubbing.Answer

import scala.collection.mutable.HashMap

/**
 * Make sure when a subclass overrides beforeAll() or afterAll() that it calls super.before/afterAll() first!
 * Otherwise SparkContext will not get cleaned up and there will be lots of weird errors
 */
abstract class ViewershipTestSuiteBase extends ETLTestBase {

  override def getFlightProductStatusFilters(): Array[String] = ViewershipStarter.getFlightProductStatusFilters()

  def shouldMockPhoenixPhoenixSaveUnion(): Boolean = true

  /**
    * Mocks out phoenix's save method, and returns a map, which will be populated as a result of DataFrames being saved to phoenix tables.
    *
    * The key of each entry in the map is a phoenix table name, and the value is a DataFrame of all saves to that table unioned together.
    */
  def mockPhoenixPersistence() : HashMap[String, DataFrame] = {
    val results = new HashMap[String, DataFrame]

    when(phoenix.save(any(), any())).thenAnswer(new Answer[Unit] {
      override def answer(invocation: InvocationOnMock): Unit = {
        val incoming = invocation.getArguments.head.asInstanceOf[DataFrame]
        incoming.cache()
        val table = invocation.getArguments.last.asInstanceOf[String]
        println(s"saving to ${table}")

        results.get(table) match {
          case Some(existing) => {
            if(shouldMockPhoenixPhoenixSaveUnion()) {
              results.put(table, existing.unionAll(incoming))
            } else {
              results.put(table, incoming)
            }
          }
          case None => results.put(table, incoming)
        }
        incoming.unpersist()
      }
    })

    results
  }

  def assertDataFramesEqual(df1: DataFrame, df2: DataFrame): Unit = {
    //DataFrameSuiteBase.assertDataFrameApproximateEquals doesn't work because of scalatest version incompatibility or something
    val df1Rows = df1.collect()
    val df2Rows = df2.collect()
    assert(df1Rows.length == df2Rows.length)
    for(i <- df1Rows.indices) {
      val df1Row = df1Rows(i)
      val df2Row = df2Rows(i)
      assert(df1Row == df2Row, "Row " + i)
    }
  }

}
