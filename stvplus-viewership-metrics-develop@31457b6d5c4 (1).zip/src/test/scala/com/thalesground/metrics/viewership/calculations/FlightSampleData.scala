package com.thalesground.metrics.viewership.calculations

import com.thalesground.metrics.viewership.common.{CommonSchema, Util}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row}

class FlightSampleData(hc: HiveContext) {

  def loadFlight(): DataFrame = {

    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("seat_class", StringType, false),
      StructField("flight_total_nb_passengers", IntegerType, false)
    )

    val expectedData = Seq(
      Row("PRYRA_20170101130001", "Business", 20),
      Row("PRYRA_20170101130000", "Business", 20),
      Row("PRYRA_20170101130000", "Economy", 100)
    )

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(expectedSchema)
    )

    expectedDF.repartition(1)
  }


  def loadSeatSession(): DataFrame = {

    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "1C", "Business", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45"), 960.0, 0.9,
        Util.getTime("2017-07-11 07:50:45"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25"), "LAX", "JFK", "AZU123", "A380","TV Series"),
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45"), 960.0, 0.92,
        Util.getTime("2017-07-11 07:50:45"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25"), "LAX", "JFK", "AZU123", "A380","TV Series"),
      Row("PRYRA_20170101130001", "AZUL", "1A", "Business", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45"), 960.0, 0.91,
        Util.getTime("2017-07-11 07:50:45"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25"), "LAX", "JFK", "AZU123", "A380","TV Series"))

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForSeatSession)
    )


    expectedDF.repartition(1)
  }
  def loadInstantaniousPlaying(): DataFrame = {

    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "1C", "Copper Chef", 1200, "PLAYING","10283657" , "TV_CHANNEL", "1499774445000"),
      Row("PRYRA_20170101130000", "AZUL", "2C", "Paradise Islands", 3600, "PLAYING","4099672" , "TV_CHANNEL", "1499774445000"),
      Row("PRYRA_20170101130000", "AZUL", "3C", "Paradise Islands", 3600, "PLAYING","4099672" , "TV_CHANNEL", "1499774445000"),
      Row("PRYRA_20170101130000", "AZUL", "3C", "ABC", 3600, "PLAYING","4099679" , "TV_CHANNEL", "1499774445200"),
      Row("PRYRA_20170101130000", "AZUL", "1C", "Sleeping Beauty", 1200, "PLAYING","1" , "AVOD", "1499776845000"),
      Row("PRYRA_20170101130000", "AZUL", "2C", "Baahubali", 3600, "PLAYING","4099673" , "AVOD", "1499774146000"),
      Row("PRYRA_20170101130000", "AZUL", "3C", "ESPN", 3600, "PLAYING","4099674" , "TV_CHANNEL", "1499777445000"),
      Row("PRYRA_20180101130001", "AZUL", "3C", "Copper Chef", 1200, "PLAYING","10283657" , "TV_CHANNEL", "1514815845000"),
      Row("PRYRA_20180101130001", "AZUL", "3C", "Sleeping Beauty", 1200, "PLAYING","1" , "AVOD", "1514818245000")
    )

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForInstantaniousPlaying())
    )


    expectedDF.repartition(1)
  }
  
  

    
  def loadInstantaniousWithStartAndEndTimes(): DataFrame = {

    val expectedData = Seq(
     Row("PRYRA_20170101130000", "AZUL", "1C",  "Copper Chef",       1200,"PLAYING",  "10283657" , "1499774445000" , "","0", "1499774445000"),
      Row("PRYRA_20170101130000", "AZUL", "2C", "Paradise Islands",  3600, "PLAYING", "4099672" , "1499774445000","","0", "1499774445000"),
      Row("PRYRA_20170101130000", "AZUL", "3C", "Paradise Islands",  3600, "PLAYING",  "4099672" , "1499774445000","", "0", "1499774445000"),
      Row("PRYRA_20170101130000", "AZUL", "3C", "ABC",               3600,"PLAYING", "4099679" ,"1499776845000", "","0", "1499774445200"),
      Row("PRYRA_20170101130000", "AZUL", "1C", "Sleeping Beauty",   1200, "PLAYING", "1" ,"1499776845000", "","0", "1499776845000"),
      Row("PRYRA_20170101130000", "AZUL", "2C", "Baahubali",         3600,  "PLAYING", "4099673" , "1499776845000","", "0", "1499774146000"),
      Row("PRYRA_20170101130000", "AZUL", "3C", "ESPN",              3600,  "PLAYING","4099674" , "1499776845000","","0", "1499777445000"),
      Row("PRYRA_20180101130001", "AZUL", "3C", "Copper Chef",       1200, "PLAYING", "10283657" , "1499776845000","","0", "1514815845000"),
      Row("PRYRA_20180101130001", "AZUL", "3C", "Sleeping Beauty",   1200, "PLAYING","1" ,"1499776845000", "","0", "1514818245000") )

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForInstantaneousWithStartAndEndTimes())
    )


    expectedDF.repartition(1)
  }  
    
  def loadFlights(): DataFrame = {

    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "2017-07-11 07:50:45","DOMESTIC", "MORNING","3600","PRYRA", "2017-07-11 08:50:45", "LAX","JFK" , "AZUL123", ""),
      Row("PRYRA_20180101130001", "AZUL", "2018-01-01 08:50:45","DOMESTIC", "MORNING","3600","PRYRA", "2018-01-01 09:50:45", "SNA","SFO" , "AZUL456", ""))

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForFlights())
    )


    expectedDF.repartition(1)
  }
}
