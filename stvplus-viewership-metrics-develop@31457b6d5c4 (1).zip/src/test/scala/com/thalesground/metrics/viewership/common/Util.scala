package com.thalesground.metrics.viewership.common
import java.sql.Timestamp
import java.text.SimpleDateFormat

import org.apache.spark.sql.hive.HiveContext

object Util extends Serializable  {


  def initialize(hc:HiveContext, debugFlag:Boolean) {
    //Register UDF
    hc.udf.register("timestamps", timestamps _)
    hc.udf.register("getContentType",getContentType(_:String))
  }
  def getTimestamp: ((String,String) => Long) = {
    (format:String, dateString:String) => {
      val sdf = new SimpleDateFormat(format)
      sdf.parse(dateString.replace("T", " ").replace("Z", "")).getTime
    }
  }

  def getTime(date: String): Timestamp = {
    val formatUTC = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    new Timestamp(formatUTC.parse(date).getTime)
  }

  def timestamps (originTime: Long, destinationTime: Long): Array[Long] = {
    val diff = destinationTime - originTime;
    var tm = (originTime) + 300
    var arr: Array[Long] = Array(tm)
    while (tm <= destinationTime) {
      tm = tm + 300;
      arr = arr :+ (tm)
    }
    return arr;
  }

  def getContentType(programTitleExt: String): String ={
    if(programTitleExt.trim.length==0) {
      "Movies"
    } else{
      "Tv series"
    }
  }
}
