package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

/**
  * Test for STVPLUS-1589/STVPLUS-1481 related to "Other" category
  */
class Flight_AZSW01_2018Nov15170311_AVBF_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/AZSW01_2018Nov15170311_AVBF")

  test("Test PRYRA_2018Oct04104245_ICCP") {
    val results = testFlight("azul", "AZSW01", "CQS0AVBF", "AZSW01_2018Nov15170311_AVBF", Util.getTime("2018-11-15 19:02:57.913"), Util.getTime("2018-11-15 22:08:13.427"))

    assert(results.contains("viewership_metrics_by_flight"))
    assert(results.contains("viewership_metrics_by_vod_content"))
    assert(results.contains("viewership_metrics_by_category"))

    val df = results("viewership_metrics_by_vod_content")
    assert(!df.head(1).isEmpty)
    assertNumbersClose(3961L, df.where("vod_metric_id = 'vod_total_time_viewed' and vod_id = 'Episode 4'").head().getAs[Long]("vod_metric_value"))
  }
}
