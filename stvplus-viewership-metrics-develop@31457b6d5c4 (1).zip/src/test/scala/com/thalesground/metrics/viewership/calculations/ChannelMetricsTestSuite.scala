package com.thalesground.metrics.viewership.calculations

import java.sql.{Timestamp}

import com.thalesground.metrics.viewership.ViewershipTestSuiteBase
import com.thalesground.metrics.viewership.common.Util
import com.thalesground.metrics.viewership.utils.DataComposer


class ChannelMetricsTestSuite extends ViewershipTestSuiteBase  {
  case class ChannelMetrics(flight_id: String, airline_id: String, seat_class: String, flight_takeoff_time: Timestamp, flight_type: String,
                            flight_day_period: String, flight_duration: Int, tail_number: String, flight_airport_origin: String, flight_airport_dest: String, flight_number: String, channel_id: String,
                            channel_name: String, channel_metric_id: String, channel_metric_value: Float)

  override def beforeAll() {
    super.beforeAll()
  }

  override def afterAll() {
    super.afterAll()
  }

  test("CHANNEL TOTAL DWELL TIME") {
    val channelMock = createChannelMock()
    val sampleTestData = new ChannelSampleData(sqlContext)
    val instantaneousData = sampleTestData.loadInstantaneousEvents
    val output = channelMock.calculateChannelTotalDwellTime(instantaneousData)
  }

  test("CHANNEL AVERAGE TIME VIEWED") {
    val channelMock = createChannelMock()
    val sampleTestData = new ChannelSampleData(sqlContext)
    val instantaneousDataDF = sampleTestData.loadInstantaneousEvents
    val channelTotalDwellTimeDF = channelMock.calculateChannelTotalDwellTime(instantaneousDataDF)
    val output = channelMock.calculateAvgSecondsViewedPerChannel(instantaneousDataDF, channelTotalDwellTimeDF)
  }

  test("CHANNEL UNIQUE VIEWS") {
    val channelMock = createChannelMock()
    val sampleTestData = new ChannelSampleData(sqlContext)
    val instantaneousDataDF = sampleTestData.loadInstantaneousEvents
    val output = channelMock.calculateNbUniqueViewsPerChannel(instantaneousDataDF, 60)
  }

  test("CHANNEL AVERAGE COMPLETION RATE") {
    val channelMock = createChannelMock()
    val sampleTestData = new ChannelSampleData(sqlContext)
    val instantaneousDataDF = sampleTestData.loadInstantaneousEvents
    val output = channelMock.calculateChannelAvgCompletionRate(instantaneousDataDF, 0.80f)
  }

  test("NUMBER OF DENIED CHANNELS") {
    var list = List(ChannelMetrics("PRYRA_20170101130000", "AZUL", "Economy", Util.getTime("2017-07-11 07:50:45.0"),
      "DOMESTIC", "MORNING", 3600, "N123N", "LAX", "JFK", "AZUL123",  "6060", "SPORTSNSTUFF", "channel_denied_count", 0.0f))

    val channelMock = createChannelMock()
    val sampleTestData = new ChannelSampleData(sqlContext)
    val instantaneousDataDF = sampleTestData.loadInstantaneousEvents
    val transitionData = sampleTestData.loadTransitionEvents
    val output = channelMock.calculateNbDeniedChannels(instantaneousDataDF, transitionData)
  }

  def createChannelMock(): ChannelCalculation = {
    return new ChannelCalculation(etlContext, false)
  }

  def validateMetrics(expectedList: List[ChannelMetrics], actualList: List[ChannelMetrics]) = {

    (expectedList, actualList).zipped foreach { (expected, actual) =>
      assert(expected.flight_id == actual.flight_id)
      assert(expected.airline_id == actual.airline_id)
      assert(expected.seat_class == actual.seat_class)
      assert(expected.flight_takeoff_time == actual.flight_takeoff_time)
      assert(expected.flight_type == actual.flight_type)
      assert(expected.flight_day_period == actual.flight_day_period)
      assert(expected.flight_duration == actual.flight_duration)
      assert(expected.tail_number == actual.tail_number)
      assert(expected.flight_airport_origin == actual.flight_airport_origin)
      assert(expected.flight_airport_dest == actual.flight_airport_dest)
      assert(expected.flight_number == actual.flight_number)
      assert(expected.channel_id == actual.channel_id)
      assert(expected.channel_name == actual.channel_name)
      assert(expected.channel_metric_id == actual.channel_metric_id)
      assert(expected.channel_metric_value == actual.channel_metric_value)
    }
  }
}

