package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util
import org.apache.spark.sql.functions.{count, expr}

/**
  * Test for STVPLUS-1589/STVPLUS-1481 related to "Other" category
  */
class Flight_PRYRD_20190215141537_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRD_20190215141537")

  test("Test PRYRA_2018Oct04104245_ICCP") {
    import sqlContext.implicits._

    val results = testFlight("azul", "PRYRD", "DSU01234", "PRYRD_20190215141537", Util.getTime("2019-02-15 14:15:43.863"), Util.getTime("2019-02-15 16:29:28.256"))

    assert(results.contains("viewership_metrics_by_roadblock"))

    val df = results("viewership_metrics_by_roadblock")
    assert(!df.head(1).isEmpty)

    // An AD ID should not appear more than once for each roadblock_metric_id
    assert(df.groupBy("flight_id","ad_id", "roadblock_metric_id").agg(expr("count(roadblock_metric_value) as ad_count")).filter($"ad_count" > 1).head(1).isEmpty)

    assert(!df.where("roadblock_title = 'Roadblock 2'").head(1).isEmpty)
    assert(!df.where("roadblock_title = 'Roadblock 5'").head(1).isEmpty)
    assert(!df.where("roadblock_title = 'Roadblock 6'").head(1).isEmpty)
    assert(!df.where("roadblock_title = 'Roadblock 7'").head(1).isEmpty)
    assert(!df.where("roadblock_title = 'Roadblock 9'").head(1).isEmpty)
    assert(!df.where("roadblock_title = 'Roadblock 10'").head(1).isEmpty)

    assertNumbersClose(255.0, df.where("roadblock_title = 'Roadblock 2' and roadblock_metric_id = 'roadblock_total__time_viewed'").head().getAs[Long]("roadblock_metric_value"))
    assertNumbersClose(391.0, df.where("roadblock_title = 'Roadblock 5' and roadblock_metric_id = 'roadblock_total__time_viewed'").head().getAs[Long]("roadblock_metric_value"))
    assertNumbersClose(137.0, df.where("roadblock_title = 'Roadblock 6' and roadblock_metric_id = 'roadblock_total__time_viewed'").head().getAs[Long]("roadblock_metric_value"))
    assertNumbersClose(180.0, df.where("roadblock_title = 'Roadblock 7' and roadblock_metric_id = 'roadblock_total__time_viewed'").head().getAs[Long]("roadblock_metric_value"))
    assertNumbersClose(64.0, df.where("roadblock_title = 'Roadblock 9' and roadblock_metric_id = 'roadblock_total__time_viewed'").head().getAs[Long]("roadblock_metric_value"))
    assertNumbersClose(99.0, df.where("roadblock_title = 'Roadblock 10' and roadblock_metric_id = 'roadblock_total__time_viewed'").head().getAs[Long]("roadblock_metric_value"))

    // Single passenger flights should not have unique views greater than one
    assert(df.where("roadblock_metric_id = 'roadblock_nb_unique_views' and roadblock_metric_value > 1").head(1).isEmpty)
  }
}
