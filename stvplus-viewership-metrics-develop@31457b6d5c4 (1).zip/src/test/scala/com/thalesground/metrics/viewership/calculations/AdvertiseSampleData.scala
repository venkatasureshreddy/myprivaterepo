package com.thalesground.metrics.viewership.calculations

import com.thalesground.metrics.viewership.common.{CommonSchema, Util}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row}

class AdvertiseSampleData(hc: HiveContext) {
  def loadSeatSession(): DataFrame = {
    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "ROADBLOCK", "CAMPAIGN_2019", null, null, "ROADBLOCK 5", "ASCENT", 120, "AD", "HARD", null, 119.0, 0.9916),
      Row("PRYRA_20170101130000", "AZUL", "26D", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "ROADBLOCK", "CAMPAIGN_2019", null, null, "ROADBLOCK 5", "ASCENT", 120, "AD", "HARD", null, 120.0, 1.0),
      Row("PRYRA_20170101130000", "AZUL", "26F", "Coach", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "ROADBLOCK", "CAMPAIGN_2019", null, null, "ROADBLOCK 6", "DESCENT", 120, "AD", "HARD", null, 60.0, 0.5)
    )

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForInstantaneous)
    )
    expectedDF.show(true)
    expectedDF.repartition(1)
  }

  def getProgramAverageCompletionTable(): DataFrame = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("seat_class", StringType, false),
      StructField("flight_takeoff_time", TimestampType, false),
      StructField("flight_type", StringType, false),
      StructField("flight_day_period", StringType, false),
      StructField("flight_duration", IntegerType, false),
      StructField("tail_number", StringType, false),
      StructField("flight_airport_origin", StringType, false),
      StructField("flight_airport_dest", StringType, false),
      StructField("flight_number", StringType, false),
      StructField("channel_id", StringType, false),
      StructField("channel_name", StringType, false),
      StructField("program_title", StringType, false),
      StructField("category", StringType, false),
      StructField("program_length", IntegerType, false),
      StructField("average_pgm_completion_rate", FloatType, false)
    )

    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING",
        7, "N123N", "LAX", "JFK", "AZU123", "5941", "CNN", "Snake on Airplane", "Comedy", 3600, 80.0f),
      Row("PRYRA_20170101130000", "AZUL", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING",
        7, "N123N", "LAX", "JFK", "AZU123", "5941", "CNN", "Snake on Airplane", "Comedy", 3600, null)
    )
    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(expectedSchema)
    )
    expectedDF.show(true)
    expectedDF.coalesce(1)
  }
}
