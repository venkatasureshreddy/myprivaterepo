package com.thalesground.metrics.viewership.utils

import com.thalesground.metrics.viewership.{ViewershipTestSuiteBase}
import com.thalesground.metrics.viewership.common.Util
import org.apache.spark.sql.functions.{col, lower}

class DataComposerTestSuiteInstantaneous extends ViewershipTestSuiteBase {

  test("TESTING DATA COMPOSER INSTANTANEOUS EVENTS"){
    import sqlContext.implicits._

    testData.loadHiveLogTable("seatsession")

    val seatSessionDF = etlContext.selectLogs("stvplus_seatsession").withColumn("airline_id", lower(col("airline_id")))

    val flightsDF = new FlightsTestData(sqlContext, "PRYRA_20180105100348", "PRYRA", "TEST29D", Util.getTime("2018-01-05 10:03:00.000"), Util.getTime("2018-01-05 18:25:00.000")).toDF

    val result = DataComposer.getInstantaneousEvents(sqlContext, seatSessionDF, flightsDF, false)

    assert(!result.filter($"flight_id" === "PRYRA_20180105100348").head(1).isEmpty)

    // TODO Add some data validation checks
  }
}
