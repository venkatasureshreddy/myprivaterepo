package com.thalesground.metrics.viewership.common

import org.apache.spark.sql.types._

object CommonSchema extends Serializable{

  def getSchemaForSeatSession():List[StructField] = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("seat_id", StringType, false),
      StructField("seat_class", StringType, false),
      StructField("program_title", StringType, false),
      StructField("program_title_ext", StringType, false),
      StructField("program_length", IntegerType, false),
      StructField("program_type", StringType, false),
      StructField("channel_id", StringType, false),
      StructField("channel_number", StringType, false),
      StructField("channel_name", StringType, false),
      StructField("channel_denied", StringType, false),
      StructField("media_type", StringType, false),
      StructField("category", StringType, false),
      StructField("time_stamp", TimestampType, false),
      StructField("total_time_viewed", DoubleType, false),
      StructField("program_completion", DoubleType, false),
      StructField("flight_takeoff_time", TimestampType, false),
      StructField("flight_type", StringType, false),
      StructField("flight_day_period", StringType, false),
      StructField("flight_duration", IntegerType, false),
      StructField("tail_number", StringType, false),
      StructField("flight_date_arrival", TimestampType, false),
      StructField("flight_airport_origin", StringType, false),
      StructField("flight_airport_dest", StringType, false),
      StructField("flight_number", StringType, false),
      StructField("flight_aircraft_type", StringType, false) ,
      StructField("content_type", StringType, false)
    )
    expectedSchema
  }

  def getSchemaForSeatSessionADVR():List[StructField] = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("seat_id", StringType, false),
      StructField("seat_class", StringType, false),
      StructField("program_title", StringType, false),
      StructField("program_title_ext", StringType, false),
      StructField("program_length", IntegerType, false),
      StructField("program_type", StringType, false),
      StructField("roadblock_type", StringType, false),
      StructField("channel_id", StringType, false),
      StructField("channel_number", StringType, false),
      StructField("channel_name", StringType, false),
      StructField("channel_denied", StringType, false),
      StructField("media_type", StringType, false),
      StructField("category", StringType, false),
      StructField("time_stamp", TimestampType, false),
      StructField("total_time_viewed", DoubleType, false),
      StructField("program_completion", DoubleType, false),
      StructField("flight_takeoff_time", TimestampType, false),
      StructField("flight_type", StringType, false),
      StructField("flight_day_period", StringType, false),
      StructField("flight_duration", IntegerType, false),
      StructField("tail_number", StringType, false),
      StructField("flight_date_arrival", TimestampType, false),
      StructField("flight_airport_origin", StringType, false),
      StructField("flight_airport_dest", StringType, false),
      StructField("flight_number", StringType, false),
      StructField("flight_aircraft_type", StringType, false) ,
      StructField("content_type", StringType, false)
    )
    expectedSchema
  }


  def getSchemaForInstantaniousPlaying():List[StructField] = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline", StringType, false),
      StructField("seat_id", StringType, false),
      StructField("program_title", StringType, false),
      StructField("position", IntegerType, false),
      StructField("update_type", StringType, false),
      StructField("channel_id", StringType, false),
      StructField("media_type", StringType, false),
      StructField("time_stamp", StringType, false)
    )
    expectedSchema
  }
  
    def getSchemaForInstantaneousWithStartAndEndTimes():List[StructField] = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("seat_id", StringType, false),
      StructField("program_title", StringType, false),
      StructField("position", IntegerType, false),
      StructField("update_type", StringType, false),
      StructField("channel_id", StringType, false),
      StructField("time_stamp", StringType, false),
      StructField("seat_class", StringType, false),
      StructField("utype", StringType, false),
      StructField("program_title_ext", StringType, false)
    )
    expectedSchema
  }
    

  def getSchemaForFlights():List[StructField] = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("flight_takeoff_time", StringType, false),
      StructField("flight_type", StringType, false),
      StructField("flight_day_period", StringType, false),
      StructField("flight_duration", StringType, false),
      StructField("tail_number", StringType, false),
      StructField("flight_date_arrival", StringType, false),
      StructField("flight_airport_origin", StringType, false),
      StructField("flight_airport_dest", StringType, false),
      StructField("flight_number", StringType, false),
      StructField("flight_aircraft_type", StringType, false)
    )
    expectedSchema
  }
  def getSchemaForSeatSessionHive():List[StructField] = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("file_name", StringType, false),
      StructField("time_stamp", StringType, false),
      StructField("host_name", StringType, false),
      StructField("process_name", StringType, false),
      StructField("p_id", IntegerType, false),
      StructField("t_id", IntegerType, false),
      StructField("log_level", IntegerType, false),
      StructField("version", DoubleType, false),
      StructField("msg_type", StringType, false),
      StructField("msg_data", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("year", StringType, false),
      StructField("month", StringType, false),
      StructField("day", StringType, false)
    )
    expectedSchema
  }

  def getSchemaForInstantaneous(): List[StructField] = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("seat_id", StringType, false),
      StructField("seat_class", StringType, false),
      StructField("flight_takeoff_time", TimestampType, false),
      StructField("flight_type", StringType, false),
      StructField("flight_day_period", StringType, false),
      StructField("flight_duration", IntegerType, false),
      StructField("tail_number", StringType, false),
      StructField("flight_date_arrival", TimestampType, false),
      StructField("flight_airport_origin", StringType, false),
      StructField("flight_airport_dest", StringType, false),
      StructField("flight_number", StringType, false),
      StructField("flight_aircraft_type", StringType, false),
      StructField("media_type", StringType, false),
      StructField("channel_id", StringType, false),
      StructField("channel_name", StringType, false),
      StructField("channel_number", StringType, false),
      StructField("program_title", StringType, false),
      StructField("program_title_ext", StringType, false),
      StructField("program_length", IntegerType, false),
      StructField("category", StringType, false),
      StructField("content_type", StringType, false),
      StructField("roadblock_type", StringType, false),
      StructField("time_viewed", DoubleType, false),
      StructField("program_completion", DoubleType, false)
    )
    expectedSchema
  }

  def getSchemaForTransition():List[StructField] = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("seat_id", StringType, false),
      StructField("seat_class", StringType, false),
      StructField("flight_takeoff_time", TimestampType, false),
      StructField("flight_type", StringType, false),
      StructField("flight_day_period", StringType, false),
      StructField("flight_duration", IntegerType, false),
      StructField("tail_number", StringType, false),
      StructField("flight_date_arrival", TimestampType, false),
      StructField("flight_airport_origin", StringType, false),
      StructField("flight_airport_dest", StringType, false),
      StructField("flight_number", StringType, false),
      StructField("flight_aircraft_type", StringType, false),
      StructField("media_type", StringType, false),
      StructField("channel_id", StringType, false),
      StructField("channel_name", StringType, false),
      StructField("channel_denied", StringType, false)
    )
    expectedSchema
  }

}

