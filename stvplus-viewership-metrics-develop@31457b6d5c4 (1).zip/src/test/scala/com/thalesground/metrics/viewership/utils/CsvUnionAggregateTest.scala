package com.thalesground.metrics.viewership.utils

import com.thalesground.metrics.viewership.ViewershipTestSuiteBase
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}

class CsvUnionAggregateTest extends ViewershipTestSuiteBase {

  test("Test CsvUnionAggregate") {
    val csvUnion = new CsvUnionAggregate
    val schema = StructType(List(StructField("col1", StringType, true), StructField("col2", StringType, true)))
    var actualDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row("a", "b"))), schema)
    actualDf = actualDf.groupBy("col2").agg(csvUnion(actualDf.col("col1")).as("col1")).select("col1", "col2")
    var expectedDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row("a", "b"))), schema)
    assertDataFramesEqual(expectedDf, actualDf)

    actualDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row(null, "b"))), schema)
    actualDf = actualDf.groupBy("col2").agg(csvUnion(actualDf.col("col1")).as("col1")).select("col1", "col2")
    expectedDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row(null, "b"))), schema)
    assertDataFramesEqual(expectedDf, actualDf)

    actualDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row(null, "b"), Row(null, "b"), Row("a", "b"))), schema)
    actualDf = actualDf.groupBy("col2").agg(csvUnion(actualDf.col("col1")).as("col1")).select("col1", "col2")
    expectedDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row("a", "b"))), schema)
    assertDataFramesEqual(expectedDf, actualDf)

    actualDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row(null, "b"), Row(null, "b"), Row("a", "b"), Row("a,b", "b"), Row("c", "b"))), schema)
    actualDf = actualDf.groupBy("col2").agg(csvUnion(actualDf.col("col1")).as("col1")).select("col1", "col2")
    assert("a,b,c".split(",").toSet == actualDf.select("col1").head().getAs[String](0).split(",").toSet)
  }

}
