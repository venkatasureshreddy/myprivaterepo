package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util
import org.apache.spark.sql.functions.expr

class Flight_PRYRD_20190215141431_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRD_20190215141431")

  test("Test PRYRA_2018Oct04104245_ICCP") {
    import sqlContext.implicits._

    val results = testFlight("azul", "PRYRD", "DSU012NGE", "PRYRD_20190215141431", Util.getTime("2019-02-15 14:15:43.863"), Util.getTime("2019-02-15 16:29:28.256"))

    assert(results.contains("viewership_metrics_by_channel"))
    assert(results.contains("viewership_metrics_by_program"))
    assert(results.contains("viewership_metrics_by_roadblock"))
    assert(results.contains("viewership_metrics_by_category"))
    assert(results.contains("viewership_metrics_by_flight"))

    val df = results("viewership_metrics_by_roadblock")
    assert(!df.head(1).isEmpty)

    assert(df.where("roadblock_metric_id='roadblock_nb_unique_views' and roadblock_metric_value > 1").head(1).isEmpty)
  }
}
