package com.thalesground.metrics.viewership.utils

import java.sql.Timestamp

import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SQLContext}

class FlightsTestData(sqlContext: SQLContext, flightId: String, tailId: String, flightNumber: String, logDepartureTime: Timestamp, logArrivalTime: Timestamp) {

  val schema = List(
    StructField("flight_id", StringType, false),
    StructField("airline_id", StringType, false),
    StructField("flight_takeoff_time", TimestampType, false),
    StructField("flight_date_arrival", TimestampType, false),
    StructField("flight_type", StringType, false),
    StructField("flight_day_period", StringType, false),
    StructField("flight_duration", LongType, false),
    StructField("tail_number", StringType, false),
    StructField("flight_number", StringType, false),
    StructField("flight_airport_origin", StringType, false),
    StructField("flight_airport_dest", StringType, false),
    StructField("flight_aircraft_type", StringType, true)
  )

  def toDF(): DataFrame = {
    val rows = Seq(
      Row(flightId, "azul", logDepartureTime, logArrivalTime, "N/A", "Unknown", Math.abs(logArrivalTime.getTime - logDepartureTime.getTime) / 60000, tailId, flightNumber, "KMCO", "KDFW", null)
    )
    sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(rows), StructType(schema))
  }
}