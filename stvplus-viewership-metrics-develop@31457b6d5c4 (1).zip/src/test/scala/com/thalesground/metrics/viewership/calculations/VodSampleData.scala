package com.thalesground.metrics.viewership.calculations

import com.thalesground.metrics.viewership.common.{CommonSchema, Util}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row}

class VodSampleData(hc: HiveContext) {
  def loadSeatSession(): DataFrame = {

    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45"), 960.0, 0.5,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","TV Series" ),
      Row("PRYRA_20170101130000", "AZUL", "26D", "Economy", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), 960.0, 0.9,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","TV Series"),
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy", "Dancing with Monkey", "", 1800, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), 960.0, 0.75,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","TV Series"),
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy", "Zero Hours", "4:6", 1800, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), 960.0, 1.0,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","TV Series"),
      Row("PRYRA_20170101130000", "AZUL", "27A", "Economy", "Zero Hours", "4:2", 1800, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), 960.0, 0.25,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","TV Series"),
      Row("PRYRA_20170101130000", "AZUL", "1A", "Business", "Zero Hours", "4:6", 1800, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), 960.0, 0.25,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","TV Series"),
      Row("PRYRA_20170101130000", "AZUL", "26E", "Economy", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), 80.0, 0.4,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","TV Series"),

      //This below data is for null checks, seatid is null and total_time_Viewed is null. in this case we are expecting 0.0 value
        Row("PRYRA_20170101130000", "AZUL", null, "coach", "TEST OUT", "", 1800, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), null, 1.0,
        Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","TV Series"),
        Row("PRYRA_20170101130000", "AZUL", null, "coach", "Training Day", "", 1800, "Comedy", "5941", "5941", "CNN",
          "NO_AVAILABLE_TUNER", "AVOD", "Comedy", Util.getTime("2017-07-11 07:50:45.0"), null, 1.0,
          Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380","TV Series")
    )

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForSeatSession())
    )
    expectedDF.show(true)
    expectedDF.repartition(1)
  }
}
