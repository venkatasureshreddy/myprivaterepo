package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_AZSW02_20180927234215_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/AZSW02_20180927234215")

   test("Test AZSW02_20180927234215") {
     val results = testFlight("azul", "AZSW02", "JMB140911", "AZSW02_20180927234215", Util.getTime("2018-09-27 20:54:17.953"), Util.getTime("2018-09-27 21:34:14.147"))

     assert(results.contains("viewership_metrics_by_program"))

     val df = results("viewership_metrics_by_program")
     assert(!df.head(1).isEmpty)

     assertNumbersClose(1658d, df.where("program_id = 'Craig of the Creek' and program_metric_id = 'program_total_time_viewed'").head().getAs[Double]("program_metric_value"))
  }
}