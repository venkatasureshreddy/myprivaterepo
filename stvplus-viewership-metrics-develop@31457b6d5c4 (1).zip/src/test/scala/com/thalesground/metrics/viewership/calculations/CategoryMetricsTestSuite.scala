package com.thalesground.metrics.viewership.calculations

import java.sql.{Timestamp}

import com.thalesground.metrics.viewership.ViewershipTestSuiteBase
import org.apache.spark.sql.hive.HiveContext

class CategoryMetricsTestSuite extends ViewershipTestSuiteBase {

  override def beforeAll() {
    super.beforeAll()  }

  override def afterAll() {
    super.afterAll()
  }

  case class CategoryMetrics(flight_id: String, airline_id: String, seat_class: String, flight_takeoff_time: Timestamp,
                             flight_type: String, flight_day_period: String, flight_duration: Int, tail_number: String,
                             flight_airport_origin: String, flight_airport_dest: String, flight_number: String, category_id: String,
                             category_metric_id: String, category_metric_value: Float, media_type: String, content_type: String)

  test("CATEGORY DERIVED") {
    val categoryMock = createCategoryMock()
    val data = new CategorySampleData(sqlContext)
    val instantaneousData = data.loadInstantaneousEvents

    val output = categoryMock.calculateCategoryDerived(instantaneousData)
  }

  test("CATEGORY TOTAL TIME VIEWED") {
    val categoryMock = createCategoryMock()
    val data = new CategorySampleData(sqlContext)
    val instantaneousData = data.loadInstantaneousEvents
    val categoryDF = categoryMock.calculateCategoryDerived(instantaneousData)

    val output = categoryMock.calculateCategoryTotalTimeViewed(categoryDF)
  }

  test("CATEGORY UNIQUE VIEWS") {
    val categoryMock = createCategoryMock()
    val data = new CategorySampleData(sqlContext)
    val instantaneousData = data.loadInstantaneousEvents
    val categoryDF = categoryMock.calculateCategoryDerived(instantaneousData)

    val output = categoryMock.calculateCategoryUniqueViews(categoryDF)
  }

  def createCategoryMock(): CategoryCalculation = {
    return new CategoryCalculation(etlContext, false)
  }

  def validateMetrics(expectedList: List[CategoryMetrics], actualList: List[CategoryMetrics]): Unit = {
    assert(expectedList.length == actualList.length)
    (expectedList, actualList).zipped foreach { (expected, actual) =>
      assert(expected.flight_id == actual.flight_id)
      assert(expected.airline_id == actual.airline_id)
      assert(expected.seat_class == actual.seat_class)
      assert(expected.flight_takeoff_time == actual.flight_takeoff_time)
      assert(expected.flight_type == actual.flight_type)
      assert(expected.flight_day_period == actual.flight_day_period)
      assert(expected.flight_duration == actual.flight_duration)
      assert(expected.tail_number == actual.tail_number)
      assert(expected.flight_airport_origin == actual.flight_airport_origin)
      assert(expected.flight_airport_dest == actual.flight_airport_dest)
      assert(expected.flight_number == actual.flight_number)
      assert(expected.category_id == actual.category_id)
      assert(expected.category_metric_id == actual.category_metric_id)
      assert(expected.category_metric_value == actual.category_metric_value)
      assert(expected.media_type == actual.media_type)
    }
  }


}