package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_PRYRK_2019mar15110949_ICCP_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRK_2019mar15110949_ICCP")

  test("Test PRYRD_20190307224345") {

    val results = testFlight("azul", "PRYRK", "DSU01234", "PRYRK_2019mar15110949_ICCP", Util.getTime("2019-03-15 09:11:01.601"), Util.getTime("2019-03-15 10:40:34.833"))

    assert(results.contains("viewership_metrics_by_channel"))

    val df = results("viewership_metrics_by_channel")
    assert(!df.head(1).isEmpty)
  }
}
