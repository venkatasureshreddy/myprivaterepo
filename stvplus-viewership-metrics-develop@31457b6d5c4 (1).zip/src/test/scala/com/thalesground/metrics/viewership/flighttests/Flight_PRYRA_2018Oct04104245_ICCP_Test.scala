package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util
import org.apache.spark.sql.Row

/**
  * Test for STVPLUS-1589/STVPLUS-1481 related to "Other" category
  */
class Flight_PRYRA_2018Oct04104245_ICCP_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRA_2018Oct04104245_ICCP")

  test("Test PRYRA_2018Oct04104245_ICCP") {
    val results = testFlight("azul", "PRYRA", "AZU9797", "PRYRA_2018Oct04104245_ICCP", Util.getTime("2018-10-02 20:14:20.368"), Util.getTime("2018-10-02 21:08:19.777"))

    assert(results.contains("viewership_metrics_by_roadblock"))
    assert(results.contains("viewership_metrics_by_program"))
    assert(results.contains("viewership_metrics_by_category"))

    var df = results("viewership_metrics_by_roadblock")
    assert(!df.head(1).isEmpty)
    assertNumbersClose(136.0, df.where("roadblock_metric_id = 'roadblock_total__time_viewed'").head().getAs[Long]("roadblock_metric_value"))
    assertNumbersClose(1, df.where("roadblock_metric_id = 'roadblock_nb_unique_views'").head().getAs[Long]("roadblock_metric_value"))

    df = results("viewership_metrics_by_program")
    assert(!df.head(1).isEmpty)
    assert(!df.filter("program_id = 'Craig of the Creek'").head(1).isEmpty)

    df = df.filter("program_id = 'The Amazing World of Gumball'")
    assert(!df.head(1).isEmpty)
    assertNumbersClose(2386d, df.where("program_metric_id = 'program_total_time_viewed'").head().getAs[Double]("program_metric_value"))
    // assertNumbersClose(2423d, df.where("program_metric_id = 'program_average_time_viewed'").head().getAs[Double]("program_metric_value"))
    assertNumbersClose(1, df.where("program_metric_id = 'program_nb_unique_views'").head().getAs[Long]("program_metric_value"))
    assertNumbersClose(2, df.where("program_metric_id = 'program_viewed_to_completion'").head().getAs[Long]("program_metric_value"))
    assertNumbersClose(4, df.where("program_metric_id = 'program_unique_views'").head().getAs[Long]("program_metric_value"))

    df = results("viewership_metrics_by_category")
    assert(!df.head(1).isEmpty)
    assert(!df.filter("category_id = 'AD'").head(1).isEmpty)
    assert(!df.filter("category_id = 'Kids'").head(1).isEmpty)
    assert(df.filter("category_id = 'Other'").head(1).isEmpty)
    assertNumbersClose(136, df.where("category_id = 'AD' and category_metric_id = 'category_total_time_viewed'").head().getAs[Long]("category_metric_value"))
    assertNumbersClose(1, df.where("category_id = 'AD' and category_metric_id = 'category_nb_unique_views'").head().getAs[Long]("category_metric_value"))
    assertNumbersClose(2637d, df.where("category_id = 'Kids' and category_metric_id = 'category_total_time_viewed'").head().getAs[Long]("category_metric_value"))
    assertNumbersClose(1, df.where("category_id = 'Kids' and category_metric_id = 'category_nb_unique_views'").head().getAs[Long]("category_metric_value"))
  }
}
