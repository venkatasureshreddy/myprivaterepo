package com.thalesground.metrics.viewership.calculations

import com.thalesground.metrics.viewership.common.{CommonSchema, Util}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row}

class CategorySampleData(hc: HiveContext){
  def loadSeatSession(): DataFrame = {

    val expectedData = Seq(
      Row("PRYRH_20170101130040", "AZUL", "26C", "First Class", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "crime", Util.getTime("2017-01-01 13:00:40.000"),  300.0, 0.5,
        Util.getTime("2017-01-01 13:00:40.000"), "DOMESTIC", "EVENING", 22, "PRYRH", Util.getTime("2017-01-01 13:00:40.000"), "LAX", "JFK", "AZU123", "A380","TV Series"),
      Row("PRYRH_20170101130040", "AZUL", "26D", "First Class", "Snake on Airplane", "", 3600, "Comedy", "5941", "5941", "CNN",
        "NO_AVAILABLE_TUNER", "AVOD", "crime", Util.getTime("2017-01-01 13:00:40.000"),  300.0, 0.5,
        Util.getTime("2017-01-01 13:00:40.000"), "DOMESTIC", "EVENING", 22, "PRYRH", Util.getTime("2017-01-01 13:00:40.000"), "LAX", "JFK", "AZU123", "A380","TV Series")
      )

    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForSeatSession())
    )

  expectedDF.show(false)
    expectedDF.repartition(1)
  }

  def loadInstantaneousEvents(): DataFrame = {
    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "TV_CHANNEL", "5941", "CNN", "5941", "CNN Newsroom", "Live", 3600, "NEWS,LIVE", "", null, 3240.0, 0.9),
      Row("PRYRA_20170101130000", "AZUL", "26D", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "TV_CHANNEL", "5941", "CNN","5941", "CNN Newsroom", "Live", 3600, "NEWS,LIVE", "", null, 3060.0, 0.85),
      Row("PRYRA_20170101130000", "AZUL", "26F", "Coach", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "TV_CHANNEL", "5941", "CNN", "5941", "CNN Newsroom", "Live", 3600, "NEWS,LIVE", "", null, 1800.0, 0.5)
    )

    val expectedDF = hc.createDataFrame(hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForInstantaneous)
    )
    expectedDF.show(true)
    expectedDF.repartition(1)
  }
}