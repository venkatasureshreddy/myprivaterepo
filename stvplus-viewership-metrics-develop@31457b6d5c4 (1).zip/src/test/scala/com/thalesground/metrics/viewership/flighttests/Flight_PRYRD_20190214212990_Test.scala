package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_PRYRD_20190214212990_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRD_20190214212990")

  test("Test PRYRA_2018Oct04104245_ICCP") {

    val results = testFlight("azul", "PRYRD", "DSUHARD3", "PRYRD_20190214212990", Util.getTime("2019-02-14 21:28:50.353"), Util.getTime("2019-02-14 22:10:23.975"))

    assert(results.contains("viewership_metrics_by_roadblock"))

    val df = results("viewership_metrics_by_roadblock")
    assert(!df.head(1).isEmpty)
  }
}
