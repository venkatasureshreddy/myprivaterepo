package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_PRYRB_20181017093045_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRB_20181017093045")

   test("Test PRYRB_20181017093045") {
     val results = testFlight("azul", "PRYRB", "TEST29D", "PRYRB_20181017093045", Util.getTime("2018-08-25 06:09:30.315"), Util.getTime("2018-08-25 06:09:30.758"))

     assert(results.contains("viewership_metrics_by_channel"))
     assert(results.contains("viewership_metrics_by_program"))
     assert(results.contains("viewership_metrics_by_category"))

     var df = results("viewership_metrics_by_program")
     assertNumbersClose(827d, df.where("program_metric_id = 'program_total_time_viewed' and program_id = 'Halloween: A Noite do Terror'").head().getAs[Double]("program_metric_value"))
     assert(df.where("program_id='Baila Comigo'").head(1).isEmpty)

     df = results("viewership_metrics_by_channel")
     assert(df.where("channel_name='VIVA'").head(1).isEmpty)

     df = results("viewership_metrics_by_category")
     assert(df.where("category_id='Soap Opera'").head(1).isEmpty)
  }
}