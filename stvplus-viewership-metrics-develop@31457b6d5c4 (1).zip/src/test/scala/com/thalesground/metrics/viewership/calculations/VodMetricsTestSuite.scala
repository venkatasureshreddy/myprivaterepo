package com.thalesground.metrics.viewership.vod

import java.sql.{Connection, DriverManager, Timestamp}

import com.thalesground.metrics.viewership.ViewershipTestSuiteBase
import com.thalesground.metrics.viewership.calculations.VodCalculation
import org.apache.spark.sql.{DataFrame, SaveMode}

import scala.collection.mutable.ListBuffer


class VodMetricsTestSuite extends ViewershipTestSuiteBase {

  case class VodMetrics(flight_id: String, airline_id: String, seat_class: String, flight_takeoff_time: Timestamp, flight_type: String,
                        flight_day_period: String, flight_duration: Int, tail_number: String, flight_airport_origin: String, flight_airport_dest: String,
                        flight_number: String, vod_id: String, vod_name: String, vod_studio_source: String, vod_category: String, vod_duration: Int,
                        vod_type: String, vod_metric_id: String, vod_metric_value: Float)

//  test("TESTING VOD TOTAL SECONDS VIEWED ") {
//    val vodMock = createVodMock()
//    val vodContentDF = vodMock.getVodContent()
//
//    val output = vodMock.calculateVodTotalSecondsViewed(vodContentDF)
//  }
//
//  test("TESTING VOD TOTAL UNIQUE VIEW CALCULATION AND VOD   COMPLETION VIEWS CALCULATION") {
//    val vodMock = createVodMock()
//    val vodContentDF = vodMock.getVodContent()
//
//  }
//
//  test("") {
//    val vodMock = createVodMock()
//    val vodContentDF = vodMock.getVodContent()
//
//    vodMock.calculateCompletionViews()
//  }

  def createVodMock(): VodCalculation = {
    return new VodCalculation(etlContext, false)
  }

  def validateMetrics(inputexpectedList: List[VodMetrics], inputactualList: List[VodMetrics]): Unit = {

    val expectedList =inputexpectedList.sortBy(VodMetrics =>  (VodMetrics.vod_id,VodMetrics.seat_class))
    val actualList =inputactualList.sortBy(VodMetrics =>  (VodMetrics.vod_id,VodMetrics.seat_class))

    assert(expectedList.length == actualList.length)
    (expectedList, actualList).zipped foreach { (expected, actual) =>
      assert(expected.flight_id == actual.flight_id)
      assert(expected.airline_id == actual.airline_id)
      assert(expected.seat_class == actual.seat_class)
      assert(expected.flight_takeoff_time == actual.flight_takeoff_time)
      assert(expected.flight_type == actual.flight_type)
      assert(expected.flight_day_period == actual.flight_day_period)
      assert(expected.flight_duration == actual.flight_duration)
      assert(expected.tail_number == actual.tail_number)
      assert(expected.flight_airport_origin == actual.flight_airport_origin)
      assert(expected.flight_airport_dest == actual.flight_airport_dest)
      assert(expected.flight_number == actual.flight_number)
      assert(expected.vod_id == actual.vod_id)
      assert(expected.vod_name == actual.vod_name)
      assert(expected.vod_studio_source == actual.vod_studio_source)
      assert(expected.vod_category == actual.vod_category)
      assert(expected.vod_duration == actual.vod_duration)
      assert(expected.vod_type == actual.vod_type)
      assert(expected.vod_metric_id == actual.vod_metric_id)
      assert(expected.vod_metric_value == actual.vod_metric_value)
    }
  }
}
