package com.thalesground.metrics.viewership.flighttests

import java.sql.Timestamp

import com.thales.avionics.ife.tvs.etl.ETLContext
import com.thales.avionics.ife.tvs.etl.hivecompaction.HiveCompactorOptions
import com.thalesground.metrics.viewership.{Viewership, ViewershipTestSuiteBase}
import org.apache.spark.SparkContext
import org.apache.spark.sql.functions.{abs, broadcast, coalesce, lit}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import org.mockito.stubbing.Answer
import org.mockito.{Matchers, Mockito}
import org.mockito.Mockito.when

import scala.collection.mutable

abstract class FlightTestSuite extends ViewershipTestSuiteBase {

  private val flightsSchema: StructType = new StructType()
    .add(StructField("id", StringType, true))
    .add(StructField("log_flight_id", StringType, true))
    .add(StructField("airline_id", StringType, true))
    .add(StructField("log_departure_time", TimestampType, true))
    .add(StructField("log_arrival_time", TimestampType, true))
    .add(StructField("origin_country_code", StringType, true))
    .add(StructField("destination_country_code", StringType, true))
    .add(StructField("tail_number", StringType, true))
    .add(StructField("origin_airport", StringType, true))
    .add(StructField("destination_airport", StringType, true))
    .add(StructField("flight_number", StringType, true))
    .add(StructField("aircraft_type", StringType, true))


  def testFlight(airlineId: String, tailId: String, flightNumber: String, flightId: String, logDepartureTime: Timestamp, logArrivalTime: Timestamp): mutable.HashMap[String, DataFrame] = {
    testData.loadHiveLogTable("seatsession")

    val flight = Seq(
      Row(flightId, flightId, airlineId, logDepartureTime, logArrivalTime, "US", "US", tailId, "MCO", "FLL", flightNumber, "A320")
    )

    when(phoenix.load("flights")).thenReturn(sqlContext.createDataFrame(sc.parallelize(flight), flightsSchema))

    val results = mockPhoenixPersistence()
    val mockCompactorOptions = Mockito.mock(classOf[HiveCompactorOptions])
    val viewership = new ViewershipMock(etlContext, mockCompactorOptions, false)

    val flightProductStatusDf=etlContext.flightProductStatus.getFiltered()
    println(flightProductStatusDf.show(false))

    viewership.run(60, 0, 0.8f, 10)
    /*
    showTables calls DataFrame.show() on all saved DataFrames, which ensures that they are actually evaluated
    since DataFrames are evaluated lazily
    printing this data also helps with troubleshooting
    Common.PROGRAM_DETAIL is used in so many places that is helpful to print it as well
     */
    showTables(results)

    results
  }

  def showTables(map:  mutable.HashMap[String, DataFrame]): Unit = {
    for((tableName, df) <- map) {
      println(tableName)
      showTable(df)
    }
  }

  def showTable(df: DataFrame) = {
    df.show(1000000, false)
  }

  private def convertToDouble(number: Any): Double = {
    assert(number != null)
    number match {
      case d: Double => d
      case l: Long => l.toDouble
      case i: Int => i.toDouble
      case _ => throw new UnsupportedOperationException("Unsupported number type " + number.getClass)
    }
  }

  def assertNumbersClose(expected: Any, actual: Any): Unit = {
    // Due to rounding, allow up to 0.5 difference between expected and actual
    assert(Math.abs(convertToDouble(expected) - convertToDouble(actual)) <= 0.5d)
  }

}

class ViewershipMock(etlContext: ETLContext, hiveCompactorOptions: HiveCompactorOptions, debugFlag: Boolean) extends Viewership(etlContext, hiveCompactorOptions, debugFlag) {
  override def compact = {
    println("Not compacting for unit tests")
  }

  override def runWithTableCompactionReadLock(callable: () => Unit) = {
    println("Skipping table lock")
    callable.apply()
  }
}
