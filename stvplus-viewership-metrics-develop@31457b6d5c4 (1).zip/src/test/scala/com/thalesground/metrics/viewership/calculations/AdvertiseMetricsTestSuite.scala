package com.thalesground.metrics.viewership.calculations

import java.sql.Timestamp
import com.thalesground.metrics.viewership.ViewershipTestSuiteBase

class AdvertiseMetricsTestSuite extends ViewershipTestSuiteBase  {

  case class AdMetrics(flight_id: String, airline_id: String, seat_class: String, flight_takeoff_time: Timestamp, flight_type: String,
                       flight_day_period: String, flight_duration: Int, tail_number: String, flight_airport_origin:String, flight_airport_dest: String,flight_number: String , AD_TITLE: String,
                       roadblock_title: String,ad_id:String,  roadblock_type: String,  category:String,roadblock_metric_id: String,  roadblock_metric_value: Float)

  override def beforeAll() {
    super.beforeAll()
  }

  override def afterAll() {
    super.afterAll()
  }

  test("TESTING ROADBLOCK TOTAL TIME VIEWED ") {
    val adMock = createAdMock()
    val sampleTestData = new AdvertiseSampleData(sqlContext)
    val seatLogs = sampleTestData.loadSeatSession()

    val output = adMock.calculateTotalTimeViewedPerAdTitle(seatLogs)

    // assertDataFramesEqual(output, avgLogs)
  }

  test("TESTING ROADBLOCK NB UNIQUE VIEWS") {
    val adMock = createAdMock()
    val sampleTestData = new AdvertiseSampleData(sqlContext)
    val seatLogs = sampleTestData.loadSeatSession()

    val output = adMock.calculateNbUniqueViewsPerAdvertisement(seatLogs)


    // assertDataFramesEqual(output, avgLogs)
  }

  def createAdMock(): AdvertisementCalculation = {
    return new AdvertisementCalculation(etlContext, false)
  }

  def validateMetrics(expectedList: List[AdMetrics], actualList: List[AdMetrics]) = {
    assert(expectedList.length == actualList.length)
    (expectedList, actualList).zipped foreach { (expected, actual) =>
      assert(expected.flight_id == actual.flight_id)
      assert(expected.airline_id == actual.airline_id)
      assert(expected.seat_class == actual.seat_class)
      assert(expected.flight_takeoff_time == actual.flight_takeoff_time)
      assert(expected.flight_type == actual.flight_type)
      assert(expected.flight_day_period == actual.flight_day_period)
      assert(expected.flight_duration == actual.flight_duration)
      assert(expected.tail_number == actual.tail_number)
      assert(expected.flight_airport_origin == actual.flight_airport_origin)
      assert(expected.flight_airport_dest == actual.flight_airport_dest)
      assert(expected.roadblock_metric_id == actual.roadblock_metric_id)
      assert(expected.roadblock_metric_value == actual.roadblock_metric_value)
    }
  }
}

