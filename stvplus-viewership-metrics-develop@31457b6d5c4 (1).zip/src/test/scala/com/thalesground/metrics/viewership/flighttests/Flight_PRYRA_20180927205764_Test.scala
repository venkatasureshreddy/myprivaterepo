package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_PRYRA_20180927205764_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRA_20180927205764")

   test("Test PRYRA_20180927205764") {
     val results = testFlight("azul", "PRYRA", "JMB04756", "PRYRA_20180927205764", Util.getTime("2018-09-27 20:54:18.388"), Util.getTime("2018-09-27 21:34:14.147"))

     assert(results.contains("viewership_metrics_by_program"))

     val df = results("viewership_metrics_by_program")

     assert(!df.where("program_metric_id = 'program_total_time_viewed' and program_id = 'The Amazing World of Gumball'").head(1).isEmpty)
     assertNumbersClose(187d, df.where("program_metric_id = 'program_total_time_viewed' and program_id = 'The Amazing World of Gumball'").head().getAs[Double]("program_metric_value"))

     // assert(!df.where("program_metric_id = 'program_average_time_viewed' and program_id = 'The Amazing World of Gumball'").head(1).isEmpty)
     // assertNumbersClose(62.33d, df.where("program_metric_id = 'program_average_time_viewed' and program_id = 'The Amazing World of Gumball'").head().getAs[Double]("program_metric_value"))

     assert(!df.where("program_metric_id = 'program_viewed_to_completion' and program_id = 'The Amazing World of Gumball'").head(1).isEmpty)
     assertNumbersClose(0L, df.where("program_metric_id = 'program_viewed_to_completion' and program_id = 'The Amazing World of Gumball'").head().getAs[Long]("program_metric_value"))
  }
}