package com.thalesground.metrics.viewership.calculations

import com.thalesground.metrics.viewership.common.{CommonSchema, Util}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row}

class ChannelSampleData(hc: HiveContext) {
  def loadInstantaneousEvents(): DataFrame = {
    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "TV_CHANNEL", "5941", "CNN", "5941", "CNN Newsroom", "Live", 3600, "", "", null, 3240.0, 0.9),
      Row("PRYRA_20170101130000", "AZUL", "26D", "Economy", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "TV_CHANNEL", "5941", "CNN","5941", "CNN Newsroom", "Live", 3600, "", "", null, 3060.0, 0.85),
      Row("PRYRA_20170101130000", "AZUL", "26F", "Coach", Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "TV_CHANNEL", "5941", "CNN", "5941", "CNN Newsroom", "Live", 3600, "", "", null, 1800.0, 0.5)
    )

    val expectedDF = hc.createDataFrame(hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForInstantaneous)
    )
    expectedDF.show(true)
    expectedDF.repartition(1)
  }

  def loadTransitionEvents(): DataFrame = {
    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy",  Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "TV_CHANNEL", "6060", "SPORTSNSTUFF", null),
      Row("PRYRA_20170101130000", "AZUL", "25C", "Economy",  Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "TV_CHANNEL", "6060", "SPORTSNSTUFF", "NO_AVAILABLE_TUNER"),
      Row("PRYRA_20170101130000", "AZUL", "26C", "Economy",  Util.getTime("2017-07-11 07:50:45.0"), "DOMESTIC", "MORNING", 7, "N123N", Util.getTime("2017-07-11 09:49:25.0"), "LAX", "JFK", "AZU123", "A380", "TV_CHANNEL", "6446", "MTV", null)
    )
    val expectedDF = hc.createDataFrame(hc.sparkContext.parallelize(expectedData),
      StructType(CommonSchema.getSchemaForTransition)
    )
    expectedDF.show(true)
    expectedDF.repartition(1)
  }

  def getNumTimesProgramsViewed_Df(): DataFrame = {
    val expectedSchema = List(
      StructField("flight_id", StringType, false),
      StructField("airline_id", StringType, false),
      StructField("channel_id", StringType, false),
      StructField("program_title", StringType, false),
      StructField("program_title_ext", StringType, false),
      StructField("program_count", IntegerType, false)

    )

    val expectedData = Seq(
      Row("PRYRA_20170101130000", "AZUL","5941", "CNN Newsroom","" ,3))
    val expectedDF = hc.createDataFrame(
      hc.sparkContext.parallelize(expectedData),
      StructType(expectedSchema)
    )
    expectedDF.show(true)
    expectedDF.coalesce(1)
  }
}