package com.thalesground.metrics.viewership.calculations

import java.sql.{Timestamp}

import com.thalesground.metrics.viewership.ViewershipTestSuiteBase
import com.thalesground.metrics.viewership.common.Util.timestamps
import com.thalesground.metrics.viewership.common.Util
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SaveMode}


class FlightMetricsTestSuite extends ViewershipTestSuiteBase {

  case class FlightMetric(flight_id: String, airline_id: String, seat_class: String, flight_takeoff_time: Timestamp,
                          flight_type: String, flight_day_period: String, flight_duration: Int, tail_number: String,
                          flight_date_arrival: Timestamp, flight_airport_origin: String, flight_airport_dest: String,
                          flight_number: String, flight_aircraft_type: String, flight_metric_id: String, flight_metric_value: Float)


  test("TESTING FLIGHT") {
    val totalPassengerList = List(
      FlightMetric("PRYRA_20170101130000", "AZUL", "Business", Util.getTime("2017-07-11 07:50:45"), "DOMESTIC", "MORNING", 7, "N123N",
        Util.getTime("2017-07-11 09:49:25"), "LAX", "JFK", "AZU123", "A380", "flight_total_nb_passengers", 20f),
      FlightMetric("PRYRA_20170101130000", "AZUL", "Economy", Util.getTime("2017-07-11 07:50:45"), "DOMESTIC", "MORNING", 7, "N123N",
        Util.getTime("2017-07-11 09:49:25"), "LAX", "JFK", "AZU123", "A380", "flight_total_nb_passengers", 100f),
      FlightMetric("PRYRA_20170101130001", "AZUL", "Business", Util.getTime("2017-07-11 07:50:45"), "DOMESTIC", "MORNING", 7, "N123N",
        Util.getTime("2017-07-11 09:49:25"), "LAX", "JFK", "AZU123", "A380", "flight_total_nb_passengers", 20f))

    val flightMock = createFlightMock()
    //flightMock.calculateFlightMetricsFlightTotalPassengers()
  }

  def createFlightMock(): FlightCalculation = {
    return new FlightCalculation(etlContext, false)
  }

  def validateMetrics(expectedList: List[FlightMetric], actualList: List[FlightMetric]): Unit = {
    assert(expectedList.length == actualList.length)
    (expectedList, actualList).zipped foreach { (expected, actual) =>
      assert(expected.flight_id == actual.flight_id)
      assert(expected.airline_id == actual.airline_id)
      assert(expected.seat_class == actual.seat_class)
      assert(expected.flight_takeoff_time == actual.flight_takeoff_time)
      assert(expected.flight_type == actual.flight_type)
      assert(expected.flight_day_period == actual.flight_day_period)
      assert(expected.flight_duration == actual.flight_duration)
      assert(expected.tail_number == actual.tail_number)
      assert(expected.flight_date_arrival == actual.flight_date_arrival)
      assert(expected.flight_airport_origin == actual.flight_airport_origin)
      assert(expected.flight_airport_dest == actual.flight_airport_dest)
      assert(expected.flight_number == actual.flight_number)
      assert(expected.flight_aircraft_type == actual.flight_aircraft_type)
      assert(expected.flight_metric_id == actual.flight_metric_id)
      assert(expected.flight_metric_value == actual.flight_metric_value)
    }
  }

}
