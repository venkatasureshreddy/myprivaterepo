package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

/**
  * Test for HDP-8370 Program Total Viewed Time
  */
class Flight_PRYRC_2018out17151604_ICCP_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRC_2018out17151604_ICCP")

  test("Test PRYRC_2018out17151604_ICCP") {
    val results = testFlight("azul", "PRYRC", "CDC30001", "PRYRC_2018out17151604_ICCP", Util.getTime("2018-10-17 18:16:04.853"), Util.getTime("2018-10-17 22:03:32.633"))

    assert(results.contains("viewership_metrics_by_vod_content"))
    assert(results.contains("viewership_metrics_by_flight"))
    assert(results.contains("viewership_metrics_by_channel"))
    assert(results.contains("viewership_metrics_by_category"))
    assert(results.contains("viewership_metrics_by_program"))
    assert(!results.contains("viewership_metrics_by_roadblock"))

    var df = results("viewership_metrics_by_vod_content")
    assert(!df.head(1).isEmpty)
    assertNumbersClose(1201L, df.where("vod_metric_id = 'vod_total_time_viewed' and vod_id = 'Crazy, Stupid, Love'").head().getAs[Long]("vod_metric_value"))
    assertNumbersClose(0L, df.where("vod_metric_id = 'nb_completed_views' and vod_id = 'Crazy, Stupid, Love'").head().getAs[Long]("vod_metric_value"))
    assertNumbersClose(1L, df.where("vod_metric_id = 'vod_nb_unique_views' and vod_id = 'Crazy, Stupid, Love'").head().getAs[Long]("vod_metric_value"))
    assertNumbersClose(1229L, df.where("vod_metric_id = 'vod_total_time_viewed' and vod_id = 'Home Sweet Home?'").head().getAs[Long]("vod_metric_value"))

    df = results("viewership_metrics_by_flight")
    assertNumbersClose(1L, df.where("flight_metric_id = 'flight_total_nb_passengers'").head().getAs[Long]("flight_metric_value"))
    assertNumbersClose(1L, df.where("flight_metric_id = 'flight_max_simul_channels'").head().getAs[Long]("flight_metric_value"))
    assertNumbersClose(1L, df.where("flight_metric_id = 'flight_max_simul_avod'").head().getAs[Long]("flight_metric_value"))

    df = results("viewership_metrics_by_channel")
    assertNumbersClose(1537d, df.where("channel_metric_id = 'channel_total_dwell_time' and channel_name = 'Syfy'").head().getAs[Double]("channel_metric_value"))
    assertNumbersClose(1537d, df.where("channel_metric_id = 'channel_average_time_viewed' and channel_name = 'Syfy'").head().getAs[Double]("channel_metric_value"))
    assertNumbersClose(1.0d, df.where("channel_metric_id = 'channel_unique_views' and channel_name = 'Syfy'").head().getAs[Long]("channel_metric_value"))
    assertNumbersClose(0L, df.where("channel_metric_id = 'channel_viewed_to_completion' and channel_name = 'Syfy'").head().getAs[Long]("channel_metric_value"))
    // assertNumbersClose(2L, df.where("channel_metric_id = 'channel_unique_views_count' and channel_name = 'Syfy'").head().getAs[Long]("channel_metric_value"))
    assertNumbersClose(0L, df.where("channel_metric_id = 'channel_denied_count' and channel_name = 'Syfy'").head().getAs[Long]("channel_metric_value"))

    df = results("viewership_metrics_by_category")
    assertNumbersClose(1828d, df.where("category_metric_id = 'category_total_time_viewed' and category_id = 'Action' and media_type = 'AVOD'").head().getAs[Double]("category_metric_value"))
    assertNumbersClose(1d, df.where("category_metric_id = 'category_nb_unique_views' and category_id = 'Action' and media_type = 'AVOD'").head().getAs[Long]("category_metric_value"))

    df = results("viewership_metrics_by_program")
    assertNumbersClose(1264d, df.where("program_metric_id = 'program_total_time_viewed' and program_id = 'Sofia the First'").head().getAs[Double]("program_metric_value"))
    assertNumbersClose(1d, df.where("program_metric_id = 'program_nb_unique_views' and program_id = 'Sofia the First'").head().getAs[Double]("program_metric_value"))
  }
}
