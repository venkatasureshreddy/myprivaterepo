package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_PRYRD_20190307224300_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRD_20190307224300")

  test("Test PRYRA_2018Oct04104245_ICCP") {

    val results = testFlight("azul", "PRYRD", "51RPARBP", "PRYRD_20190307224300", Util.getTime("2019-03-07 22:43:56.514"), Util.getTime("2019-03-08 16:29:30.083"))

    assert(results.contains("viewership_metrics_by_roadblock"))

    val df = results("viewership_metrics_by_roadblock")
    assert(!df.head(1).isEmpty)
  }
}
