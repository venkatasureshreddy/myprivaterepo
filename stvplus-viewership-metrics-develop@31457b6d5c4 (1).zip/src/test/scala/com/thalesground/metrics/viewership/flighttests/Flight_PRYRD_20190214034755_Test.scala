package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_PRYRD_20190214034755_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRD_20190214034755")

  test("Test PRYRD_20190307224345") {

    val results = testFlight("azul", "DSUD2EOF1", "51RPATIL", "PRYRD_20190214034755", Util.getTime("2019-02-14 21:28:50.353"), Util.getTime("2019-02-14 22:10:23.975"))

    assert(results.contains("viewership_metrics_by_channel"))
    assert(results.contains("viewership_metrics_by_program"))
    assert(results.contains("viewership_metrics_by_roadblock"))
    assert(results.contains("viewership_metrics_by_category"))
    assert(results.contains("viewership_metrics_by_flight"))

    val df = results("viewership_metrics_by_program")
    assert(!df.head(1).isEmpty)
    val filteredDF = df.where("program_id = 'Around the Horn'")
    assert(!filteredDF.head(1).isEmpty)
    assert(!filteredDF.where("program_metric_id = 'program_total_time_viewed'").head(1).isEmpty)
    assertNumbersClose(436d, filteredDF.where("program_metric_id = 'program_total_time_viewed'").head().getAs[Double]("program_metric_value"))
    assert(!filteredDF.where("program_metric_id = 'program_viewed_to_completion'").head(1).isEmpty)
    assertNumbersClose(0L, filteredDF.where("program_metric_id = 'program_viewed_to_completion'").head().getAs[Long]("program_metric_value"))
  }
}
