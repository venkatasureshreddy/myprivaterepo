package com.thalesground.metrics.viewership.utils

import com.thalesground.metrics.viewership.ViewershipTestSuiteBase
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}

class FirstNonNullStringAggregateTest extends ViewershipTestSuiteBase {

  test("Test FirstNonNullStringAggregate") {
    val firstNonNull = new FirstNonNullStringAggregate
    val schema = StructType(List(StructField("col1", StringType, true), StructField("col2", StringType, true)))
    var actualDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row("a", "b"))), schema)
    actualDf = actualDf.groupBy("col2").agg(firstNonNull(actualDf.col("col1")).as("col1")).select("col1", "col2")
    var expectedDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row("a", "b"))), schema)
    assertDataFramesEqual(expectedDf, actualDf)

    actualDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row(null, "b"))), schema)
    actualDf = actualDf.groupBy("col2").agg(firstNonNull(actualDf.col("col1")).as("col1")).select("col1", "col2")
    expectedDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row(null, "b"))), schema)
    assertDataFramesEqual(expectedDf, actualDf)

    actualDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row(null, "b"), Row(null, "b"), Row("a", "b"))), schema)
    actualDf = actualDf.groupBy("col2").agg(firstNonNull(actualDf.col("col1")).as("col1")).select("col1", "col2")
    expectedDf = sqlContext.createDataFrame(sqlContext.sparkContext.parallelize(Seq(Row("a", "b"))), schema)
    assertDataFramesEqual(expectedDf, actualDf)
  }

}
