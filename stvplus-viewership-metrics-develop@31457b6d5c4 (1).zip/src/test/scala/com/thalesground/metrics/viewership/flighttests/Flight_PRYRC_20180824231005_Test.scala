package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

/**
  * Tests for HDP-8371
  */
class Flight_PRYRC_20180824231005_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRC_20180824231005")

  test("Test PRYRC_20180824231005") {
    /*
    this is also testing that all seat session data is retrieved, as log lines are from the 08/24/2018 partition, but log_departure_time is on 08/25/2018
    see ViewerShipContext.hiveKeys
     */
    val results = testFlight("azul", "PRYRC", "TEST29D", "PRYRC_20180824231005", Util.getTime("2018-08-25 06:09:30.315"), Util.getTime("2018-08-25 06:09:30.758"))

    assert(results.contains("viewership_metrics_by_program"))
    assert(results.contains("viewership_metrics_by_channel"))
    assert(results.contains("viewership_metrics_by_category"))

    var df = results("viewership_metrics_by_program")
    assert(!df.head(1).isEmpty)
    val filteredDF = df.where("program_id = 'Halloween: A Noite do Terror'")
    assert(!filteredDF.head(1).isEmpty)
    assert(!filteredDF.where("program_metric_id = 'program_total_time_viewed'").head(1).isEmpty)
    assertNumbersClose(827d, filteredDF.where("program_metric_id = 'program_total_time_viewed'").head().getAs[Double]("program_metric_value"))
    // assert(!filteredDF.where("program_metric_id = 'program_average_time_viewed'").head(1).isEmpty)
    // assertNumbersClose(827d, filteredDF.where("program_metric_id = 'program_average_time_viewed'").head().getAs[Double]("program_metric_value"))
    assert(!filteredDF.where("program_metric_id = 'program_viewed_to_completion'").head(1).isEmpty)
    assertNumbersClose(0L, filteredDF.where("program_metric_id = 'program_viewed_to_completion'").head().getAs[Long]("program_metric_value"))


    df = results("viewership_metrics_by_channel")
    assert(!df.head(1).isEmpty)
    assert(!df.where("channel_metric_id = 'channel_total_dwell_time' and channel_name = 'SPACE'").head(1).isEmpty)
    assertNumbersClose(827d, df.where("channel_metric_id = 'channel_total_dwell_time' and channel_name = 'SPACE'").head().getAs[Double]("channel_metric_value"))
    assert(!df.where("channel_metric_id = 'channel_average_time_viewed' and channel_name = 'SPACE'").head(1).isEmpty)
    assertNumbersClose(827d, df.where("channel_metric_id = 'channel_average_time_viewed' and channel_name = 'SPACE'").head().getAs[Double]("channel_metric_value"))
    assert(!df.where("channel_metric_id = 'channel_total_dwell_time' and channel_name = 'SYFY'").head(1).isEmpty)
    assertNumbersClose(43d, df.where("channel_metric_id = 'channel_total_dwell_time' and channel_name = 'SYFY'").head().getAs[Double]("channel_metric_value"))
    assert(df.where("channel_metric_id = 'channel_unique_views' and channel_name = 'SYFY'").head(1).isEmpty)

    //programs are all linked to specific categories - ie not null/Other
    df = results("viewership_metrics_by_category")
    assert(df.filter("category_id = 'Other'").head(1).isEmpty)

//    df = results("viewership_metrics_by_program")
//    for(categoryCsvRow <- df.select("channel_category").collect()) {
//      assert(!categoryCsvRow.getAs[String](0).contains("Other"))
//    }
  }
}
