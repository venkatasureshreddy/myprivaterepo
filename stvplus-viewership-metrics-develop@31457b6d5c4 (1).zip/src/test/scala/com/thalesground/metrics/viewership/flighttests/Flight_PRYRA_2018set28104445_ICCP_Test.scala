package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

/**
  * Test for HDP-8332 Maximum Simultaneous Videos/Channels
  */
class Flight_PRYRA_2018set28104445_ICCP_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRA_2018set28104445_ICCP")

  test("Test PRYRA_2018set28104445_ICCP") {

    val results = testFlight("azul", "PRYRA", "TMJ01124", "PRYRA_2018set28104445_ICCP", Util.getTime("2018-09-27 20:01:59.249"), Util.getTime("2018-09-27 20:54:14.032"))

    assert(results.contains("viewership_metrics_by_flight"))

    val df = results("viewership_metrics_by_flight")

    assert(!df.where("flight_metric_id = 'flight_max_simul_avod'").head(1).isEmpty)
    assertNumbersClose(2L, df.where("flight_metric_id = 'flight_max_simul_avod'").head().getAs[Long]("flight_metric_value"))

    assert(!df.where("flight_metric_id = 'flight_max_simul_channels'").head(1).isEmpty)
    assertNumbersClose(1L, df.where("flight_metric_id = 'flight_max_simul_channels'").head().getAs[Long]("flight_metric_value"))

    assert(!df.where("flight_metric_id = 'flight_total_nb_passengers'").head(1).isEmpty)
    assertNumbersClose(9L, df.where("flight_metric_id = 'flight_total_nb_passengers'").head().getAs[Long]("flight_metric_value"))
  }
}
