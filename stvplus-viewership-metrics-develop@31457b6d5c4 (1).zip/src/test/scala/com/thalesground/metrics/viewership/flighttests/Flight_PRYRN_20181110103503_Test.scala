package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util
import org.apache.spark.sql.Row

/**
  * Test for STVPLUS-1708 related to empty program_title
  * SEATSESSION.tsv is from flight PRYRN_20181110103503
  * ISD9E line 168 has an empty program_title - formerly this resulted in blank/null program_id data
  * There are also empty channel_id entries present which resulted in "Null" values
  * in Tableau Average Completion Rate By Channel and Channel Denied
  */
class Flight_PRYRN_20181110103503_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRN_20181110103503")

  test("Test PRYRN_20181110103503") {
    val results = testFlight("azul", "PRYRN", "AZU2588", "PRYRN_20181110103503", Util.getTime("2018-11-10 10:35:18.932"), Util.getTime("2018-11-11 16:38:18.970"))

    assert(results.contains("viewership_metrics_by_program"))
    assert(results.contains("viewership_metrics_by_channel"))
    assert(results.contains("viewership_metrics_by_category"))

    var df = results("viewership_metrics_by_program")
    val emptyProgramIdDf = df.filter("program_id is null or length(program_id) < 1")
    assert(emptyProgramIdDf.head(1).isEmpty)

    df = results("viewership_metrics_by_channel").filter("channel_id is null or length(channel_id) < 1 or channel_name is null or length(channel_name) < 1")
    assert(df.head(1).isEmpty)

    df = results("viewership_metrics_by_category").filter("category_id is null or length(category_id) < 1")
    assert(df.head(1).isEmpty)
  }
}
