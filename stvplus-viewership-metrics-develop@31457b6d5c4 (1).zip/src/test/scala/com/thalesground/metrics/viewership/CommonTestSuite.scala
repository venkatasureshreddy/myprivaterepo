package com.thalesground.metrics.viewership

import org.scalatest.FunSuite

class CommonTestSuite extends FunSuite {

  test("get flight_type") {
    assert("Domestic" == flight_type("US", "US"))
    assert("Domestic" == flight_type("US", "us"))
    assert("International" ==flight_type("US", "CA"))
    assert("N/A" == flight_type(null, "CA"))
    assert("N/A" == flight_type("US", null))
    assert("N/A" == flight_type(null, null))
  }
}
