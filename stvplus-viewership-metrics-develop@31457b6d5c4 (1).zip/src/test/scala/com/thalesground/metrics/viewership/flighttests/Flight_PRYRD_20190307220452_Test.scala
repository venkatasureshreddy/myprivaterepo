package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_PRYRD_20190307220452_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/PRYRD_20190307220452")

   test("Test PRYRD_20190307220452") {
     val results = testFlight("azul", "PRYRD", "51RPATBF", "PRYRD_20190307220452", Util.getTime("2019-03-07 22:43:56.514"), Util.getTime("2019-03-08 16:29:30.083"))

     var df = results("viewership_metrics_by_vod_content")
     assert(!df.head(1).isEmpty)
     val filteredDF = df.where("vod_id = 'Despicable Me 3'")
     assert(!filteredDF.head(1).isEmpty)
     assert(!filteredDF.where("vod_metric_id = 'vod_total_time_viewed'").head(1).isEmpty)
     assertNumbersClose(3638.878959d, filteredDF.where("vod_metric_id = 'vod_total_time_viewed'").head().getAs[Double]("vod_metric_value"))

     assert(results.contains("viewership_metrics_by_roadblock"))

     df = results("viewership_metrics_by_roadblock")
     assert(!df.head(1).isEmpty)
   }
}
