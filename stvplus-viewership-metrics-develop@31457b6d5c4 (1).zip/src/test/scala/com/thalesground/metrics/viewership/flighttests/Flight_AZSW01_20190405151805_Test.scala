package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_AZSW01_20190405151805_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/AZSW01_20190405151805")

   test("Test AZSW01_20190405151805") {
     val results = testFlight("azul", "AZSW01", "DSU01234", "AZSW01_20190405151805", Util.getTime("2019-04-05 11:51:19.000"), Util.getTime("2019-04-05 13:03:09.000"))

     assert(results.contains("viewership_metrics_by_vod_content"))
   }
}