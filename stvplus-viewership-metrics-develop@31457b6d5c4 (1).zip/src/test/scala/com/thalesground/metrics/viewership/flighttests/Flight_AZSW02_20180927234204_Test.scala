package com.thalesground.metrics.viewership.flighttests

import com.thalesground.metrics.viewership.common.Util

class Flight_AZSW02_20180927234204_Test extends FlightTestSuite {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/AZSW02_20180927234204")

   test("Test AZSW02_20180927234204") {
     val results = testFlight("azul", "AZSW02", "JMB10564", "AZSW02_20180927234204", Util.getTime("2018-09-27 20:54:17.953"), Util.getTime("2018-09-27 22:34:14.147"))

     assert(results.contains("viewership_metrics_by_program"))

     val df = results("viewership_metrics_by_program")
     assert(!df.head(1).isEmpty)

     assertNumbersClose(900d, df.where("program_id = 'Total DramaRama' and program_metric_id = 'program_total_time_viewed'").head().getAs[Double]("program_metric_value"))
  }
}