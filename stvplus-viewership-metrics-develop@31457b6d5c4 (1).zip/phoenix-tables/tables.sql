
create table if not exists main.viewership_metrics_by_flight(
    airline_id VARCHAR,
    flight_takeoff_time TIMESTAMP NOT NULL,
    flight_metric_id VARCHAR,
    tail_number VARCHAR,
    flight_id VARCHAR,
    seat_class VARCHAR,
    flight_type  VARCHAR,
    flight_day_period VARCHAR,
    flight_duration INTEGER,
    flight_date_arrival TIMESTAMP,
    flight_airport_origin VARCHAR,
    flight_airport_dest VARCHAR,
    flight_number VARCHAR,
    flight_aircraft_type VARCHAR,
    flight_metric_value FLOAT
    CONSTRAINT PK PRIMARY KEY (airline_id,flight_takeoff_time, flight_metric_id,tail_number,flight_id, seat_class)
);

create table if not exists main.viewership_metrics_by_channel(
    airline_id VARCHAR,
    flight_takeoff_time TIMESTAMP NOT NULL,
    channel_metric_id VARCHAR,
    tail_number VARCHAR,
    flight_id VARCHAR,
    seat_class VARCHAR,
    channel_id VARCHAR,
    flight_airport_origin VARCHAR,
    flight_airport_dest VARCHAR,
    flight_number VARCHAR,
    flight_type  VARCHAR,
    flight_day_period VARCHAR,
    flight_duration INTEGER,
    channel_name VARCHAR,
    channel_metric_value FLOAT
    CONSTRAINT PK PRIMARY KEY (airline_id,flight_takeoff_time, channel_metric_id,tail_number,flight_id,seat_class, channel_id)
);

create table if not exists main.viewership_metrics_by_program(
    airline_id VARCHAR,
    flight_takeoff_time TIMESTAMP NOT NULL,
    program_metric_id VARCHAR,
    tail_number VARCHAR,
    flight_id VARCHAR,
    seat_class VARCHAR,
    channel_id VARCHAR,
    program_id VARCHAR,
    flight_type  VARCHAR,
    flight_day_period VARCHAR,
    flight_duration INTEGER,
    flight_airport_origin VARCHAR,
    flight_airport_dest VARCHAR,
    flight_number VARCHAR,
    channel_name VARCHAR,
    channel_category VARCHAR,
    program_name VARCHAR,
    program_category VARCHAR,
    program_origin VARCHAR,
    program_duration INTEGER,
    program_metric_value FLOAT
    CONSTRAINT PK PRIMARY KEY (airline_id,flight_takeoff_time, program_metric_id,tail_number,flight_id,seat_class, channel_id,program_id)
);

create table if not exists main.viewership_metrics_by_vod_content(
    airline_id VARCHAR,
    flight_takeoff_time TIMESTAMP NOT NULL,
    vod_metric_id VARCHAR,
    tail_number VARCHAR,
    flight_id VARCHAR,
    seat_class VARCHAR,
    vod_id VARCHAR,
    flight_type  VARCHAR,
    flight_day_period VARCHAR,
    flight_duration INTEGER,
    flight_airport_origin VARCHAR,
    flight_airport_dest VARCHAR,
    flight_number VARCHAR,
    vod_name VARCHAR,
    vod_studio_source VARCHAR,
    vod_type VARCHAR,
    vod_category VARCHAR,
    vod_duration INTEGER,
    vod_metric_value FLOAT,
    CONSTRAINT PK PRIMARY KEY (airline_id,flight_takeoff_time, vod_metric_id,tail_number,flight_id,seat_class,vod_id)
);

create table if not exists main.viewership_metrics_by_category(
    airline_id VARCHAR,
    flight_takeoff_time TIMESTAMP NOT NULL,
    category_metric_id VARCHAR,
    tail_number VARCHAR,
    flight_id VARCHAR,
    seat_class VARCHAR,
    category_id VARCHAR,
    media_type VARCHAR,
    flight_airport_origin VARCHAR,
    flight_airport_dest VARCHAR,
    flight_number VARCHAR,
    flight_type  VARCHAR,
    flight_day_period VARCHAR,
    flight_duration INTEGER,
    category_metric_value FLOAT,
    CONSTRAINT PK PRIMARY KEY (airline_id, flight_takeoff_time,category_metric_id, tail_number,flight_id, seat_class, category_id, media_type)
);
create table if not exists main.viewership_metrics_by_roadblock(
    airline_id VARCHAR,
    flight_takeoff_time TIMESTAMP NOT NULL,
    roadblock_metric_id VARCHAR,
    tail_number VARCHAR,
    flight_id VARCHAR,
    seat_class VARCHAR,
    ad_id VARCHAR,
    roadblock_title VARCHAR,
    ad_title VARCHAR,
    category VARCHAR,
    roadblock_type VARCHAR,
    flight_airport_origin VARCHAR,
    flight_airport_dest VARCHAR,
    flight_number VARCHAR,
    flight_type  VARCHAR,
    flight_day_period VARCHAR,
    flight_duration INTEGER,
    roadblock_metric_value FLOAT,
    CONSTRAINT PK PRIMARY KEY (airline_id, flight_takeoff_time,roadblock_metric_id,tail_number,flight_id,seat_class, ad_id)
);
