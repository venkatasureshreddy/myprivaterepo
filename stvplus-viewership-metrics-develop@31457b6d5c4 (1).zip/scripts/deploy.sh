#!/bin/bash
## Usage: deploy [options] --principal PRINCIPAL --keytab KEYTAB --oozie OOZIEURL --properties JOBPROPERTIES
##
## Options:
##   -h, --help    Display this message.
##   -n            Dry-run; only show what would be done.
##

while [[ $# -gt 1 ]]
do
key="$1"

case $key in
        -p|--principal)
                PRINCIPAL="$2"
                shift # past argument
        ;;
        -k|--keytab)
                KEYTABPATH="$2"
                shift # past argument
        ;;
        -o|--oozie)
                OOZIE="$2"
                shift # past argument
        ;;
        --properties)
                PROPERTIESPATH="$2"
                shift # past argument
        ;;
        --hivecompactorconfig)
                HIVECOMPACTORCONFIG="$2"
        ;;
        *)
            # unknown option
        ;;
esac
shift # past argument or value
done

echo PRINCIAPL  = "${PRINCIPAL}"
echo KEY TAB     = "${KEYTABPATH}"
echo OOZIE    = "${OOZIE}"
echo PROPERTIES = "${PROPERTIESPATH}"
echo HIVECOMPACTORCONFIG = "${HIVECOMPACTORCONFIG}"

if [ -z "$PRINCIPAL" ]; then
	echo "ERROR: Kerberos principal required." && exit 1
fi

if [ -z "$KEYTABPATH" ]; then
	echo "ERROR: Keytab required." && exit 1
fi

if [ ! -f "$KEYTABPATH" ]; then
	echo "ERROR: Keytab file does not exist!" && exit 1
fi

if [ -z "$OOZIE" ]; then
	echo "ERROR: Oozie url required." && exit 1
fi

if [ -z "$PROPERTIESPATH" ]; then
	echo "ERROR: Properties file required." && exit 1
fi

if [ ! -f "$PROPERTIESPATH" ]; then
	echo "ERROR: Properties file does not exist!" && exit 1
fi

if [ -z "$HIVECOMPACTORCONFIG" ]; then
	echo "ERROR: Hive Compactor config file required." && exit 1
fi

if [ ! -f "$HIVECOMPACTORCONFIG" ]; then
	echo "ERROR: Hive Compactor config file does not exist!" && exit 1
fi

echo USER: `whoami`

echo "Creating ticket using principal and keytab."
kinit $PRINCIPAL -k -t $KEYTABPATH

echo "Attempting to kill existing coordinator deployment."
oozie jobs -oozie "$OOZIE" -jobtype coord -filter status=PREP | grep viewership_metrics_coordinator | awk '{print $1}' | xargs -r oozie job -oozie "$OOZIE" -kill
oozie jobs -oozie "$OOZIE" -jobtype coord -filter status=RUNNING | grep viewership_metrics_coordinator | awk '{print $1}' | xargs -r oozie job -oozie "$OOZIE" -kill

echo "Attempting to kill existing YARN apps that are not RUNNING."
for app in `yarn application -list -appStates NEW,NEW_SAVING,SUBMITTED,ACCEPTED | grep -E "viewership_metrics_coordinator|com.thalesground.metrics.viewership.ViewershipStarter" | awk '{ print $1 }'`; do yarn application -kill "$app";  done

echo "Creating application directory in HDFS."
hadoop fs -mkdir -p /opt/app/stvplus_viewership_metrics

echo "Copying application jar to HDFS."
mv lib/*.jar lib/viewership.jar
hadoop fs -put -f lib/viewership.jar /opt/app/stvplus_viewership_metrics/viewership.jar

echo "Copying oozie files to HDFS."
hadoop fs -put -f oozie/ /opt/app/stvplus_viewership_metrics/

echo "Copying keytab to HDFS."
hadoop fs -put -f $KEYTABPATH /opt/app/stvplus_viewership_metrics/oozie/service.keytab

echo "Copying hivecompactorconfig.json to HDFS."
hadoop fs -put -f $HIVECOMPACTORCONFIG /opt/app/stvplus_viewership_metrics/oozie/hivecompactorconfig.json

echo "Submitting coordinator to Oozie."
oozie job -oozie "$OOZIE" -config "$PROPERTIESPATH" -run -DstartTime=`date -u "+%Y-%m-%dT%H:%MZ"` -Dprincipal="$PRINCIPAL"