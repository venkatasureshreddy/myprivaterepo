#!/bin/bash

export SPARK_CLASSPATH="$SPARK_CLASSPATH:/usr/hdp/current/hbase-client/lib/hbase-common.jar:/usr/hdp/current/hbase-client/lib/hbase-client.jar:/usr/hdp/current/hbase-client/lib/hbase-server.jar:/usr/hdp/current/hbase-client/lib/hbase-protocol.jar:/usr/hdp/current/hbase-client/lib/guava-12.0.1.jar:/usr/hdp/current/hbase-client/lib/htrace-core-3.1.0-incubating.jar"

spark-submit \
	--files /usr/hdp/current/hbase-client/conf/hbase-site.xml,/usr/hdp/current/spark-client/conf/hive-site.xml \
	--conf spark.buffer.pageSize=8192000 \
	--executor-memory $1 \
	--driver-memory $2 \
	--num-executors $3 \
	--executor-cores $4 \
	--master yarn \
	--deploy-mode cluster \
	--jars  local:/usr/hdp/current/hbase-client/lib/hbase-common.jar,local:/usr/hdp/current/hbase-client/lib/hbase-client.jar,local:/usr/hdp/current/hbase-client/lib/hbase-protocol.jar,local:/usr/hdp/current/hbase-client/lib/guava-12.0.1.jar,local:/usr/hdp/current/hbase-client/lib/hbase-server.jar,local:/usr/hdp/current/hbase-client/lib/htrace-core-3.1.0-incubating.jar,local:/usr/hdp/current/phoenix-client/phoenix-client.jar,local:/usr/hdp/current/spark-client/lib/datanucleus-api-jdo-3.2.6.jar,local:/usr/hdp/current/spark-client/lib/datanucleus-core-3.2.10.jar,local:/usr/hdp/current/spark-client/lib/datanucleus-rdbms-3.2.9.jar \
	--keytab keytab \
	--principal $5 \
	--class com.thalesground.metrics.viewership.ViewershipStarter \
	 app.jar \
	-phoenixZkUrl $6 \
	-phoenixDatabase $7 \
	-zookeeperUrl $8 \
    -debugFlag $9 \
    -channelDwellTime ${10} \
    -avodDwellTime ${11} \
    -pctOfCompletion ${12} \
    -numOfFlightsToRun ${13} \
    -flightsPerBatch ${14} \
   	-smtpHost ${15} \
	-smtpPort ${16} \
	-emailFromAddress ${17} \
	-emailToAddresses ${18} \
	-smtpConnectTimeoutMillis ${19} \
	-smtpTimeoutMillis ${20} \
	-hiveCompactionOptionsJsonHdfsFilePath ${21} \
	-hiveCompactionLockBaseZooKeeperPath ${22}
