# tvs-etl-common

A library with common Spark ETL code

## Development
When making changes to this project in order to test in a separate project that uses this project, do the following:
* Change pom.xml version to something to indicate this a dev version, for example: 2.3.11_HDP-8460
* Run mvn install
* Change the other project pom.xml to point at the dev version

Remember to not commit the pom.xml version number change - it is just for local development.