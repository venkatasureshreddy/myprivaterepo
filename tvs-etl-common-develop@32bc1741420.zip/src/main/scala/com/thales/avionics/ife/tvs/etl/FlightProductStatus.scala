package com.thales.avionics.ife.tvs.etl

import org.apache.spark.sql.DataFrame

/**
 * Provides access to various views of the flight_product_status table.
 */
class FlightProductStatus(phoenix: PhoenixPersistence, maxNumOfFlightsPerRun: Int, filterConditions: Array[String]) {

  private val unfiltered = phoenix.load("flight_product_status")

  private var filtered = filterConditions.foldLeft(unfiltered)((df, condition) => df.filter(condition))
    .sort("LOG_DEPARTURE_TIME")
    .limit(maxNumOfFlightsPerRun)

  /**
   * Returns all rows of the flight_product_status.
   */
  def getUnfiltered(): DataFrame = unfiltered

  /**
   * Returns the rows of the flight_product_status table for flights that are pending for the current ETL execution.
   */
  def getFiltered(): DataFrame = filtered

  /**
   * Returns the rows of the flight_product_status table  for  input log_flight_id String
   */
  def getFilteredWithLogFilghtIds(logFlightIdString: String): DataFrame = {
    filterConditions.foldLeft(unfiltered)((df, condition) => df.filter(condition))
      .sort("LOG_DEPARTURE_TIME")
      .filter(s"LOG_FLIGHT_ID IN (${logFlightIdString})")
  }

}