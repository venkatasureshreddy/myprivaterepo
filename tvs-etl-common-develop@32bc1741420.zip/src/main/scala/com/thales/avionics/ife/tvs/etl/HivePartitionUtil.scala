package com.thales.avionics.ife.tvs.etl

import java.sql.Timestamp
import java.time.{Instant, LocalDateTime, ZoneId}

import org.apache.spark.sql.DataFrame

/**
  * Build a Hive sql where clause that filters by partition columns to avoid full table scans
  */
object HivePartitionUtil {

  private val UTC = ZoneId.of("UTC")

  def getHiveWhere(flightProductStatusDf: DataFrame): String = {
    //use sorted collections for deterministic behavior, which makes unit testing easier
    val logFlightIds = scala.collection.mutable.SortedSet[String]()
    val airlineMap = scala.collection.mutable.LinkedHashMap[String, YearMonthDayTree]()
    flightProductStatusDf
      .select("airline_id", "log_departure_time", "log_flight_id")
      .where("airline_id is not null and log_departure_time is not null and log_flight_id is not null")
      .collect().foreach(row => {
      val airline = row.getAs[String]("airline_id").toUpperCase()
      val logFlightId = row.getAs[String]("log_flight_id")
      val logDepartureTime = row.getAs[Timestamp]("log_departure_time")
      val yearMonthDayTreeOption = airlineMap.get(airline)
      var yearMonthDayTree: YearMonthDayTree = null
      if(yearMonthDayTreeOption.isDefined) {
        yearMonthDayTree = yearMonthDayTreeOption.get
      } else {
        yearMonthDayTree = new YearMonthDayTree()
        airlineMap.put(airline, yearMonthDayTree)
      }
      val date = timestampToDateTime(logDepartureTime)
      /*
      Log files from different sources tend to have different dates,
      which means they can end up in different partitions
      To be safe we query for the day before through the day after
       */
      yearMonthDayTree.add(date.minusDays(1))
      yearMonthDayTree.add(date)
      yearMonthDayTree.add(date.plusDays(1))
      logFlightIds.add(logFlightId)
    })
    getHiveWhere(logFlightIds.toSet, airlineMap.toMap)
  }

  def getHiveWhere(logFlightIds: scala.collection.mutable.Set[String],
                   airlineMap: scala.collection.mutable.Map[String, YearMonthDayTree]): String = {
    getHiveWhere(logFlightIds.toSet, airlineMap.toMap)
  }

  def getHiveWhere(logFlightIds: Set[String], airlineMap: Map[String, YearMonthDayTree]): String = {
    if(logFlightIds.isEmpty || airlineMap.isEmpty) {
      //returns no rows
      "false"
    } else {
      val ret = scala.collection.mutable.StringBuilder.newBuilder
      //sorting is to make behavior deterministic, which makes unit tests easier
      var firstAppend = true
      for ((airline, yearMonthDayTree) <- airlineMap) {
        if (firstAppend) {
          firstAppend = false
        } else {
          ret.append(" OR ")
        }
        ret.append("(logs.airline = '").append(airline).append("'").append(" AND ").append(yearMonthDayTree.toSqlQuery()).append(")")
      }
      ret.append(" AND logs.flight_id in (").append(quoteIterableToString(logFlightIds)).append(")")
      ret.toString()
    }
  }

  private def timestampToDateTime(ts: Timestamp): LocalDateTime = {
    LocalDateTime.ofInstant(Instant.ofEpochMilli(ts.getTime), UTC)
  }

  private def formatIterableToString(set: scala.collection.mutable.Iterable[Int], formatStr: String): String = {
    //sort so the order is deterministic, which makes unit testing easier
    set.map(value => value.formatted(formatStr)).map(value => "'" + value + "'").toList.sorted.mkString(",")
  }

  private def quoteIterableToString(set: Iterable[String]): String = {
    //sort so the order is deterministic, which makes unit testing easier
    set.map(value => "'" + value + "'").toList.sorted.mkString(",")
  }

  class YearMonthDayTree {

    //use SortedSet and LinkedHashMap so that order is deterministic, which makes unit testing easier

    private val yearMap = scala.collection.mutable.LinkedHashMap[Int, scala.collection.mutable.Map[Int, scala.collection.mutable.Set[Int]]]()

    def add(date: LocalDateTime): Unit = {
      add(date.getYear, date.getMonthValue, date.getDayOfMonth)
    }

    def add(year: Int, month: Int, day: Int): Unit = {
      var monthMapOption = yearMap.get(year)
      var monthMap: scala.collection.mutable.Map[Int, scala.collection.mutable.Set[Int]] = null
      if(monthMapOption.isDefined) {
        monthMap = monthMapOption.get
      } else {
        monthMap = scala.collection.mutable.LinkedHashMap[Int, scala.collection.mutable.Set[Int]]()
        yearMap.put(year, monthMap)
      }
      val dayMapOption = monthMap.get(month)
      var days: scala.collection.mutable.Set[Int] = null
      if(dayMapOption.isDefined) {
        days = dayMapOption.get
      } else {
        days = scala.collection.mutable.SortedSet[Int]()
        monthMap.put(month, days)
      }
      days.add(day)
    }

    def toSqlQuery(): String = {
      val ret = scala.collection.mutable.StringBuilder.newBuilder
      ret.append("(")
      var firstAppend = true
      for((year, monthMap) <- yearMap) {
        for((month, days) <- monthMap) {
          if(firstAppend) {
            firstAppend = false
          } else {
            ret.append(" OR ")
          }
          ret.append("(year = '").append(year.formatted("%04d")).append("' and ")
          ret.append("month = '").append(month.formatted("%02d")).append("' and ")
          ret.append("day in (").append(formatIterableToString(days, "%02d")).append("))")
        }
      }
      ret.append(")")
      ret.toString()
    }
  }

}

