package com.thales.avionics.ife.tvs.etl

import java.text.SimpleDateFormat
import java.util.{ Properties, TimeZone }
import javax.mail.{ Session, Transport }
import javax.mail.internet.{ InternetAddress, MimeMessage }
import org.slf4j.LoggerFactory
import java.net.InetAddress
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.Row
import org.apache.spark.sql.DataFrame
import scala.collection.Seq

/*
 * Most of this code taken from Missing flight logs  which was written by M.Friesen
http://mlbbitbucket:7990/projects/GTVS/repos/missinglogsnotification/browse/src/main/scala/com/thales/avionics/ife/tvs/MissingLogs.scala
*/

object ThalesEmailUtils {

  case class EmailConfig(smtpHost: String,
                         smtpPort: Int,
                         fromAddress: String,
                         destinationAddresses: Seq[String],
                         smtpConnectTimeoutMillis: java.lang.Long,
                         smtpTimeoutMillis: java.lang.Long)

  val flightsSchema: StructType = {
    val fields: Array[StructField] = Array[StructField](
      StructField("LOG_FLIGHT_ID", StringType, true),
      StructField("AIRLINE_NAME", StringType, true),
      StructField("TAIL_NUMBER", StringType, true),
      StructField("FLIGHT_NUMBER", StringType, true),
      StructField("LOG_ARRIVAL_TIME", TimestampType, true))
    new StructType(fields)
  }

  val logger = LoggerFactory.getLogger(getClass)

  def buildHtmlTable(rows: List[Row], Expection: String, Exception_msg: String): String = {
    val ret = new StringBuilder("<html><body><table border=\"1\">\n<tr><th>ID</th><th>Airline</th><th>Tail</th><th>Flight Number</th><th>Actual Arrival Time</th><th>Exception</th><th>Exception Msg</th></tr>\n")

    if (rows.size == 0) {
      ret.append("<tr>")
      appendTrOption(ret, Some(""))
      appendTrOption(ret, Some(""))
      appendTrOption(ret, Some(""))
      appendTrOption(ret, Some(""))
      appendTrOption(ret, Some(""))
      appendTrOption(ret, Some(Expection))
      appendTrOption(ret, Some(Exception_msg))
      ret.append("</tr>\n")
    } else {

      for (row <- rows) {
        val rowValMap = row.getValuesMap(Seq("LOG_FLIGHT_ID", "AIRLINE_NAME", "TAIL_NUMBER", "FLIGHT_NUMBER", "LOG_ARRIVAL_TIME"))
        ret.append("<tr>")
        appendTrOption(ret, rowValMap.get("LOG_FLIGHT_ID"))
        appendTrOption(ret, rowValMap.get("AIRLINE_NAME"))
        appendTrOption(ret, rowValMap.get("TAIL_NUMBER"))
        appendTrOption(ret, rowValMap.get("FLIGHT_NUMBER"))
        val actualArrivalTime: java.sql.Timestamp = rowValMap.get("LOG_ARRIVAL_TIME").get.asInstanceOf[java.sql.Timestamp]
        val dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"))
        appendTrOption(ret, Some(dateFormat.format(actualArrivalTime)))
        appendTrOption(ret, Some(Expection))
        appendTrOption(ret, Some(Exception_msg))
        ret.append("</tr>\n")
      }
    }
    ret.append("</table></body></html>")
    ret.toString()
  }

  def appendTrOption(sb: StringBuilder, option: Option[String]): StringBuilder = {
    sb.append("<td>")
    appendOption(sb, option)
    sb.append("</td>")
  }

  def appendOption(sb: StringBuilder, option: Option[String]): StringBuilder = {
    if (option.isDefined) {
      sb.append(option.get)
    }
    sb
  }

  import java.util.List
  def getListOfRowsFromDf(unscoredflights: DataFrame): List[Row] = {
    val unscoredflightsList = unscoredflights.collectAsList()
    unscoredflightsList

  }

  def sendEmail(unscoredflights: DataFrame, Expection: String, Exception_msg: String, emailSubject: String, emailConfig: Option[EmailConfig]): Unit = {
    val rows = getListOfRowsFromDf(unscoredflights)
    import scala.collection.JavaConversions._
    val scalarowsList = rows.toList
    val body = buildHtmlTable(scalarowsList, Expection, Exception_msg)
    sendEmail(body, emailSubject, emailConfig)
  }

  def sendEmail(body: String, emailSubject: String, emailConfig: Option[EmailConfig]) {
    val emailConfigVal = emailConfig.get
    val props = new Properties
    //see http://connector.sourceforge.net/doc-files/Properties.html
    props.put("mail.transport.protocol", "smtp")
    //these timeouts don't work unless they are Strings in the Properties
    props.put("mail.smtp.connectiontimeout", emailConfigVal.smtpConnectTimeoutMillis.toString)
    props.put("mail.smtp.timeout", emailConfigVal.smtpTimeoutMillis.toString)
    val session = Session.getDefaultInstance(props)
    val msg = new MimeMessage(session)

    //HostName is assigned to fromAddress  because, it might helpful in finding the exact environment  in which job is failed.
    val fromAddressHost = InetAddress.getLocalHost().getHostName()

    msg.setFrom(new InternetAddress(emailConfigVal.fromAddress, fromAddressHost))
    for (destinationAddress <- emailConfigVal.destinationAddresses) {
      msg.addRecipient(javax.mail.Message.RecipientType.TO, new InternetAddress(destinationAddress))
    }
    msg.setSubject(emailSubject)
    msg.setContent(body, "text/html")
    
    var transportOption: Option[Transport] = None
    try {
      val transport = session.getTransport
      transportOption = Some(transport)
      transport.connect(emailConfigVal.smtpHost, emailConfigVal.smtpPort, "", null)
      transport.sendMessage(msg, msg.getAllRecipients)
    } catch {
      case ex: Exception => logger.error("Error sending email", ex)
        } finally {
      if (transportOption.isDefined) {
        transportOption.get.close()
      }
    }
  }

}