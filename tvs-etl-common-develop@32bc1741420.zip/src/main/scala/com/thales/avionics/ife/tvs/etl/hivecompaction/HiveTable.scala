package com.thales.avionics.ife.tvs.etl.hivecompaction

case class HiveTable(name: String, baseHdfsDir: String) {
  require(name != null, "Invalid name")
  require(baseHdfsDir != null, "Invalid baseHdfsDir")
}
