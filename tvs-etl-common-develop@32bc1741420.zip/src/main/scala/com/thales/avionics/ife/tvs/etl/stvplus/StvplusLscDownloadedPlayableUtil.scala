package com.thales.avionics.ife.tvs.etl.stvplus

import com.google.gson._
import org.apache.log4j.Logger

import scala.collection.JavaConverters

/**
  * See STVPLUS-2154 and STVPLUS-2154
  * STV+ EIS4 aircraft software does not calculate downloaded_hv_content_percentage and playable_hv_content_percentage
  * correctly, so this code computes it from the hv_content_list as a workaround
  */
object StvplusLscDownloadedPlayableUtil {

  case class LscDownloadedPlayable(downloadedPct: java.lang.Double,
                                   downloadedPctCalculatedFromHvContentList: Boolean,
                                   playablePct: java.lang.Double,
                                   playablePctCalculatedFromHvContentList: Boolean,
                                   downloadedAndPlayablePct: java.lang.Double)

  private val logger = Logger.getLogger(getClass().getName())

  /**
    * Calculate the LSC Downloaded and Playable values from hv_status_report json
    * for use by parseLscDownloaded() and parseLscPlayable()
    * @param hvStatusReportJson hv_status_report json
    * @return LscDownloadedPlayable
    */
  def parseLscDownloadedPlayable(hvStatusReportJson: String): LscDownloadedPlayable = {
    var downloadedPct: java.lang.Double = null
    var downloadedPctCalculatedFromHvContentList: Boolean = false
    var playablePct: java.lang.Double = null
    var playablePctCalculatedFromHvContentList: Boolean = false
    var downloadedAndPlayablePct: java.lang.Double = null
    try {
      if (hvStatusReportJson != null && !hvStatusReportJson.isEmpty) {
        val jsonParser = new JsonParser()
        val hvStatusReport = jsonParser.parse(hvStatusReportJson)
        if (hvStatusReport.isJsonObject) {
          val hvStatusReportObj = hvStatusReport.getAsJsonObject
          downloadedPct = safeToDouble(getOptionalPrimitiveMember(hvStatusReportObj, "downloaded_hv_content_percentage"))
          val calcDownloadedPctFromHvContentList = calculatePctFromHvContentList(downloadedPct)
          playablePct = safeToDouble(getOptionalPrimitiveMember(hvStatusReportObj, "playable_hv_content_percentage"))
          val calcPlayablePctFromHvContentList = calculatePctFromHvContentList(playablePct)
          if(calcDownloadedPctFromHvContentList || calcPlayablePctFromHvContentList) {
            val hvContentList = hvStatusReportObj.get("hv_content_list")
            if (hvContentList != null && hvContentList.isJsonArray) {
              val hvContentListCounts = getHvContentListCounts(hvContentList.getAsJsonArray)
              if (hvContentListCounts.totalCnt > 0) {
                if(calcDownloadedPctFromHvContentList) {
                  downloadedPct = hvContentListCounts.downloadedCnt.toDouble / hvContentListCounts.totalCnt.toDouble
                  downloadedPctCalculatedFromHvContentList = true
                }
                if(calcPlayablePctFromHvContentList) {
                  playablePct = hvContentListCounts.playableCnt.toDouble / hvContentListCounts.totalCnt.toDouble
                  playablePctCalculatedFromHvContentList = true
                }
                downloadedAndPlayablePct = hvContentListCounts.downloadedAndPlayableCnt.toDouble / hvContentListCounts.totalCnt.toDouble
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => {
        //don't let this cause further exceptions
        logger.error(s"Error parsing hv_status_report: $hvStatusReportJson", e)
      }
    }
    LscDownloadedPlayable(downloadedPct, downloadedPctCalculatedFromHvContentList,
      playablePct, playablePctCalculatedFromHvContentList, downloadedAndPlayablePct)
  }

  private def getOptionalPrimitiveMember(jsonObj: JsonObject, member: String): String = {
    var ret: String = null
    if(jsonObj != null) {
      val memberJson = jsonObj.get(member)
      if(memberJson != null && memberJson.isJsonPrimitive) {
        ret = memberJson.getAsJsonPrimitive.getAsString
      }
    }
    ret
  }

  private def safeToDouble(str: String): java.lang.Double = {
    var ret: java.lang.Double = null
    if(str != null && !str.isEmpty && !"null".equalsIgnoreCase(str)) {
      try {
        ret = str.toDouble
      } catch {
        case e: Exception => {
          logger.debug(s"Could not parse $str", e)
        }
      }
    }
    ret
  }

  private def calculatePctFromHvContentList(pct: java.lang.Double): Boolean = {
    var calculateFromHvContentList = true
    if(pct != null && pct < 0) {
      /*
      If downloaded/playablePct is -1, then the ISD is in an unknown state, so leave as -1
      If >= 0, then the ISD can produce an incorrect value, so calculate from hv_content_list
       */
      calculateFromHvContentList = false
    }
    calculateFromHvContentList
  }

  private case class HvContentListCounts(downloadedCnt: Int, playableCnt: Int, downloadedAndPlayableCnt: Int, totalCnt: Int)

  private case class HvContentStatus(var downloaded: Boolean, var playable: Boolean)

  private def getHvContentListCounts(hvContentList: JsonArray): HvContentListCounts = {
    /*
    STVPLUS-2201 - A/C may report the same content_id status multiple times
    If any of the statuses for a given content_id is false, we treat the status as false
     */
    val contentIdStatusMap = scala.collection.mutable.HashMap[String, HvContentStatus]()
    for (hvContent <- JavaConverters.iterableAsScalaIterableConverter(hvContentList.getAsJsonArray).asScala) {
      val hvContentElem = hvContent.asInstanceOf[JsonElement]
      if (hvContentElem.isJsonObject) {
        val hvContentObj = hvContentElem.getAsJsonObject
        val contentId = getOptionalPrimitiveMember(hvContentObj, "content_id")
        if(contentId != null) {
          var downloaded = "true".equalsIgnoreCase(getOptionalPrimitiveMember(hvContentObj, "downloaded"))
          val playable = "true".equalsIgnoreCase(getOptionalPrimitiveMember(hvContentObj, "license_available"))
          val existingDownloadedPlayableOption = contentIdStatusMap.get(contentId)
          val downloadedPlayable: HvContentStatus = HvContentStatus(downloaded, playable)
          if(existingDownloadedPlayableOption.isDefined) {
            val existingDownloadedPlayable = existingDownloadedPlayableOption.get
            downloadedPlayable.downloaded = existingDownloadedPlayable.downloaded && downloaded
            downloadedPlayable.playable = existingDownloadedPlayable.playable && playable
          }
          contentIdStatusMap.put(contentId, downloadedPlayable)
        }
      }
    }
    var downloadedCnt = 0
    var playableCnt = 0
    var downloadedAndPlayableCnt = 0
    var totalCnt = 0
    for((contentId, status) <- contentIdStatusMap) {
      if(status.downloaded) {
        downloadedCnt = downloadedCnt + 1
      }
      if(status.playable) {
        playableCnt = playableCnt + 1
      }
      if(status.downloaded && status.playable) {
        downloadedAndPlayableCnt = downloadedAndPlayableCnt + 1
      }
      totalCnt = totalCnt + 1
    }
    HvContentListCounts(downloadedCnt, playableCnt, downloadedAndPlayableCnt, totalCnt)
  }

  def serialize(lscDownloadedPlayable: StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable): String = {
    new Gson().toJson(lscDownloadedPlayable)
  }

  def deserialize(json: String): StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable = {
    new Gson().fromJson(json, classOf[StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable])
  }
}
