package com.thales.avionics.ife.tvs.etl.hivecompaction

import java.util.concurrent.TimeUnit

class HiveCompactorLockOptions {

  var lockZooKeeperUrl: String = _
  var lockBaseZooKeeperPath: String = _
  var lockBaseSleepMillis: Int = TimeUnit.SECONDS.toMillis(5).toInt
  var lockMaxSleepMillis: Int = TimeUnit.SECONDS.toMillis(5).toInt
  var lockMaxRetries = 5
  var lockAcquireTimeoutSeconds: Int = TimeUnit.MINUTES.toSeconds(15).toInt

  override def toString: String = s"HiveCompactorLockOptions(" +
    s"lockZooKeeperUrl=$lockZooKeeperUrl, " +
    s"lockBaseZooKeeperPath=$lockBaseZooKeeperPath, " +
    s"lockBaseSleepMillis=$lockBaseSleepMillis, " +
    s"lockMaxSleepMillis=$lockMaxSleepMillis, " +
    s"lockMaxRetries=$lockMaxRetries, " +
    s"lockAcquireTimeoutSeconds=$lockAcquireTimeoutSeconds)"
}
