package com.thales.avionics.ife.tvs.etl

import org.apache.spark.sql.Column
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.expressions.Window

object TimeSeriesTransformations {

  /**
   * DataFrame transformer that produces a DataFrame that includes:
   * - the first and last records for each "partition" (based on the keys)
   * - records that demonstrate a change in any of the value columns from the previous or next records in the same partition
   *
   * See the corresponsing unit test for more info.
   */
  def reduceNoise(timestamp: Column, keys: Seq[Column], values: Seq[Column])(df: DataFrame): DataFrame = {

    import df.sqlContext.implicits._

    val defaultHashCode = 0

    val hashCodeUdf = udf[Int, String](_.hashCode())
    val window = Window.partitionBy(keys: _*).orderBy(timestamp)

    val changes = df.withColumn("values_concatenated", concat_ws("%", values: _*))
      .withColumn("current_hashcode", hashCodeUdf.apply($"values_concatenated"))
      .drop($"values_concatenated")
      .withColumn("previous_hashcode", lag("current_hashcode", 1, defaultHashCode).over(window))
      .withColumn("next_hashcode", lead("current_hashcode", 1, defaultHashCode).over(window))
      .filter(($"previous_hashcode" !== $"current_hashcode") || ($"next_hashcode" !== $"current_hashcode"))

    val allSelectors = Seq(timestamp) ++ keys ++ values
    changes.select(allSelectors: _*)
  }
  
  /**
   * DataFrame transformer that produces a DataFrame that includes:
   * - the first and last records for each "partition" (based on the keys)
   * - on change records
   *
   * See the corresponsing unit test for more info.
   */
  def firstLastOnChange(timestamp: Column, keys: Seq[Column], values: Seq[Column])(df: DataFrame): DataFrame = {

    import df.sqlContext.implicits._

    val defaultHashCode = 0
    val allSelectors = keys ++ values ++ Seq(timestamp)
    val hashCodeUdf = udf[Int, String](_.hashCode())
    val window = Window.partitionBy(keys: _*).orderBy(timestamp)

    val changes = df.withColumn("values_concatenated", concat_ws("%", values: _*))
      .withColumn("current_hashcode", hashCodeUdf.apply($"values_concatenated"))
      .drop($"values_concatenated")
      .withColumn("previous_hashcode", lag("current_hashcode", 1, defaultHashCode).over(window))
      .filter($"previous_hashcode" !== $"current_hashcode").drop($"current_hashcode").drop($"previous_hashcode").select(allSelectors: _*)

     val lastRecord = df.select(allSelectors: _*).join(df.sort(timestamp.desc).groupBy(keys: _*).agg(max(timestamp.toString()).alias("ts")),  keys.toArray.map(_.toString()).toSeq ++ Seq(timestamp.toString())).select(allSelectors: _*)

     changes.unionAll(lastRecord).distinct()  
  }

}