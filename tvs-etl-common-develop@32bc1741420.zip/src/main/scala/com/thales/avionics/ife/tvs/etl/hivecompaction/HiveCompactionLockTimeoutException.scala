package com.thales.avionics.ife.tvs.etl.hivecompaction

/**
  * Exception to indicate that lock acquisition timed out
  */
class HiveCompactionLockTimeoutException(tableName: String, lockType: LockType.Value) extends RuntimeException("Lock timeout for " + tableName + " " + lockType) {

  def getTableName(): String = tableName

  def getLockType(): LockType.Value = lockType

}