package com.thales.avionics.ife.tvs.etl

import org.apache.curator.framework.CuratorFramework
import org.apache.curator.framework.recipes.locks.InterProcessMutex
import org.apache.curator.RetryPolicy
import org.apache.curator.retry.ExponentialBackoffRetry
import org.apache.curator.framework.CuratorFrameworkFactory
import java.io.Closeable
import org.apache.curator.framework.recipes.locks.InterProcessReadWriteLock
import org.apache.hadoop.hive.metastore.api.ThriftHiveMetastore.Processor.lock
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import org.apache.log4j.Logger

class HiveSchemaLocker(zookeeperUrl: String, hiveSchema: String) extends Closeable {
  
  val logger = Logger.getLogger(getClass().getName());

  private val baseSleep = 500
  private val maxRetries = 5
  private val lockTimeout = 60 * 10

  val client = CuratorFrameworkFactory.newClient(
    zookeeperUrl,
    new ExponentialBackoffRetry(baseSleep, maxRetries))
  client.start()

  private val lock = new InterProcessReadWriteLock(client, s"/thales/hive/${hiveSchema}/locks")

  def acquireReadLock() {
    logger.info(s"acquiring read lock on hive schema '${hiveSchema}'")
    if (!lock.readLock().acquire(lockTimeout, TimeUnit.SECONDS)) {
      throw new TimeoutException(s"Failed to acquire read lock on hive schema '${hiveSchema}' within ${lockTimeout} seconds")
    }
  }

  def acquireWriteLock() {
    logger.info(s"acquiring write lock on hive schema '${hiveSchema}'")
    if (!lock.writeLock().acquire(lockTimeout, TimeUnit.SECONDS)) {
      throw new TimeoutException(s"Failed to acquire write lock on hive schema '${hiveSchema}' within ${lockTimeout} seconds")
    }
  }

  def releaseReadLock() {
    logger.info(s"releasing read lock on hive schema '${hiveSchema}'")
    lock.readLock().release()
  }

  def releaseWriteLock() {
    logger.info(s"releasing write lock on hive schema '${hiveSchema}'")
    lock.writeLock().release()
  }

  override def close() {
    client.close()
  }
}