package com.thales.avionics.ife.tvs.etl.hivecompaction

class HiveCompactorTableOptions {

  var compressCompactedFiles = true
  var minFilesToCompact = 3
  var maxDaysAgoToProcess = 60
  var minMinutesForRecentlyWrittenFiles = 30
  var maxFileSizeBytesToCompact = 209715200 //200MB
  var alwaysCompactFilesSizeSmallerThanBytes = -1
  var maxFilesPerDirectory = 100

  override def toString: String = s"HiveCompactorTableOptions(" +
    s"compressCompactedFiles=$compressCompactedFiles," +
    s"minFilesToCompact=$minFilesToCompact," +
    s"maxDaysAgoToProcess=$maxDaysAgoToProcess," +
    s"minMinutesForRecentlyWrittenFiles=$minMinutesForRecentlyWrittenFiles," +
    s"maxFileSizeBytesToCompact=$maxFileSizeBytesToCompact," +
    s"alwaysCompactFilesSizeSmallerThanBytes=$alwaysCompactFilesSizeSmallerThanBytes," +
    s"maxFilesPerDirectory=$maxFilesPerDirectory)"
}
