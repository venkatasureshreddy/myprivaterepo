package com.thales.avionics.ife.tvs.etl

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.SQLContext

class PhoenixPersistence(sqlContext: SQLContext, zkUrl: String, schema: String) {

  def load(table: String): DataFrame = sqlContext.load("org.apache.phoenix.spark", Map("zkUrl" -> zkUrl, "table" -> s"${schema}.${table}"))

  def save(df: DataFrame, table: String) = {
    println(s"schema for df writing to ${schema}.${table} = ${df.schema.fields.map(_.toString()).mkString(",")}")
	  sqlContext.sparkContext.setLocalProperty("callSite.short", s"writing to ${schema}.${table}")

    df.write.format("org.apache.phoenix.spark").mode("overwrite").options(
      Map(
        "zkUrl" -> zkUrl,
        "table" -> s"${schema}.${table}"
        )
      ).save()

    sqlContext.sparkContext.setLocalProperty("callSite.short", null)
  }
}