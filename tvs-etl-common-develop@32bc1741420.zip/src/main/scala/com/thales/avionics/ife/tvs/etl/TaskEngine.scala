package com.thales.avionics.ife.tvs.etl

import java.io.Closeable
import java.util.concurrent.{BlockingQueue, LinkedBlockingQueue, TimeUnit}
import java.util.concurrent.atomic.{AtomicBoolean, AtomicReference}

import scala.util.control.Breaks._

import org.slf4j.{Logger, LoggerFactory}

object TaskEngine {

  val QUIT_MSG: Runnable = new Runnable {
    override def run(): Unit = {}
  }
  val LOGGER: Logger = LoggerFactory.getLogger(classOf[TaskEngine])

}

/**
  * Manages running tasks on background threads
  */
class TaskEngine(val numThreads: Int, val queueCapacity: Int, val maxCloseWaitMillis: Int) extends Closeable {

  private var workQueue: BlockingQueue[Runnable] = _
  private var threads: Array[Thread] = _
  private val isShutdown: AtomicBoolean = new AtomicBoolean(false)
  private val lastExceptionRef: AtomicReference[Exception] = new AtomicReference[Exception]

  TaskEngine.LOGGER.info("Init: " + numThreads + " " + queueCapacity + " " + maxCloseWaitMillis)
  if (numThreads > 1) {
    workQueue = new LinkedBlockingQueue[Runnable](queueCapacity)
    threads = new Array[Thread](numThreads)
    var i: Int = 0
    for(i <- 0 until numThreads) {
      val thread: Thread = new Thread(new Runnable {
        override def run(): Unit = {
          breakable {
            while (!isShutdown.get) {
              var task: Runnable = null
              try {
                task = workQueue.take
              } catch {
                case e: InterruptedException => {
                  TaskEngine.LOGGER.error("Worker interrupted", e)
                  Thread.currentThread.interrupt()
                  break
                }
              }
              if (TaskEngine.QUIT_MSG eq task) {
                TaskEngine.LOGGER.info("Received quit message")
                break
              }
              try {
                task.run()
              } catch {
                case e: Exception =>
                  TaskEngine.LOGGER.error("Error processing task", e)
                  //don't kill the thread by propagating the Exception
                  lastExceptionRef.set(e)
              }
            }
          }
        }
        TaskEngine.LOGGER.info("Exiting")
      })
      thread.start()
      threads(i) = thread
    }
  }
  else {
    workQueue = null
    threads = null
  }

  def queue(task: () => Unit): Unit = {
    queue(new Runnable {
      override def run(): Unit = {
        task.apply()
      }
    })
  }

  def queue(task: Runnable): Unit = {
    if (workQueue != null) {
      try {
        workQueue.put(task)
      } catch {
        case e: InterruptedException =>
          throw new RuntimeException(e)
      }
    }
    else {
      task.run()
    }
  }

  def waitForFinished(): Unit = {
    TaskEngine.LOGGER.info("waitForFinished")
    if (threads != null) {
      for (ignored <- threads) {
        workQueue.put(TaskEngine.QUIT_MSG)
      }
      for (thread <- threads) {
        thread.join()
      }
    }
    isShutdown.set(true)
    val lastException: Exception = lastExceptionRef.get
    if (lastException != null) {
      throw lastException
    }
  }

  override def close(): Unit = {
    if (!isShutdown.get) {
      TaskEngine.LOGGER.info("Closing")
      isShutdown.set(true)
      if (threads != null) {
        try {
          val maxWaitMillisPerThread: Long = maxCloseWaitMillis / threads.length
          for (ignored <- threads) {
            workQueue.offer(TaskEngine.QUIT_MSG, maxWaitMillisPerThread, TimeUnit.MILLISECONDS)
          }
        } catch {
          case e: InterruptedException =>
            Thread.currentThread.interrupt()
            throw new RuntimeException(e)
        }
        //this purposefully does not wait for threads to finish
      }
    }
  }
}