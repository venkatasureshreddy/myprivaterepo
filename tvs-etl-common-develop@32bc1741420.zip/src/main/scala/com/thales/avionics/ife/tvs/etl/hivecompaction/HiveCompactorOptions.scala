package com.thales.avionics.ife.tvs.etl.hivecompaction

import java.lang.reflect.Type

import com.google.common.annotations.VisibleForTesting
import com.google.gson._
import org.apache.hadoop.conf.Configuration

class HiveCompactorOptions {

  var conf: Configuration = _
  var tmpDir = "/tmp"
  var numThreads = 1
  var queueCapacity = 1000
  var taskEngineMaxCloseWaitMillis = 10000
  var ignoreErrors = false
  //only check for matches - doesn't actually write anything
  var trialMode = false
  //if true compaction will not be run, only msck
  var msckOnly = false
  var hiveDatabase: String = _

  var hiveTables: Seq[HiveTable] = _
  var defaultHiveTableOptions: HiveCompactorTableOptions = _
  var hiveTableOptions: Map[String, HiveCompactorTableOptions] = _

  var lockOptions: HiveCompactorLockOptions = _

  override def toString: String = s"HiveCompactorOptions(" +
    s"conf=$conf, " +
    s"tmpDir=$tmpDir, " +
    s"numThreads=$numThreads," +
    s"queueCapacity=$queueCapacity, " +
    s"taskEngineMaxCloseWaitMillis=$taskEngineMaxCloseWaitMillis, " +
    s"ignoreErrors=$ignoreErrors," +
    s"trialMode=$trialMode, " +
    s"msckOnly=$msckOnly, " +
    s"hiveDatabase=$hiveDatabase, " +
    s"hiveTables=$hiveTables, " +
    s"defaultHiveTableOptions=$defaultHiveTableOptions, " +
    s"hiveTableOptions=$hiveTableOptions," +
    s"lockOptions=$lockOptions)"
}

object HiveCompactorOptions {

  class SeqHiveTableJsonDeserializer extends JsonDeserializer[Seq[HiveTable]] {
    override def deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): Seq[HiveTable] = {
      val ret = new scala.collection.mutable.ArrayBuffer[HiveTable]()
      require(json.isJsonArray)
      val iter = json.getAsJsonArray.iterator()
      while(iter.hasNext) {
        val tableElem = iter.next.getAsJsonObject
        val nameElem = tableElem.get("name")
        require(nameElem != null, "Invalid HiveTable name")
        val baseHdfsDirElem = tableElem.get("baseHdfsDir")
        require(baseHdfsDirElem != null, "Invalid HiveTable name")
        ret.append(HiveTable(nameElem.getAsString, baseHdfsDirElem.getAsString))
      }
      ret.toList
    }
  }

  class StringMapHiveCompactorTableOptionsJsonDeserializer extends JsonDeserializer[Map[String, HiveCompactorTableOptions]] {
    override def deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): Map[String, HiveCompactorTableOptions] = {
      val ret = new scala.collection.mutable.HashMap[String, HiveCompactorTableOptions]()
      require(json.isJsonObject)
      val entrySetIter = json.getAsJsonObject.entrySet().iterator()
      while(entrySetIter.hasNext) {
        val entry = entrySetIter.next()
        val tableName = entry.getKey
        require(tableName != null, "Invalid tableName")
        val optionsObj = entry.getValue
        require(optionsObj != null, "Invalid optionsObj")
        ret.put(tableName, context.deserialize(optionsObj, classOf[HiveCompactorTableOptions]))
      }
      ret.toMap
    }
  }

  private val gson = new GsonBuilder()
    .registerTypeAdapter(classOf[Seq[HiveTable]], new SeqHiveTableJsonDeserializer())
    .registerTypeAdapter(classOf[Map[String, HiveCompactorTableOptions]], new StringMapHiveCompactorTableOptionsJsonDeserializer())
    .create()

  def fromJson(json: String): HiveCompactorOptions = {
    var ret: HiveCompactorOptions = null
    if(json != null) {
      ret = gson.fromJson(json, classOf[HiveCompactorOptions])
    }
    if(ret == null) {
      ret = new HiveCompactorOptions()
    }
    ret
  }

  def parseArgNameValues(args: Array[String]): Map[String, String] = {
    val ret = new scala.collection.mutable.HashMap[String, String]
    var i = 0
    while ( {
      i < args.length
    }) {
      val argName = args(i)
      require(i < args.length - 1, "Missing " + argName + " value")
      val argValue = args({
        i += 1; i
      })
      ret.put(argName, argValue)

      {
        i += 1; i - 1
      }
    }
    ret.toMap
  }

  private def validString(s: String) = s != null && !s.isEmpty && !("null" == s)

  @VisibleForTesting
  def safeGetArgString(s: Option[String], defaultValue: String): String = {
    if (s.isDefined) {
      safeGetArgString(s.get, defaultValue)
    } else {
      defaultValue
    }
  }

  private def safeGetArgString(s: String, defaultValue: String): String = {
    var ret = defaultValue
    if (validString(s)) ret = s
    ret
  }

  @VisibleForTesting
  def safeParseInt(s: Option[String], defaultValue: Int): Int = {
    if (s.isDefined) {
      safeParseInt(s.get, defaultValue)
    } else {
      defaultValue
    }
  }

  private def safeParseInt(s: String, defaultVal: Int): Int = {
    var ret = defaultVal
    if (validString(s)) ret = s.toInt
    ret
  }

  @VisibleForTesting
  def safeParseBoolean(s: Option[String], defaultValue: Boolean): Boolean = {
    if (s.isDefined) {
      safeParseBoolean(s.get, defaultValue)
    } else {
      defaultValue
    }
  }

  private def safeParseBoolean(s: String, defaultValue: Boolean): Boolean = {
    var ret = defaultValue
    if (validString(s)) {
      ret = "true".equalsIgnoreCase(s)
    }
    ret
  }

  private def parseHiveTablesFromArgs(argNameValues: Map[String, String]) = {
    val hiveTablesCsv = argNameValues("-tables")
    val ret = new scala.collection.mutable.ArrayBuffer[HiveTable]
    for (tableAndHdfsPath <- hiveTablesCsv.split(",")) {
      val tableSplit = tableAndHdfsPath.split("::")
      require(tableSplit.length == 2, "Invalid table and hdfs path: " + tableAndHdfsPath)
      ret.append(HiveTable(tableSplit(0), tableSplit(1)))
    }
    ret
  }

  def parseFromArgs(argNameValues: Map[String, String]): HiveCompactorOptions = {
    val options = new HiveCompactorOptions
    options.conf = new Configuration
    options.hiveTables = parseHiveTablesFromArgs(argNameValues)
    options.tmpDir = safeGetArgString(argNameValues.get("-tmpDir"), options.tmpDir)
    options.numThreads = safeParseInt(argNameValues.get("-threads"), options.numThreads)
    options.queueCapacity = safeParseInt(argNameValues.get("-queueCapacity"), options.queueCapacity)
    options.taskEngineMaxCloseWaitMillis = safeParseInt(argNameValues.get("-taskEngineMaxCloseWaitMillis"), options.taskEngineMaxCloseWaitMillis)
    options.ignoreErrors = safeParseBoolean(argNameValues.get("-ignoreErrors"), options.ignoreErrors)
    options.trialMode = safeParseBoolean(argNameValues.get("-trialMode"), options.trialMode)
    options.msckOnly = safeParseBoolean(argNameValues.get("-msckOnly"), options.msckOnly)
    options.hiveDatabase = safeGetArgString(argNameValues.get("-hiveDatabase"), options.hiveDatabase)
    //note that this only sets default table options, not per table options
    options.defaultHiveTableOptions = new HiveCompactorTableOptions
    options.defaultHiveTableOptions.compressCompactedFiles = safeParseBoolean(argNameValues.get("-compress"), options.defaultHiveTableOptions.compressCompactedFiles)
    options.defaultHiveTableOptions.minFilesToCompact = safeParseInt(argNameValues.get("-minFilesToCompact"), options.defaultHiveTableOptions.minFilesToCompact)
    options.defaultHiveTableOptions.maxDaysAgoToProcess = safeParseInt(argNameValues.get("-maxDaysAgoToProcess"), options.defaultHiveTableOptions.maxDaysAgoToProcess)
    options.defaultHiveTableOptions.minMinutesForRecentlyWrittenFiles = safeParseInt(argNameValues.get("-minMinutesForRecentlyWrittenFiles"), options.defaultHiveTableOptions.minMinutesForRecentlyWrittenFiles)
    options.defaultHiveTableOptions.maxFileSizeBytesToCompact = safeParseInt(argNameValues.get("-maxFileSizeBytesToCompact"), options.defaultHiveTableOptions.maxFileSizeBytesToCompact)
    options.defaultHiveTableOptions.alwaysCompactFilesSizeSmallerThanBytes = safeParseInt(argNameValues.get("-alwaysCompactFilesSizeSmallerThanBytes"), options.defaultHiveTableOptions.alwaysCompactFilesSizeSmallerThanBytes)
    options.defaultHiveTableOptions.maxFilesPerDirectory = safeParseInt(argNameValues.get("-maxFilesPerDirectory"), options.defaultHiveTableOptions.maxFilesPerDirectory)
    //lockOptions
    val lockZooKeeperUrl = safeGetArgString(argNameValues.get("-lockZooKeeperUrl"), null)
    if (lockZooKeeperUrl != null) {
      options.lockOptions = new HiveCompactorLockOptions
      options.lockOptions.lockZooKeeperUrl = lockZooKeeperUrl
      options.lockOptions.lockBaseZooKeeperPath = safeGetArgString(argNameValues.get("-lockBaseZooKeeperPath"), null)
      options.lockOptions.lockBaseSleepMillis = safeParseInt(argNameValues.get("-lockBaseSleepMillis"), options.lockOptions.lockBaseSleepMillis)
      options.lockOptions.lockMaxSleepMillis = safeParseInt(argNameValues.get("-lockMaxSleepMillis"), options.lockOptions.lockMaxSleepMillis)
      options.lockOptions.lockMaxRetries = safeParseInt(argNameValues.get("-lockMaxRetries"), options.lockOptions.lockMaxRetries)
      options.lockOptions.lockAcquireTimeoutSeconds = safeParseInt(argNameValues.get("-lockAcquireTimeoutSeconds"), options.lockOptions.lockAcquireTimeoutSeconds)
    }
    options
  }
}
