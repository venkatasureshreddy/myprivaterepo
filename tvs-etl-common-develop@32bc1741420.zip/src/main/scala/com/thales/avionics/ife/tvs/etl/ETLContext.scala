package com.thales.avionics.ife.tvs.etl

import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.apache.spark.sql.functions._

/**
 * Contains the fields that make up the partition key for log tables.
 */
private case class LogPartition(
  airline_id: String,
  year: String,
  month: String,
  day: String)

object ETLContext {

  /**
   * Factory method to create an ETLContext and its dependencies.
   */
  def create(sqlContext: SQLContext, config: ETLConfig, flightProductStatusFilters: Array[String]): ETLContext = {

    val phoenix = new PhoenixPersistence(sqlContext, config.phoenixZookeeperUrl, config.phoenixDatabase)
    val flightProductStatus = new FlightProductStatus(phoenix, config.maxNumOfFlightsPerRun, flightProductStatusFilters)

    new ETLContext(
      flightProductStatus,
      sqlContext,
      phoenix,
      config)
  }
}

/**
 * Provides access to data and logic that is used across the various ETL applications used to process flight logs.
 */
class ETLContext(val flightProductStatus: FlightProductStatus, val sqlContext: SQLContext, val phoenix: PhoenixPersistence, val config: ETLConfig) {

  private[this] val logger = Logger.getLogger(getClass().getName());

  import sqlContext.implicits._

  flightProductStatus.getFiltered().cache().registerTempTable("FLIGHT_PRODUCT_STATUS_TABLE")

  val productFlightIds = flightProductStatus.getFiltered().select("flight_id").map(line => line).collect().map(_(0)).toList

  /**
   * List of `log_flight_id`s on which to perform ETL.
   *
   * Deprecated, as we need to stop using this list for filtering logs and start using the hiveKeys defined below.
   */
  @deprecated
  val logFlightIds = flightProductStatus.getFiltered().select("log_flight_id").map(line => line).collect().map(_(0)).toList

  /**
   * Comma-separated string version of logFlightIds
   *
   * Deprecated, as we need to stop using this list for filtering logs and start using the hiveKeys defined below.
   */
  @deprecated
  val logFlightIdsFilterValue = s"'${logFlightIds.mkString("','")}'"

  val productIds = flightProductStatus.getFiltered().select("product_id").dropDuplicates().rdd.collect().map(_(0).toString()).toList

  val productIdFilterValue = s"'${productIds.mkString("','")}'"

  private val enhancedFlightProductStatus = flightProductStatus.getFiltered()
    .withColumn("airline_id", upper($"airline_id"))
    .cache()

  enhancedFlightProductStatus.registerTempTable("ENHANCED_FLIGHT_PRODUCT_STATUS")

  private val hiveKeys = HivePartitionUtil.getHiveWhere(enhancedFlightProductStatus)

  println(s"hiveKeys = ${hiveKeys}")

  private lazy val cachedLogTables = config.logTables.filter(_.eagerlyCache)
                                        .map(_.tableName)
                                        .map(table => (table, reallySelectLogs(table).cache()))
                                        .toMap
                                        
  def repairLogTables() {

    // the following settings ensure log table compaction results in files of desireable sizes
    sqlContext.setConf("hive.exec.dynamic.partition", "true")
    sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    sqlContext.setConf("hive.exec.compress.output", "true")
    sqlContext.setConf("mapred.min.split.size", "134217728")

    val tables = config.logTables
      .map(_.tableName)
      .map(tableWithDatabase(_))

    tables.foreach(table => {
      sqlContext.sql(s"MSCK REPAIR TABLE ${table}")
    })
  }

  /**
   * Gets logs from the requested table, filtered to include only flights that are pending metrics calculation.
   */
  def selectLogs(table: String): DataFrame = {
    cachedLogTables.get(table) match {
      case Some(df) => df
      case None => reallySelectLogs(table)
    }
  }
  
  /**
   * Gets logs from the requested table, filtered to include only flights that are pending metrics calculation and method expects log_flight_ids as input.
   */
  def selectLogs(table: String,logFlightIdString:String): DataFrame = {
    cachedLogTables.get(table) match {
      case Some(df) => df
      case None     => reallySelectLogs(table,logFlightIdString)
    }
  }
  
  /**
   * We use "sparkContext.getExecutorStorageStatus.length - 1", to find the number of executors minus the driver in a cluster.
   * We fall back to one, to handle the case where all the work is being done on the driver, like in unit tests.
   */
  def calculateNumberOfPartitions(): Int = Math.max(1, sqlContext.sparkContext.getExecutorStorageStatus.length - 1)

  private def tableWithDatabase(table: String): String = config.logDatabase match {
    case Some(database) => s"${database}.${table}"
    case None => table
  }

  private def reallySelectLogs(table: String): DataFrame = {
    val query = """SELECT
                 fps.tail_id,
                 fps.fleet_id,
                 fps.airline_id,
                 fps.product_id,
                 fps.flight_id,
                 fps.log_departure_time,
                 logs.time_stamp,
                 logs.host_name,
                 logs.msg_type,
                 logs.msg_data
                 FROM %1$s as logs, ENHANCED_FLIGHT_PRODUCT_STATUS as fps
                 WHERE (%2$s) AND logs.flight_id = fps.log_flight_id"""
      .format(tableWithDatabase(table), hiveKeys)

    println(query)

    sqlContext.sql(query).repartition(calculateNumberOfPartitions(), $"flight_id", $"time_stamp")
  }

 
  /**
   * This method takes table name and Unscored log_flight_ids as input and returns a dataframe 
   * 
   * */
 def reallySelectLogs(table: String, logflightIdString: String): DataFrame = {

     println(s"delta_log_flight_id_string = ${logflightIdString}")
        
    val deltaEnhancedFlightProductStatus = flightProductStatus.getFilteredWithLogFilghtIds(logflightIdString)
      .withColumn("airline_id", upper($"airline_id"))
      .cache()

    deltaEnhancedFlightProductStatus.registerTempTable("DELTA_ENHANCED_FLIGHT_PRODUCT_STATUS")

    val deltaHiveKeys = HivePartitionUtil.getHiveWhere(deltaEnhancedFlightProductStatus)

    println(s"deltaHiveKeys = ${deltaHiveKeys}")

    val query = """SELECT
                 fps.tail_id,
                 fps.fleet_id,
                 fps.airline_id,
                 fps.product_id,
                 fps.flight_id,
                 fps.log_departure_time,
                 logs.time_stamp,
                 logs.host_name,
                 logs.msg_type,
                 logs.msg_data
                 FROM %1$s as logs, DELTA_ENHANCED_FLIGHT_PRODUCT_STATUS as fps
                 WHERE (%2$s) AND logs.flight_id = fps.log_flight_id"""
      .format(tableWithDatabase(table), deltaHiveKeys)

    println(query)

    sqlContext.sql(query).repartition(calculateNumberOfPartitions(), $"flight_id", $"time_stamp")
  }
    
  
  /**
   * Commonly used DataFrame transformations should be defined here.
   */
  object transformations {

    def addModifiedByAndDateTimeFields()(df: DataFrame): DataFrame = {
      import implicits._
      df.withModifiedByAndDateTimeFields()
    }
  }

  object implicits {

    implicit class EnhancedDataFrame(val df: DataFrame) {

      /**
       * Add modified_by and modified_date_time fields to the DataFrame.
       */
      implicit def withModifiedByAndDateTimeFields(): DataFrame = df
        .withColumn("modified_by", lit(s"${sqlContext.sparkContext.sparkUser}#${config.applicationName}"))
        .withColumn("modified_date_time", current_timestamp())

      /**
       * Allows inspection of a DataFrame within a chain of transformations without needing to store intermediate DataFrames to local variables.
       *
       * Only causes work to be done if log level for MetricsContext is set to debug.
       *
       * For example:
       * ```
       * import metricsContext.implicits_
       * sqlContext.sql("select foo, bar from xyz")
       *     .peek("initial values after selection")
       *     .withColumn("haha", lit("lol"))
       *     .peek("after adding haha column")
       * ```
       */
      implicit def peek(description: String): DataFrame = {
        if (logger.isDebugEnabled()) {
          logger.debug(s"peeking : ${description}")
          df.show(false)
        }
        df
      }

      /**
       * Saves the DataFrame to the provided phoenix table.
       * NOTE - do not add a schema prefix to the table name when calling this method.
       */
      implicit def saveToPhoenix(table: String): DataFrame = {
        phoenix.save(df, table)
        df
      }
    }
  }
}
