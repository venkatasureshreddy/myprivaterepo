package com.thales.avionics.ife.tvs.etl.hivecompaction

import java.util.concurrent.atomic.AtomicInteger

class HiveCompactionStats {

  val filesCompacted = new AtomicInteger(0)
  val dirsCompacted = new AtomicInteger(0)
  val errors = new AtomicInteger(0)

  override def toString = s"HiveCompactionStats(filesCompacted=$filesCompacted, dirsCompacted=$dirsCompacted, errors=$errors)"
}
