package com.thales.avionics.ife.tvs.etl.hivecompaction

import java.io._
import java.time.{LocalDate, ZoneId}
import java.util.Locale
import java.util.concurrent.TimeUnit

import com.google.common.annotations.VisibleForTesting
import com.thales.avionics.ife.tvs.etl.TaskEngine
import org.apache.commons.io.Charsets
import org.apache.curator.framework.recipes.locks.{InterProcessMutex, InterProcessReadWriteLock}
import org.apache.curator.framework.{CuratorFramework, CuratorFrameworkFactory}
import org.apache.curator.retry.ExponentialBackoffRetry
import org.apache.hadoop.fs._
import org.apache.hadoop.io.compress.{CompressionCodec, CompressionCodecFactory, DefaultCodec}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext

import scala.util.control.Breaks._

/**
  * Compacts Hive table in a cluster safe manner
  * Uses ZooKeeper locks to avoid concurrent compaction of the same Hive tables, which can result in data corruption
  */
class HiveCompactor(options: HiveCompactorOptions, fileContext: FileContext, tmpDir: Path, msckFunction: (String) => Unit) {

  private val compressionCodecFactory = new CompressionCodecFactory(options.conf)
  private val stats = new HiveCompactionStats
  private var taskEngine: TaskEngine = _

  private def traverseNoLocks(): Unit = {
    for (hiveTable <- options.hiveTables) {
      traverse(hiveTable, fileContext.getFileStatus(new Path(hiveTable.baseHdfsDir)))
    }
  }

  private def traverseWithLocks(): Unit = {
    val curatorFramework = HiveCompactor.newCuratorFramework(options.lockOptions)
    try {
      val sortedHiveTables = HiveCompactor.sortHiveTablesForLocking(options.hiveTables)
      for (hiveTable <- sortedHiveTables) {
        HiveCompactor.runWithLock(curatorFramework, options.lockOptions, hiveTable.name, LockType.WRITE, () => {
          try {
            traverse(hiveTable, fileContext.getFileStatus(new Path(hiveTable.baseHdfsDir)))
          } catch {
            case e: IOException =>
              throw new RuntimeException(e)
          }
        })
      }
    } finally {
      curatorFramework.close()
    }
  }

  private def traverse(table: HiveTable, baseHdfsDir: FileStatus): Unit = {
    val baseHdfsDirPath = baseHdfsDir.getPath
    HiveCompactor.LOGGER.info("Traversing " + baseHdfsDirPath)
    val traverser = new Traverser(options, HiveCompactor.getTableOptions(options, table))
    traverser.traverse(baseHdfsDir)
    HiveCompactor.LOGGER.info("Finished traversing " + baseHdfsDirPath)
    msckFunction.apply(table.name)
  }

  private class Traverser(options: HiveCompactorOptions, tableOptions: HiveCompactorTableOptions) {

    def traverse(file: FileStatus): Unit = {
      if (!HiveCompactor.isHidden(file.getPath.getName) && file.isDirectory) {
        val childrenToCompact = HiveCompactor.getChildrenToCompact(fileContext, tableOptions, file)
        if (childrenToCompact.size > 1) {
          taskEngine.queue(() => compactDirectory(file, childrenToCompact))
        } else {
          val iter = fileContext.listStatus(file.getPath)
          while (iter.hasNext) {
            traverse(iter.next)
          }
        }
      }
    }

    private def compactDirectory(dir: FileStatus, childrenToCompact: List[Path]): Unit = {
      val dirPath = dir.getPath
      try {
        if(options.trialMode) {
          HiveCompactor.LOGGER.info("Trial mode not compacting " + dirPath)
        } else {
          HiveCompactor.LOGGER.info("Compacting " + dirPath)
          compactDirectory(dirPath, childrenToCompact)
        }
      } catch {
        case e: Exception =>
          stats.errors.incrementAndGet
          HiveCompactor.LOGGER.error("Error processing " + dirPath, e)
          if (!options.ignoreErrors) {
            throw new RuntimeException(e)
          }
      }
    }

    private def compactDirectoryChildren(childrenToCompact: List[Path], writer: Writer): Unit = {
      var writeNewline = false
      var line: String = null
      for (fileToCompact <- childrenToCompact) {
        val reader = new BufferedReader(new InputStreamReader(open(fileToCompact), Charsets.UTF_8))
        try {
          breakable {
            while (true) {
              line = reader.readLine()
              if (line == null) {
                break
              }
              if (writeNewline) {
                writer.write("\n")
              }
              writeNewline = true
              writer.write(line)
            }
          }
        } finally {
          reader.close()
        }
        stats.filesCompacted.incrementAndGet
      }
    }

    private def getCompactedFileCompressionCodec: CompressionCodec = {
      var compactedFileCompressionCodec: CompressionCodec = null
      if (tableOptions.compressCompactedFiles) {
        val newCodec = new DefaultCodec()
        newCodec.setConf(options.conf)
        compactedFileCompressionCodec = newCodec
      }
      compactedFileCompressionCodec
    }

    private def compactDirectory(dirPath: Path, childrenToCompact: List[Path]): Unit = {
      val compactedFileCompressionCodec = getCompactedFileCompressionCodec
      //sort to make unit testing easier (behavior is deterministic)
      childrenToCompact.sortBy(path => path.toString)
      val tmpFile = new Path(tmpDir, ".hive_compact_tmp-." + System.currentTimeMillis + "-" + Thread.currentThread.getId)
      val writer = new BufferedWriter(new OutputStreamWriter(create(compactedFileCompressionCodec, tmpFile,
        java.util.EnumSet.of(CreateFlag.CREATE)), Charsets.UTF_8))
      try {
        compactDirectoryChildren(childrenToCompact, writer)
      } finally {
        writer.close()
      }
      /*
      Note that it is not safe for Hive to run a query that reads from this directory right now due to files being modified
      Also, note that if this process errors/crashes before the deletion below is finished that the directory will have corrupt data
      There is no way to make this process atomic
       */
      var fileName = "compacted-" + System.currentTimeMillis
      if (compactedFileCompressionCodec != null) {
        fileName += compactedFileCompressionCodec.getDefaultExtension
      } else {
        fileName += ".txt"
      }
      fileContext.rename(tmpFile, new Path(dirPath, fileName),
        org.apache.hadoop.fs.Options.Rename.OVERWRITE)
      /*
      Only delete after the compacted file has been successfully written
      Note that if a Hive query runs right now it will see duplicate data from the non-compacted files and the compacted file
       */
      for (fileToCompact <- childrenToCompact) {
        if(!fileContext.delete(fileToCompact, false)) {
          throw new RuntimeException(s"Unable to delete $fileToCompact")
        }
      }
      //Now Hive queries can run on this directory
      stats.dirsCompacted.incrementAndGet
    }

    private def open(path: Path): InputStream = {
      val codec = compressionCodecFactory.getCodec(path)
      var is: InputStream = fileContext.open(path)
      if (codec != null) {
        is = codec.createInputStream(is)
      }
      is
    }

    private def create(codec: CompressionCodec, path: Path, createFlag: java.util.EnumSet[CreateFlag]): OutputStream = {
      var ret: OutputStream = fileContext.create(path, createFlag)
      if (codec != null) {
        ret = codec.createOutputStream(ret)
      }
      ret
    }
  }

  private def compact(): Unit = {
    val taskEngine = new TaskEngine(options.numThreads, options.queueCapacity, options.taskEngineMaxCloseWaitMillis)
    try {
      this.taskEngine = taskEngine
      if (options.lockOptions != null) {
        HiveCompactor.LOGGER.info("Running with locks")
        traverseWithLocks()
      } else { //this could result in data corruption if there are concurrent writers to the HDFS data
        HiveCompactor.LOGGER.info("Running without locks")
        traverseNoLocks()
      }
      taskEngine.waitForFinished()
      HiveCompactor.LOGGER.info("Finished compaction with stats: " + stats)
    } catch {
      case e: Exception => {
        HiveCompactor.LOGGER.error("Error during compaction " + stats, e)
        throw new RuntimeException(e)
      }
    } finally {
      this.taskEngine = null
      taskEngine.close()
    }
  }
}

object HiveCompactor {

  private val UTC = ZoneId.of("UTC")

  private val LOGGER = Logger.getLogger(getClass().getName())
  LOGGER.setLevel(Level.INFO)

  @VisibleForTesting
  def newCuratorFramework(options: HiveCompactorLockOptions): CuratorFramework = {
    val ret = CuratorFrameworkFactory.newClient(options.lockZooKeeperUrl, new ExponentialBackoffRetry(options.lockBaseSleepMillis, options.lockMaxRetries, options.lockMaxSleepMillis))
    ret.start()
    ret
  }

  /**
    * Run a Callable while holding a read lock on Hive tables
    * This is necessary to avoid running a process that will read data while the compaction
    * process is running
    * Not locking while compaction is running could result in errors or incorrect results
    *
    * @param lockOptions HiveCompactorLockOptions
    * @param hiveTables  set of Hive tables to read lock
    * @param callable    Callable to run while locks are held
    * @return return value from callable
    * @throws Exception if there is an Exception
    */
  def runWithTableCompactionReadLock[T](lockOptions: HiveCompactorLockOptions, hiveTables: Set[String], callable: () => T): T = {
    //Locks must be acquired in the same order by different processes to avoid deadlock
    val sortedTables = sortForLocking(hiveTables.toSeq)
    val curatorFramework = newCuratorFramework(lockOptions)
    try {
      val acquiredLocks = new scala.collection.mutable.ArrayBuffer[ZkLockPathAndLock]
      try {
        for (tableName <- sortedTables) {
          val zkLockPath = getZkLockPath(lockOptions.lockBaseZooKeeperPath, tableName)
          val zkLock = getLock(curatorFramework, LockType.READ, zkLockPath)
          lock(lockOptions, tableName, LockType.READ, zkLockPath, zkLock)
          acquiredLocks.append(ZkLockPathAndLock(zkLock, zkLockPath))
        }
        callable.apply()
      } finally {
        releaseLocks(acquiredLocks, LockType.READ)
      }
    } finally {
      curatorFramework.close()
    }
  }

  private def releaseLock(zkLockPath: String, lock: InterProcessMutex, lockType: LockType.Value): Unit = {
    lock.release()
    LOGGER.info(s"$lockType lock released " + zkLockPath)
  }

  private def getLock(curatorFramework: CuratorFramework, lockType: LockType.Value, zkLockPath: String) = {
    val interProcessReadWriteLock = new InterProcessReadWriteLock(curatorFramework, zkLockPath)
    var lock: InterProcessMutex = null
    lockType match {
      case LockType.WRITE => lock = interProcessReadWriteLock.writeLock
      case LockType.READ => lock = interProcessReadWriteLock.readLock
    }
    lock
  }

  private def lock(lockOptions: HiveCompactorLockOptions, tableName: String, lockType: LockType.Value, zkLockPath: String, lock: InterProcessMutex): Unit = {
    LOGGER.info(s"Attempting to acquire $lockType lock " + zkLockPath)
    if (lock.acquire(lockOptions.lockAcquireTimeoutSeconds, TimeUnit.SECONDS)) {
      LOGGER.info(s"Acquired $lockType lock " + zkLockPath)
    } else {
      throw new HiveCompactionLockTimeoutException(tableName, lockType)
    }
  }

  private def releaseLocks(acquiredLocks: scala.collection.mutable.ArrayBuffer[ZkLockPathAndLock], lockType: LockType.Value): Unit = {
    //unlock in reverse order
    var lastException: Option[Exception] = None
    for(zkLockPathAndLock <- acquiredLocks.reverse) {
      try {
        releaseLock(zkLockPathAndLock.zkLockPath, zkLockPathAndLock.lock, lockType)
      } catch {
        case e: Exception =>
          //don't let this prevent other locks from releasing other locks
          LOGGER.error(s"Error releasing $lockType lock " + zkLockPathAndLock.zkLockPath, e)
          lastException = Some(e)
      }
    }
    if (lastException.isDefined) {
      throw lastException.get
    }
  }

  @VisibleForTesting
  def runWithLock(curatorFramework: CuratorFramework, lockOptions: HiveCompactorLockOptions,
                  tableName: String, lockType: LockType.Value, function: () => Unit): Unit = {
    val zkLockPath = getZkLockPath(lockOptions.lockBaseZooKeeperPath, tableName)
    val zkLock = getLock(curatorFramework, lockType, zkLockPath)
    var lockAcquired = false
    try {
      lock(lockOptions, tableName, lockType, zkLockPath, zkLock)
      lockAcquired = true
      function.apply()
    } finally {
      if (lockAcquired) {
        releaseLock(zkLockPath, zkLock, lockType)
      }
    }
  }

  case class ZkLockPathAndLock(lock: InterProcessMutex, zkLockPath: String)

  private def validate(options: HiveCompactorOptions): Unit = {
    require(options != null, "Invalid options")
    if(options.msckOnly) {
      require(options.hiveTables != null && options.hiveTables.nonEmpty, "Invalid hiveTables")
    } else {
      require(options.conf != null, "Invalid conf")
      require(options.hiveTables != null && options.hiveTables.nonEmpty, "Invalid hiveTables")
      require(options.tmpDir != null, "Invalid tmpDir")
      require(options.numThreads > 0, "Invalid numThreads")
      require(options.queueCapacity > 0, "Invalid queueCapacity")
      require(options.taskEngineMaxCloseWaitMillis > 0, "Invalid taskEngineMaxCloseWaitMillis")
    }
    if(options.defaultHiveTableOptions != null) {
      validateTableOptions(options.defaultHiveTableOptions)
    }
    if(options.hiveTableOptions != null) {
      for(option <- options.hiveTableOptions.values) {
        validateTableOptions(option)
      }
    }
    if (options.lockOptions != null) {
      validateLockOptions(options)
    }
  }

  private def validateLockOptions(options: HiveCompactorOptions): Unit = {
    require(options.lockOptions.lockZooKeeperUrl != null, "Invalid lockZooKeeperUrl")
    require(options.lockOptions.lockBaseZooKeeperPath != null, "Invalid lockBaseZooKeeperPath")
    require(options.lockOptions.lockBaseSleepMillis > 0, "Invalid lockBaseSleepMillis")
    require(options.lockOptions.lockMaxSleepMillis > 0, "Invalid lockMaxSleepMillis")
    require(options.lockOptions.lockMaxRetries > 0, "Invalid lockMaxRetries")
    require(options.lockOptions.lockAcquireTimeoutSeconds > 0, "Invalid lockAcquireTimeoutSeconds")
  }

  private def validateTableOptions(options: HiveCompactorTableOptions): Unit = {
    require(options.maxFileSizeBytesToCompact > 0, "Invalid maxFileSizeBytesToCompact")
  }

  private def msck(sqlContext: SQLContext, databaseName: String, tableName: String): Unit = {
    var fullTableName = tableName
    if(databaseName != null) {
      fullTableName = databaseName + "." + fullTableName
    }
    if (sqlContext != null) {
      LOGGER.info(s"Running msck $fullTableName")
      sqlContext.sql(s"MSCK REPAIR TABLE $fullTableName")
      LOGGER.info(s"Finished msck $fullTableName")
    } else {
      LOGGER.info(s"Not running msck $fullTableName")
    }
  }

  /**
    * Locks must be acquired in the same order by all processes to avoid deadlock
    *
    * @param lockNames Collection of lock names to sort
    * @return sorted lock names
    */
  @VisibleForTesting
  def sortForLocking(lockNames: Seq[String]): Seq[String] = {
    lockNames.sorted
  }

  /**
    * Locks must be acquired in the same order by all processes to avoid deadlock
    *
    * @param tables collection of HiveTable's to lock
    * @return sorted HiveTable
    */
  @VisibleForTesting
  def sortHiveTablesForLocking(tables: Seq[HiveTable]): Seq[HiveTable] = {
    tables.sortBy(ht => ht.name)
  }

  @VisibleForTesting
  def getZkLockPath(baseZkLockpath: String, hiveTableName: String): String = {
    var ret = baseZkLockpath
    if (!ret.endsWith("/")) {
      ret += "/"
    }
    ret + hiveTableName
  }

  /**
    * Compact Hive tables
    *
    * @param options    HiveCompactorOptions
    * @param sqlContext SQLContext
    * @throws Exception if there is an Exception
    */
  def compact(options: HiveCompactorOptions, sqlContext: SQLContext): Unit = {
    validate(options)
    if(options.msckOnly) {
      LOGGER.info("Only running msck, no compaction")
      for(hiveTable <- options.hiveTables) {
        msck(sqlContext, options.hiveDatabase, hiveTable.name)
      }
    } else {
      val fileContext = FileContext.getFileContext(options.conf)
      val tmpDir = new Path(options.tmpDir)
      val tmpDirFs = fileContext.getFileStatus(tmpDir)
      require(tmpDirFs.isDirectory, tmpDir + " is not a directory")
      val compactor = new HiveCompactor(options, fileContext, tmpDir, (tableName: String) => {
        msck(sqlContext, options.hiveDatabase, tableName)
      })
      LOGGER.info("Compacting with options: " + options)
      compactor.compact()
    }
  }

  @VisibleForTesting
  def getPartitionDate(dayDirPath: Path): Option[Long] = {
    val day: Option[Int] = getPartitionDirNameNumber(dayDirPath.getName)
    var month: Option[Int] = None
    var year: Option[Int] = None
    val monthDirPath = dayDirPath.getParent
    if (monthDirPath != null) {
      month = getPartitionDirNameNumber(monthDirPath.getName)
      val yearDirPath = monthDirPath.getParent
      if (yearDirPath != null) {
        year = getPartitionDirNameNumber(yearDirPath.getName)
      }
    }
    var ret: Option[Long] = None
    if (day.isDefined && month.isDefined && year.isDefined) {
      ret = Some(LocalDate.of(year.get, month.get, day.get).atStartOfDay(UTC).toEpochSecond * 1000)
    }
    ret
  }

  private def getPartitionDirNameNumber(dirName: String): Option[Int] = {
    val split = dirName.split("=")
    var ret: Option[Int] = None
    if (split.length == 2) {
      try {
        ret = Some(split(1).toInt)
      } catch {
        case e: Exception => //ignore
      }
    }
    ret
  }

  /**
    * While Flume is writing files it names them as .whatever so that
    * Hive will ignore them until they are finished writing, when Flume renames the file
    * Hive and other MapReduce jobs also create temporary directories starting with '.'
    * so that other processes will ignore them
    *
    * @param fileName file name
    * @return whether a file or directory is hidden and should be ignored
    */
  private def isHidden(fileName: String) = {
    fileName.startsWith(".")
  }

  private def getCompactableChildren(fileContext: FileContext, tableOptions: HiveCompactorTableOptions, dir: Path): List[FileStatus] = {
    // RemoteIterator is not traversable more than once, so create a list
    val list = new scala.collection.mutable.ArrayBuffer[FileStatus]
    val iter = fileContext.listStatus(dir)
    while(iter.hasNext) {
      val child = iter.next
      if(child.isFile && !isHidden(child.getPath.getName) && child.getLen < tableOptions.maxFileSizeBytesToCompact) {
        list.append(child)
      }
    }
    list.toList
  }

  @VisibleForTesting
  def getChildrenToCompact(fileContext: FileContext, tableOptions: HiveCompactorTableOptions, fileStatus: FileStatus): List[Path] = {
    val filePath = fileStatus.getPath
    val name = filePath.getName.toLowerCase(Locale.ENGLISH)
    //skip hidden files/directories (Flume creates hidden files while files are being written)
    var shouldCompact = false
    //avoid listStatus() if not necessary by creating lazily
    lazy val children = getCompactableChildren(fileContext, tableOptions, filePath)
    if (!isHidden(name) && name.startsWith("day=") && fileStatus.isDirectory) {
      //ignore old partitions
      if ((tableOptions.maxDaysAgoToProcess < 1 || !isOlderThan(filePath, tableOptions.maxDaysAgoToProcess, System.currentTimeMillis)) &&
        children.size >= tableOptions.minFilesToCompact) {
        if(tableOptions.minMinutesForRecentlyWrittenFiles > 0) {
          /*
          Ignore directories where file data has been recently written, which is an indicator that it may have more data written soon
          This prevents repeatedly compacting directories where file data is being continuously written, ie very recent days
           */
          shouldCompact |= !hasRecentlyModifiedFiles(children, tableOptions.minMinutesForRecentlyWrittenFiles, System.currentTimeMillis)
        }
        if(tableOptions.maxFilesPerDirectory > 0) {
          //note that this purposefully overrides the shouldCompact result of minMinutesForRecentlyWrittenFiles
          shouldCompact |= children.size > tableOptions.maxFilesPerDirectory
        }
        if(!shouldCompact && tableOptions.alwaysCompactFilesSizeSmallerThanBytes > 0) {
          //optionally force compaction of small files
          shouldCompact |= hasFilesSmallerThan(children, tableOptions.alwaysCompactFilesSizeSmallerThanBytes)
        }
      }
    }
    if(shouldCompact) {
      children.map(fs => fs.getPath)
    } else {
      List[Path]()
    }
  }

  @VisibleForTesting
  def isOlderThan(path: Path, maxDaysAgoToProcess: Int, now: Long): Boolean = {
    val partitionDate = getPartitionDate(path)
    partitionDate.isDefined && partitionDate.get < now - TimeUnit.DAYS.toMillis(maxDaysAgoToProcess)
  }

  @VisibleForTesting
  def hasRecentlyModifiedFiles(children: List[FileStatus],
                               minMinutesForRecentlyWrittenFiles: Int, now: Long): Boolean = {
    var mostRecentModificationTimeMillis: Option[Long] = None
    for(child <- children) {
      if(child.isFile && !isHidden(child.getPath.getName)) {
        val childModMillis = child.getModificationTime
        if(mostRecentModificationTimeMillis.isEmpty || childModMillis > mostRecentModificationTimeMillis.get) {
          mostRecentModificationTimeMillis = Some(childModMillis)
        }
      }
    }
    mostRecentModificationTimeMillis.isDefined &&
      mostRecentModificationTimeMillis.get > (now - TimeUnit.MINUTES.toMillis(minMinutesForRecentlyWrittenFiles))
  }

  @VisibleForTesting
  def hasFilesSmallerThan(children: List[FileStatus], smallerThanBytes: Int): Boolean = {
    children.exists(child => child.getLen < smallerThanBytes)
  }

  @VisibleForTesting
  def getTableOptions(options: HiveCompactorOptions, table: HiveTable): HiveCompactorTableOptions = {
    var ret: HiveCompactorTableOptions = null
    if(options.hiveTableOptions != null) {
      ret = options.hiveTableOptions.getOrElse(table.name, null)
    }
    if(ret == null) {
      ret = options.defaultHiveTableOptions
    }
    if(ret == null) {
      ret = new HiveCompactorTableOptions()
    }
    ret
  }
}

/**
  * Main method to allow for running compaction standalone via command line:
  * Enable maven shade plugin: https://maven.apache.org/plugins/maven-shade-plugin/
  * Build: mvn clean package
  * Replace "AST" with "*":
  * java -cp "/etc/hadoop/conf/:/etc/hive/conf/:tvs-etl-common.jar:/usr/hdp/current/hadoop-client/lib/AST:/usr/hdp/current/hadoop-hdfs-client/AST:/usr/hdp/current/hadoop-client/AST" \
  * com.thales.avionics.ife.tvs.etl.hivecompaction.HiveCompactorMain $ARGS
  */
object HiveCompactorMain {

  def main(args: Array[String]): Unit = {
    val argNameValues: Map[String, String] = HiveCompactorOptions.parseArgNameValues(args)
    val options: HiveCompactorOptions = HiveCompactorOptions.parseFromArgs(argNameValues)
    var sqlContext: SQLContext = null
    if ("true".equalsIgnoreCase(argNameValues.getOrElse("-msck", null))) {
      sqlContext = new SQLContext(new SparkContext)
    } else {
      //means no msck will run
      sqlContext = null
    }
    HiveCompactor.compact(options, sqlContext)
  }
}
