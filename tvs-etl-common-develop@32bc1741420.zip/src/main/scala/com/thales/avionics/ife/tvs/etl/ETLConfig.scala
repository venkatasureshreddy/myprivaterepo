package com.thales.avionics.ife.tvs.etl

case class ETLConfig(
  applicationName: String,
  logDatabase: Option[String],
  phoenixDatabase: String,
  phoenixZookeeperUrl: String,
  maxNumOfFlightsPerRun: Int,
  zookeeperUrl: String,
  logTables: Array[LogTableConfig])
  
case class LogTableConfig(tableName: String, eagerlyCache: Boolean)