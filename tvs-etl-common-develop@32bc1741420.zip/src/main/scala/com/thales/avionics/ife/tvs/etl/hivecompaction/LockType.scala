package com.thales.avionics.ife.tvs.etl.hivecompaction

object LockType extends Enumeration {

  val WRITE, READ = Value

}