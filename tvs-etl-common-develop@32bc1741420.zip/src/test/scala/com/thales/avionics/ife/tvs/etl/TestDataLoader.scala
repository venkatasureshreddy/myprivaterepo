

package com.thales.avionics.ife.tvs.etl

import java.sql.Timestamp
import org.apache.spark.SparkContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SQLContext

case class HiveLogRow(airline: String, year: String, month: String, day: String,
  flight_id: String, file_name: String, time_stamp: String, host_name: String, process_name: String,
  p_id: Int, t_id: String, log_level: Int, version: Double, msg_type: String, msg_data: String)

case class FlightProductStatusRecord(
  product_id: String,
  flight_id: String,
  tail_id: String,
  airline_id: String,
  departure_time: Timestamp,
  logs_received: Boolean,
  log_flight_id: String,
  log_departure_time: Timestamp,
  mel_action: Boolean,
  mel_checked: Boolean,
  is_scored: Boolean,
  metrics_calculated: Boolean,
  viewership_calculated: Boolean,
  modified_date_time: Timestamp,
  fleet_id: String,
  fleet_name: String,
  modified_by: String,
  is_valid: Boolean)

case class ConfigsRecord(
  airline_id: String,
  config_key: String,
  config_value: String)

case class SeatResetCountRecord(
  flight_id: String,
  seat_number: String,
  metric_value: Integer)

class TestDataLoader(sc: SparkContext, hc: SQLContext, subDir: String) {

  val tsvToArray = (x: String) => x.split("\t")

  val arrayToLogRow = (x: Array[String]) => HiveLogRow(x(0), x(1), x(2), x(3),
    x(4), x(5), x(6), x(7), x(8),
    x(9).toInt, x(10), x(11).toInt, x(12).toDouble, x(13), x(14))

  val arrayToFlightProductStatus = (x: Array[String]) => {
    var isValid: Boolean = true
    if(x.length > 17) {
      val isValidStr = x(17)
      if(isValidStr != null) {
        isValid = isValidStr.toBoolean
      }
    }
    FlightProductStatusRecord(
      x(0),
      x(1),
      x(2),
      x(3),
      Timestamp.valueOf(x(4)),
      x(5).toBoolean,
      x(6),
      Timestamp.valueOf(x(7)),
      x(8).toBoolean,
      x(9).toBoolean,
      x(10).toBoolean,
      x(11).toBoolean,
      x(12).toBoolean,
      Timestamp.valueOf(x(13)),
      x(14),
      x(15),
      x(16),
      isValid)
  }

  val arrayToConfigs = (x: Array[String]) => ConfigsRecord(
    x(0),
    x(1),
    x(2))

  val arrayToSeatResetCountRecord = (x: Array[String]) => SeatResetCountRecord(
    x(0),
    x(1),
    x(2).toInt)

  import hc.implicits._

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadSeatSession(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.seatsession.tsv", 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadSgdStatusLogs(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.sgdstatus.tsv", 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadZeb2StatusLogs(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.zeb2status.tsv", 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)
    return df
  }

  def loadFlightProductStatus(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/phoenix.flight_product_status.tsv", 1)
      .map(tsvToArray)
      .map(arrayToFlightProductStatus).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadSgdStatusForSeatColorProductStatus(): DataFrame = {
    println(s"src/test/resources${subDir}/hive.sgdstatusforSeatColor.tsv")
    val df = sc.textFile(s"src/test/resources${subDir}/hive.sgdstatusforSeatColor.tsv", 1).map(tsvToArray).map(arrayToLogRow).toDF()
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadRemoteInventoryAll(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.remote_inventory.1.tsv", 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadRemoteInventorySW(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.remote_inventory.2.tsv", 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadRemoteInventoryHW(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.remote_inventory.3.tsv", 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadSvcStatesLogs(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.svcstates.tsv", 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadPhoenixConfigsTable(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/phoenix.configs.tsv", 1)
      .map(tsvToArray)
      .map(arrayToConfigs).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadHiveSeatResetsTempTable(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.seatresetscount.tsv", 1)
      .map(tsvToArray)
      .map(arrayToSeatResetCountRecord).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadHiveStvPlusHeatlh(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.health.tsv", 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)
    return df
  }

  /**
   * Deprecated, use loadHiveLogTable(shortTableName: String) or loadHiveLogTable(shortTableName: String, qualifier: String) instead.
   */
  @deprecated
  def loadMPSInventoryAll(): DataFrame = {
    val df = sc.textFile(s"src/test/resources${subDir}/hive.mpsinventory.tsv", 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)
    return df
  }

  /**
   * Loads test data for a given hive table from a tsv file.
   * Registers the loaded data as a temp table, and returns a DataFrame containing all data from the file.
   */
  def loadHiveLogTable(shortTableName: String): DataFrame =
    _loadHiveLogTable(s"src/test/resources${subDir}/hive.${shortTableName}.tsv", shortTableName)

  /**
   * Loads test data for a given hive table from a tsv file, using a combination of the talbe name and the qualifier to find the right file.
   * Registers the loaded data as a temp table, and returns a DataFrame containing all data from the file.
   */
  def loadHiveLogTable(shortTableName: String, qualifier: String): DataFrame =
    _loadHiveLogTable(s"src/test/resources${subDir}/hive.${shortTableName}.${qualifier}.tsv", shortTableName)

  private def _loadHiveLogTable(filePath: String, shortTableName: String): DataFrame = {
    val df = sc.textFile(filePath, 1)
      .map(tsvToArray)
      .map(arrayToLogRow).toDF().coalesce(2)

    df.registerTempTable(s"stvplus_${shortTableName}")

    return df
  }

  def getUnfiltered(): DataFrame = loadFlightProductStatus()
}
