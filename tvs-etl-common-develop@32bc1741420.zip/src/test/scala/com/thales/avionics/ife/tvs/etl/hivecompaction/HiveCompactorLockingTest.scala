package com.thales.avionics.ife.tvs.etl.hivecompaction

import java.util.concurrent.{Callable, ExecutorService, Executors}

import com.google.common.base.Throwables
import com.google.common.collect.Lists
import org.apache.curator.test.TestingServer
import org.joda.time.Interval
import org.junit.{After, Assert, Before, Test}

import scala.util.control.Breaks._

/**
  * Test curator locking
  *
  * Note that these tests rely on Thread.sleep() and timing but the sleeps should be long enough
  * that the tests pass 99.9% of the time
  * It is possible that if the threads are scheduled in a strange way by the OS that the tests could fail
  */
class HiveCompactorLockingTest {

  /**
    * Default sleep time for SleepTimeRunnable
    * Since this is testing concurrecy set this sleep time long enough that behavior
    * should be the same unless the box that is running these tests is under very high load
    */
  private val SLEEP_MILLIS = 10000

  private var zkServer: TestingServer = _
  private var executorService: ExecutorService = _
  private var lockOptions: HiveCompactorLockOptions = _

  @Before
  def setUp(): Unit = {
    lockOptions = new HiveCompactorLockOptions
    lockOptions.lockZooKeeperUrl = "localhost:2181"
    lockOptions.lockBaseZooKeeperPath = "/HiveCompactorLockingTest"
    zkServer = new TestingServer(2181, true)
    //this must have enough threads that all tests below can run their SleepTimeRunnable's concurrently
    executorService = Executors.newFixedThreadPool(10)
  }

  @After
  def tearDown(): Unit = {
    zkServer.stop()
    executorService.shutdownNow
  }

  @Test
  def testConcurrentReadLocks(): Unit = {
    val tableNames = scala.collection.mutable.Set("table1")
    val readLockRunnable1 = new SleepTimeRunnable("ReadLock1", SLEEP_MILLIS)
    val readLockRunnable2 = new SleepTimeRunnable("ReadLock2", SLEEP_MILLIS)
    val future1 = submitReadLockSleepTimeRunnable(tableNames.toSet, readLockRunnable1)
    val future2 = submitReadLockSleepTimeRunnable(tableNames.toSet, readLockRunnable2)
    future1.get
    future2.get
    //test that the read locks were able to run concurrently
    Assert.assertTrue(readLockRunnable2.runInterval.getStart.isBefore(readLockRunnable1.runInterval.getEnd))
    Assert.assertTrue(readLockRunnable1.runInterval.getStart.isBefore(readLockRunnable2.runInterval.getEnd))
  }

  @Test
  def testConcurrentReadLocksMultipleTableNames(): Unit = {
    val tableNames = scala.collection.mutable.Set("table1", "table2", "table3", "table4")
    val readLockRunnable1 = new SleepTimeRunnable("ReadLock1", SLEEP_MILLIS)
    val readLockRunnable2 = new SleepTimeRunnable("ReadLock2", SLEEP_MILLIS)
    val writeLockRunnable1 = new SleepTimeRunnable("WriteLock1", SLEEP_MILLIS)
    val futures = new scala.collection.mutable.ArrayBuffer[java.util.concurrent.Future[_]]
    futures.append(submitLockSleepTimeRunnable("table3", LockType.WRITE, writeLockRunnable1))
    //wait a couple seconds to ensure that the write lock is acquired first
    Thread.sleep(2000L)
    futures.append(submitReadLockSleepTimeRunnable(tableNames.toSet, readLockRunnable1))
    futures.append(submitReadLockSleepTimeRunnable(tableNames.toSet, readLockRunnable2))
    import scala.collection.JavaConversions._
    for (future <- futures) {
      future.get
    }
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable1, readLockRunnable1))
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable1, readLockRunnable2))
    Assert.assertTrue(readLockRunnable2.runInterval.getStart.isBefore(readLockRunnable1.runInterval.getEnd))
    Assert.assertTrue(readLockRunnable1.runInterval.getStart.isBefore(readLockRunnable2.runInterval.getEnd))
  }

  @Test
  def testWriteLocksNoRuntimeOverlap(): Unit = {
    val runnable1 = new SleepTimeRunnable("WriteLock1", SLEEP_MILLIS)
    val runnable2 = new SleepTimeRunnable("WriteLock2", SLEEP_MILLIS)
    val future1 = submitLockSleepTimeRunnable("table1", LockType.WRITE, runnable1)
    val future2 = submitLockSleepTimeRunnable("table1", LockType.WRITE, runnable2)
    future1.get
    future2.get
    //test that the write locks did not run concurrently
    assertNoOverlaps(Seq(runnable1, runnable2))
  }

  @Test
  def testDifferentLockTables(): Unit = {
    val table1 = "table1"
    val table1WriteLockRunnable1 = new SleepTimeRunnable("Table1WriteLock1", SLEEP_MILLIS)
    val table1WriteLockRunnable2 = new SleepTimeRunnable("Table1WriteLock2", SLEEP_MILLIS)
    val table1ReadLockRunnable1 = new SleepTimeRunnable("Table1ReadLock1", SLEEP_MILLIS)
    val table1ReadLockRunnable2 = new SleepTimeRunnable("Table1ReadLock2", SLEEP_MILLIS)
    val table2 = "table2"
    val table2WriteLockRunnable1 = new SleepTimeRunnable("Table2WriteLock1", SLEEP_MILLIS)
    val table2WriteLockRunnable2 = new SleepTimeRunnable("Table2WriteLock2", SLEEP_MILLIS)
    val table2ReadLockRunnable1 = new SleepTimeRunnable("Table2ReadLock1", SLEEP_MILLIS)
    val table2ReadLockRunnable2 = new SleepTimeRunnable("Table2ReadLock2", SLEEP_MILLIS)
    val futures = new scala.collection.mutable.ArrayBuffer[java.util.concurrent.Future[_]]
    futures.append(submitLockSleepTimeRunnable(table1, LockType.WRITE, table1WriteLockRunnable1))
    futures.append(submitLockSleepTimeRunnable(table1, LockType.WRITE, table1WriteLockRunnable2))
    futures.append(submitLockSleepTimeRunnable(table1, LockType.READ, table1ReadLockRunnable1))
    futures.append(submitLockSleepTimeRunnable(table1, LockType.READ, table1ReadLockRunnable2))
    futures.append(submitLockSleepTimeRunnable(table2, LockType.WRITE, table2WriteLockRunnable1))
    futures.append(submitLockSleepTimeRunnable(table2, LockType.WRITE, table2WriteLockRunnable2))
    futures.append(submitLockSleepTimeRunnable(table2, LockType.READ, table2ReadLockRunnable1))
    futures.append(submitLockSleepTimeRunnable(table2, LockType.READ, table2ReadLockRunnable2))
    import scala.collection.JavaConversions._
    for (future <- futures) {
      future.get
    }
    //test that the table write locks did not run concurrently
    assertNoOverlaps(Lists.newArrayList(table1WriteLockRunnable1, table1WriteLockRunnable2))
    assertNoOverlaps(Lists.newArrayList(table2WriteLockRunnable1, table2WriteLockRunnable2))
    assertAtLeastOneOverlap(Lists.newArrayList(table1ReadLockRunnable1, table1ReadLockRunnable2, table2ReadLockRunnable1, table2ReadLockRunnable2))
  }

  @Test
  def testReadWriteLocks(): Unit = {
    val tableName = "tableName"
    val writeLockRunnable1 = new SleepTimeRunnable("WriteLock1", SLEEP_MILLIS)
    val writeLockRunnable2 = new SleepTimeRunnable("WriteLock2", SLEEP_MILLIS)
    val writeLockRunnable3 = new SleepTimeRunnable("WriteLock3", SLEEP_MILLIS)
    val readLockRunnable1 = new SleepTimeRunnable("ReadLock1", SLEEP_MILLIS)
    val readLockRunnable2 = new SleepTimeRunnable("ReadLock2", SLEEP_MILLIS)
    val readLockRunnable3 = new SleepTimeRunnable("ReadLock3", SLEEP_MILLIS)
    val futures = new scala.collection.mutable.ArrayBuffer[java.util.concurrent.Future[_]]
    futures.append(submitLockSleepTimeRunnable(tableName, LockType.WRITE, writeLockRunnable1))
    futures.append(submitLockSleepTimeRunnable(tableName, LockType.WRITE, writeLockRunnable2))
    futures.append(submitLockSleepTimeRunnable(tableName, LockType.WRITE, writeLockRunnable3))
    futures.append(submitLockSleepTimeRunnable(tableName, LockType.READ, readLockRunnable1))
    futures.append(submitLockSleepTimeRunnable(tableName, LockType.READ, readLockRunnable2))
    futures.append(submitLockSleepTimeRunnable(tableName, LockType.READ, readLockRunnable3))
    import scala.collection.JavaConversions._
    for (future <- futures) {
      future.get
    }
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable1, writeLockRunnable2, writeLockRunnable3))
    //test that the write locks did not run concurrently with the read locks
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable1, readLockRunnable1))
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable1, readLockRunnable2))
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable1, readLockRunnable3))
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable2, readLockRunnable1))
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable2, readLockRunnable2))
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable2, readLockRunnable3))
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable3, readLockRunnable1))
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable3, readLockRunnable2))
    assertNoOverlaps(Lists.newArrayList(writeLockRunnable3, readLockRunnable3))
  }

  @Test
  def testLockTimeout(): Unit = {
    lockOptions.lockAcquireTimeoutSeconds = 2
    val runnable1 = new SleepTimeRunnable("WriteLock1", SLEEP_MILLIS)
    val runnable2 = new SleepTimeRunnable("WriteLock2", SLEEP_MILLIS)
    val runnable1Future = submitLockSleepTimeRunnable("table1", LockType.WRITE, runnable1)
    Thread.sleep(2000L)
    val runnable2Future = submitLockSleepTimeRunnable("table1", LockType.WRITE, runnable2)
    runnable1Future.get()
    var ex: HiveCompactionLockTimeoutException = null
    try
      runnable2Future.get
    catch {
      case e: Exception =>
        ex = Throwables.getRootCause(e).asInstanceOf[HiveCompactionLockTimeoutException]
    }
    Assert.assertNotNull(ex)
    Assert.assertEquals(LockType.WRITE, ex.getLockType())
    Assert.assertEquals("table1", ex.getTableName())
  }

  private def submitReadLockSleepTimeRunnable(tableNames: Set[String], sleepTimeRunnable: SleepTimeRunnable): java.util.concurrent.Future[_] = {
    val runnable = new Runnable {
      override def run(): Unit = {
        try {
          HiveCompactor.runWithTableCompactionReadLock(lockOptions, tableNames, () => {sleepTimeRunnable.run()})
        } catch {
          case e: Exception =>
            throw new RuntimeException(e)
        }
      }
    }
    executorService.submit(runnable)
  }

  private def submitLockSleepTimeRunnable(tableName: String, lockType: LockType.Value, sleepTimeRunnable: SleepTimeRunnable): java.util.concurrent.Future[_] = {
    val runnable = new Runnable {
      override def run(): Unit = {
        val curatorFramework = HiveCompactor.newCuratorFramework(lockOptions)
        try {
          HiveCompactor.runWithLock(curatorFramework, lockOptions, tableName, lockType, () => {sleepTimeRunnable.run()})
        } catch {
          case e: Exception =>
            throw new RuntimeException(e)
        } finally {
          if (curatorFramework != null) {
            curatorFramework.close()
          }
        }
      }
    }
    executorService.submit(runnable)
  }

  private def assertAtLeastOneOverlap(sleepTimeRunnables: Iterable[SleepTimeRunnable]): Unit = {
    var overlapFound = false
    for (runnable <- sleepTimeRunnables) {
      Assert.assertNotNull(runnable.runInterval)
    }
    breakable {
      for (runnable1 <- sleepTimeRunnables) {
        for (runnable2 <- sleepTimeRunnables) {
          if (runnable1 ne runnable2) { //don't compare to self
            if (runnable1.runInterval.overlaps(runnable2.runInterval)) {
              overlapFound = true
              break
            }
          }
        }
      }
    }
    Assert.assertTrue(overlapFound)
  }

  private def assertNoOverlaps(sleepTimeRunnables: Iterable[SleepTimeRunnable]): Unit = {
    for (runnable1 <- sleepTimeRunnables) {
      for (runnable2 <- sleepTimeRunnables) {
        if (runnable1 ne runnable2) {
          Assert.assertNotNull(runnable1.runInterval)
          Assert.assertNotNull(runnable2.runInterval)
          Assert.assertFalse("Overlap:" + runnable1 + " " + runnable2, runnable1.runInterval.overlaps(runnable2.runInterval))
        }
      }
    }
  }

  class SleepTimeRunnable (val name: String, val sleepMillis: Long) extends Runnable with Callable[Void] {
    
    var runInterval: Interval = _

    override def run(): Unit = {
      val startMillis = System.currentTimeMillis
      System.out.println("SleepTimeRunnable " + name + " started " + startMillis)
      try
        Thread.sleep(sleepMillis)
      catch {
        case e: InterruptedException =>
          throw new RuntimeException(e)
      }
      val endMillis = System.currentTimeMillis
      System.out.println("SleepTimeRunnable " + name + " finished " + endMillis)
      /*
      If an exception is thrown above, runInterval will be null,
      which will cause test errors, which is good, as that will indicates a problem
       */
      runInterval = new Interval(startMillis, endMillis)
    }

    override def call: Void = {
      run()
      null
    }

    override def toString: String = "SleepTimeRunnable{" + "name='" + name + '\'' + ", sleepMillis=" + sleepMillis + ", runInterval=" + runInterval + '}'
  }
}
