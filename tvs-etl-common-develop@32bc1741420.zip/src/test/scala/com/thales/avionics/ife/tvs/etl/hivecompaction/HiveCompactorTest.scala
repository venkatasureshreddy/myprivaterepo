package com.thales.avionics.ife.tvs.etl.hivecompaction

import java.io.{ByteArrayOutputStream, File, FileInputStream}
import java.text.SimpleDateFormat
import java.util.concurrent.TimeUnit
import java.util.{Locale, TimeZone}

import com.google.common.io.{ByteStreams, Files}
import org.apache.commons.io.{Charsets, FileUtils}
import org.apache.hadoop.fs.{FileContext, FileStatus, Path}
import org.junit.Assert.{assertEquals, assertFalse, assertTrue}
import org.junit.Test

import scala.collection.immutable.HashMap

/**
  * Set this environment variable first to run this test:
  * $env:HADOOP_HOME = "C:\Users\ET0184487\thalesdev\hadoop_windows\winutils-master\winutils-master\hadoop-2.7.1"
  **/
class HiveCompactorTest {

  @Test
  def testGetPartitionDate(): Unit = {
    assert(HiveCompactor.getPartitionDate(new Path("abc")).isEmpty)
    assert(HiveCompactor.getPartitionDate(new Path("/airline=AZUL/dir1")).isEmpty)
    assertEquals(1536969600000L, HiveCompactor.getPartitionDate(new Path("/airline=AZUL/year=2018/month=09/day=15")).get)
    assertEquals(1515456000000L, HiveCompactor.getPartitionDate(new Path("/airline=AZUL/year=2018/month=01/day=09")).get)
  }

  @Test
  def testIsOlderThan(): Unit = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    sdf.setTimeZone(TimeZone.getTimeZone("UTC"))
    assertFalse(HiveCompactor.isOlderThan(new Path("abc"), 3, 3L))
    assertFalse(HiveCompactor.isOlderThan(new Path("year=2018/month=09/day=15"), 3, sdf.parse("2018-09-14").getTime))
    assertFalse(HiveCompactor.isOlderThan(new Path("year=2018/month=09/day=15"), 3, sdf.parse("2018-09-15").getTime))
    assertFalse(HiveCompactor.isOlderThan(new Path("year=2018/month=09/day=15"), 3, sdf.parse("2018-09-17").getTime))
    assertFalse(HiveCompactor.isOlderThan(new Path("year=2018/month=09/day=15"), 3, sdf.parse("2018-09-18").getTime))
    assertTrue(HiveCompactor.isOlderThan(new Path("year=2018/month=09/day=15"), 3, sdf.parse("2018-09-19").getTime))
  }

  @Test
  def testHasRecentlyModifiedFiles(): Unit = {
    val tmpDir = Files.createTempDir
    try {
      val fileContext = FileContext.getFileContext()
      val tmpDirPath = new Path(tmpDir.getAbsolutePath)
      val getChildrenFunction = () => {
        val list = new scala.collection.mutable.ArrayBuffer[FileStatus]
        val iter = fileContext.listStatus(tmpDirPath)
        while(iter.hasNext) {
          list.append(iter.next)
        }
        list.toList
      }
      assertFalse(HiveCompactor.hasRecentlyModifiedFiles(getChildrenFunction(), -1, System.currentTimeMillis()))
      assertFalse(HiveCompactor.hasRecentlyModifiedFiles(getChildrenFunction(), 10000, System.currentTimeMillis()))
      val file1 = createFile(new File(tmpDir, "file1"), "file1")
      assertFalse(HiveCompactor.hasRecentlyModifiedFiles(getChildrenFunction(), -1, System.currentTimeMillis()))
      assertTrue(HiveCompactor.hasRecentlyModifiedFiles(getChildrenFunction(), 10, System.currentTimeMillis()))
      file1.setLastModified(System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(30))
      assertFalse(HiveCompactor.hasRecentlyModifiedFiles(getChildrenFunction(), -1, System.currentTimeMillis()))
      assertFalse(HiveCompactor.hasRecentlyModifiedFiles(getChildrenFunction(), 10, System.currentTimeMillis()))
      val file2 = createFile(new File(tmpDir, "file2"), "file2")
      assertFalse(HiveCompactor.hasRecentlyModifiedFiles(getChildrenFunction(), -1, System.currentTimeMillis()))
      assertTrue(HiveCompactor.hasRecentlyModifiedFiles(getChildrenFunction(), 10, System.currentTimeMillis()))
    } finally {
      FileUtils.deleteDirectory(tmpDir)
    }
  }

  @Test
  def testHasFilesSmallerThan(): Unit = {
    val tmpDir = Files.createTempDir
    try {
      val fileContext = FileContext.getFileContext()
      val tmpDirPath = new Path(tmpDir.getAbsolutePath)
      val getChildrenFunction = () => {
        val list = new scala.collection.mutable.ArrayBuffer[FileStatus]
        val iter = fileContext.listStatus(tmpDirPath)
        while(iter.hasNext) {
          list.append(iter.next)
        }
        list.toList
      }
      assertFalse(HiveCompactor.hasFilesSmallerThan(getChildrenFunction(), 3))
      val file1 = createFile(new File(tmpDir, "file1"), "file1WithLotsOfData")
      assertFalse(HiveCompactor.hasFilesSmallerThan(getChildrenFunction(), 3))
      val file2 = createFile(new File(tmpDir, "file2"), "f")
      assertTrue(HiveCompactor.hasFilesSmallerThan(getChildrenFunction(), 3))
    } finally {
      FileUtils.deleteDirectory(tmpDir)
    }
  }

  @Test
  def testSortForLocking(): Unit = {
    assertEquals(List("table1", "table3", "table7"), HiveCompactor.sortForLocking(Seq("table3", "table1", "table7")))
    assertEquals(List(HiveTable("table1", "path3"), HiveTable("table3", "path2"), HiveTable("table7", "path1")),
      HiveCompactor.sortHiveTablesForLocking(Seq(HiveTable("table1", "path3"), HiveTable("table3", "path2"), HiveTable("table7", "path1"))))
  }

  @Test
  def testGetZkLockPath(): Unit = {
    assertEquals("base/table1", HiveCompactor.getZkLockPath("base", "table1"))
    assertEquals("base/table1", HiveCompactor.getZkLockPath("base/", "table1"))
    assertEquals("/base/table1", HiveCompactor.getZkLockPath("/base", "table1"))
    assertEquals("/base/table1", HiveCompactor.getZkLockPath("/base/", "table1"))
  }

  @Test
  def testGetTableOptions(): Unit = {
    val options = new HiveCompactorOptions()
    val table1 = HiveTable("table1", "dir1")
    assertEquals(3, HiveCompactor.getTableOptions(options, table1).minFilesToCompact)
    options.hiveTableOptions = new HashMap[String, HiveCompactorTableOptions]
    assertEquals(3, HiveCompactor.getTableOptions(options, table1).minFilesToCompact)
    val table1Options = new HiveCompactorTableOptions()
    table1Options.minFilesToCompact = 4
    options.hiveTableOptions = Map[String, HiveCompactorTableOptions](("table1", table1Options))
    val table2 = HiveTable("table2", "dir2")
    assertEquals(4, HiveCompactor.getTableOptions(options, table1).minFilesToCompact)
    assertEquals(3, HiveCompactor.getTableOptions(options, table2).minFilesToCompact)
    val defaultTableOptions = new HiveCompactorTableOptions()
    defaultTableOptions.minFilesToCompact = 5
    options.defaultHiveTableOptions = defaultTableOptions
    assertEquals(4, HiveCompactor.getTableOptions(options, table1).minFilesToCompact)
    assertEquals(5, HiveCompactor.getTableOptions(options, table2).minFilesToCompact)
  }

  @Test
  def testMain(): Unit = {
    testMain(1)
    testMain(5)
  }

  private def testMain(numThreads: Int): Unit = {
    val testDir = Files.createTempDir
    try {
      val tmpDir = mkdir(testDir, "tmp")
      val baseHiveDir = mkdir(testDir, "hive")
      //this will be compacted
      val dataDir1 = mkdir(baseHiveDir, "seatsession", "airline=AZUL", "year=2018", "month=10", "day=12")
      createFile(new File(dataDir1, "file1"), "file1\nline2")
      createFile(new File(dataDir1, "file2"), "file2\nline_abc")
      createFile(new File(dataDir1, "file3"), "file3\nline_def\nabc\n")
      //not compacted
      val dataDir2 = mkdir(baseHiveDir, "seatsession", "airline=AZUL", "year=2018", "month=10", "day=13")
      val file4 = createFile(new File(dataDir2, "file3"), "Hello\nblah\nBob")
      HiveCompactorMain.main(Array[String]("-tables",
        "table1::" + baseHiveDir.getAbsolutePath,
        "-tmpDir", tmpDir.getAbsolutePath,
        //hdfs compression does not work on Windows
        "-compress", "false",
        "-minMinutesForRecentlyWrittenFiles", "-1",
        "-maxDaysAgoToProcess", "-1",
        "-maxFilesPerDirectory", "2",
        "-threads", numThreads.toString))
      assertEquals(1, listFilesNoCrc(dataDir1).length)
      assertEquals(1, listFilesNoCrc(dataDir2).length)
      assertEquals(0, listFilesNoCrc(tmpDir).length)
      val compactedFiles = getCompactedFileInDir(dataDir1)
      assertEquals(1, compactedFiles.length)
      val compactedFile = compactedFiles(0)
      assertTrue(compactedFile.getName.endsWith(".txt"))
      assertEquals("file1\nline2\nfile2\nline_abc\nfile3\nline_def\nabc", readFile(compactedFile))
      assertEquals("Hello\nblah\nBob", readFile(file4))
    } finally {
      FileUtils.deleteDirectory(testDir)
    }
  }

  @Test
  def testGetChildrenToCompact(): Unit = {
    val tmpDir = Files.createTempDir()
    try {
      val baseDir = new File(tmpDir, "day=12")
      if(!baseDir.mkdir()) {
        throw new RuntimeException("Could not create baseDir")
      }
      val fileContext = FileContext.getFileContext()
      val tableOptions = new HiveCompactorTableOptions()
      assertTrue(HiveCompactor.getChildrenToCompact(fileContext, tableOptions, fileContext.getFileStatus(new Path(tmpDir.getAbsolutePath))).isEmpty)
      val baseDirFileStatus = fileContext.getFileStatus(new Path(baseDir.getAbsolutePath))
      assertTrue(HiveCompactor.getChildrenToCompact(fileContext, tableOptions, baseDirFileStatus).isEmpty)
      createFile(new File(baseDir, ".hiddenFile1"), "hiddenFile1")
      if(!new File(baseDir, "dir1").mkdir()) {
        throw new RuntimeException("Could not create dir1")
      }
      tableOptions.maxDaysAgoToProcess = -1
      assertTrue(HiveCompactor.getChildrenToCompact(fileContext, tableOptions, baseDirFileStatus).isEmpty)
      createFile(new File(baseDir, "file1"), "file1")
      assertTrue(HiveCompactor.getChildrenToCompact(fileContext, tableOptions, baseDirFileStatus).isEmpty)
      createFile(new File(baseDir, "file2"), "file2")
      assertTrue(HiveCompactor.getChildrenToCompact(fileContext, tableOptions, baseDirFileStatus).isEmpty)
      createFile(new File(baseDir, "file3"), "file3")
      assertTrue(HiveCompactor.getChildrenToCompact(fileContext, tableOptions, baseDirFileStatus).isEmpty)
      tableOptions.maxFilesPerDirectory = 2
      assertSameFileNames(Seq("file1", "file2", "file3"), HiveCompactor.getChildrenToCompact(fileContext, tableOptions, baseDirFileStatus))
      tableOptions.maxFilesPerDirectory = 4
      createFile(new File(baseDir, "file4"), "file4")
      createFile(new File(baseDir, "file5"), "file5")
      assertSameFileNames(Seq("file1", "file2", "file3", "file4", "file5"), HiveCompactor.getChildrenToCompact(fileContext, tableOptions, baseDirFileStatus))
      tableOptions.maxFilesPerDirectory = 6
      assertTrue(HiveCompactor.getChildrenToCompact(fileContext, tableOptions, baseDirFileStatus).isEmpty)
      for(file <- baseDir.listFiles()) {
        val moreThanMinMinutesForRecentlyWrittenFilesAgoMillis = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(60)
        if(file.getName.startsWith("file")) {
          if(!file.setLastModified(moreThanMinMinutesForRecentlyWrittenFilesAgoMillis)) {
            throw new RuntimeException(s"Could not update last modified time ${file.getAbsolutePath}")
          }
        }
      }
      assertSameFileNames(Seq("file1", "file2", "file3", "file4", "file5"), HiveCompactor.getChildrenToCompact(fileContext, tableOptions, baseDirFileStatus))
    } finally {
      FileUtils.deleteDirectory(tmpDir)
    }
  }

  private def assertSameFileNames(expected: Seq[String], actual: Seq[Path]): Unit = {
    //order doesn't matter so compare Sets
    assertEquals(expected.toSet, actual.map((path: Path) => path.getName).toSet)
  }

  private def getCompactedFileInDir(dir: File) = {
    dir.listFiles().filter((file: File) => file.getName.startsWith("compacted"))
  }

  private def listFilesNoCrc(dir: File) = {
    dir.listFiles().filter((file: File) => !file.getName.toLowerCase(Locale.ENGLISH).endsWith(".crc"))
  }

  private def mkdir(parent: File, names: String*) = {
    assert(names.nonEmpty, "Invalid names")
    var dir: File = null
    var parentTmp = parent
    for (name <- names) {
      dir = new File(parentTmp, name)
      if (!dir.isDirectory) assert(dir.mkdir, "Could not create directory " + dir.getAbsolutePath)
      parentTmp = dir
    }
    dir
  }

  private def createFile(file: File, content: String) = {
    Files.write(content.getBytes(Charsets.UTF_8), file)
    file
  }

  private def readFile(file: File) = {
    val baos = new ByteArrayOutputStream
    try {
      val is = new FileInputStream(file)
      try
        ByteStreams.copy(is, baos)
      finally {
        if (is != null) {
          is.close()
        }
      }
    }
    new String(baos.toByteArray, Charsets.UTF_8)
  }

}
