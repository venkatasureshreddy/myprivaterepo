package com.thales.avionics.ife.tvs.etl

import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.mockito.Mockito.when
import org.scalatest.BeforeAndAfter
import org.scalatest.FunSuite
import org.scalatest.mock.MockitoSugar

import com.holdenkarau.spark.testing.DataFrameSuiteBase

abstract class ETLTestBase extends FunSuite with DataFrameSuiteBase with BeforeAndAfter with MockitoSugar {

  var testData: TestDataLoader = _
  var etlContext: ETLContext = _
  var phoenix: PhoenixPersistence = _

  val debugFlag = System.getProperty("test.debug", "false") == "true"

  def getTestDataLoaderSubdirectory(): Option[String] = None

  def getFlightProductStatusFilters(): Array[String]

  override def conf(): SparkConf = {
    super.conf
      .set("spark.ui.enabled", System.getProperty("test.spark.ui.enabled", "false"))
      .set("spark.ui.port", System.getProperty("test.spark.ui.port", "4040"))
      .set("spark.sql.shuffle.partitions", System.getProperty("test.spark.sql.shuffle.partitions", "10"))
  }

  before {
    phoenix = mock[PhoenixPersistence]
    testData = new TestDataLoader(sc, sqlContext, getTestDataLoaderSubdirectory match {
      case Some(subdir) => subdir
      case None => ""
    })
    when(phoenix.load("flight_product_status")).thenReturn(testData.getUnfiltered())

    etlContext = new ETLContext(new FlightProductStatus(phoenix, 50000, getFlightProductStatusFilters()), sqlContext, phoenix, ETLConfig(logDatabase = None, phoenixDatabase = "main", phoenixZookeeperUrl = "", maxNumOfFlightsPerRun = 500, zookeeperUrl = "", applicationName = "doesntmatter", logTables = Array()))

    if (!debugFlag) {
      sc.setLogLevel("ERROR")
      Logger.getLogger("org.apache.spark.util.ShutdownHookManager").setLevel(Level.OFF)
      Logger.getLogger("org.apache.spark.scheduler.DAGScheduler").setLevel(Level.OFF)
    }
  }

}