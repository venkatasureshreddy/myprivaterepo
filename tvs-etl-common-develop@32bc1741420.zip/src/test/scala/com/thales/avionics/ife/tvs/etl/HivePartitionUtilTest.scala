package com.thales.avionics.ife.tvs.etl

import com.thales.avionics.ife.tvs.etl.HivePartitionUtil.YearMonthDayTree
import org.scalatest.FunSuite

class HivePartitionUtilTest extends FunSuite {

  test("getHiveWhere") {
    val logFlightIds = scala.collection.mutable.Set[String]()
    val airlineMap = scala.collection.mutable.Map[String, YearMonthDayTree]()
    assert("false" == HivePartitionUtil.getHiveWhere(logFlightIds, airlineMap))

    logFlightIds.add("flight1")
    val airline1YearMonthDayTree = new YearMonthDayTree()
    airline1YearMonthDayTree.add(2018, 10, 15)
    airlineMap.put("airline1", airline1YearMonthDayTree)
    assert("(logs.airline = 'airline1' AND ((year = '2018' and month = '10' and day in ('15')))) AND logs.flight_id in ('flight1')" == HivePartitionUtil.getHiveWhere(logFlightIds, airlineMap))
    airline1YearMonthDayTree.add(2018, 10, 16)
    assert("(logs.airline = 'airline1' AND ((year = '2018' and month = '10' and day in ('15','16')))) AND logs.flight_id in ('flight1')" == HivePartitionUtil.getHiveWhere(logFlightIds, airlineMap))
    airline1YearMonthDayTree.add(2018, 11, 1)
    assert("(logs.airline = 'airline1' AND ((year = '2018' and month = '10' and day in ('15','16')) OR (year = '2018' and month = '11' and day in ('01')))) AND logs.flight_id in ('flight1')" == HivePartitionUtil.getHiveWhere(logFlightIds, airlineMap))

    logFlightIds.add("flight2")
    airline1YearMonthDayTree.add(2018, 10, 15)
    assert("(logs.airline = 'airline1' AND ((year = '2018' and month = '10' and day in ('15','16')) OR (year = '2018' and month = '11' and day in ('01')))) AND logs.flight_id in ('flight1','flight2')" == HivePartitionUtil.getHiveWhere(logFlightIds, airlineMap))

    logFlightIds.add("flight2")
    val airline2YearMonthDayTree = new YearMonthDayTree()
    airlineMap.put("airline2", airline2YearMonthDayTree)
    airline2YearMonthDayTree.add(2018, 6, 15)
    assert("(logs.airline = 'airline1' AND ((year = '2018' and month = '10' and day in ('15','16')) OR (year = '2018' and month = '11' and day in ('01')))) OR (logs.airline = 'airline2' AND ((year = '2018' and month = '06' and day in ('15')))) AND logs.flight_id in ('flight1','flight2')" == HivePartitionUtil.getHiveWhere(logFlightIds, airlineMap))
  }

  test("YearMonthDayTree") {
    val yearMonthDayTree = new YearMonthDayTree()
    yearMonthDayTree.add(2018, 10, 15)
    assert("((year = '2018' and month = '10' and day in ('15')))" == yearMonthDayTree.toSqlQuery())
    yearMonthDayTree.add(2018, 10, 16)
    assert("((year = '2018' and month = '10' and day in ('15','16')))" == yearMonthDayTree.toSqlQuery())
    yearMonthDayTree.add(2018, 10, 17)
    assert("((year = '2018' and month = '10' and day in ('15','16','17')))" == yearMonthDayTree.toSqlQuery())
    yearMonthDayTree.add(2018, 11, 1)
    assert("((year = '2018' and month = '10' and day in ('15','16','17')) OR (year = '2018' and month = '11' and day in ('01')))" == yearMonthDayTree.toSqlQuery())
    yearMonthDayTree.add(2018, 11, 2)
    assert("((year = '2018' and month = '10' and day in ('15','16','17')) OR (year = '2018' and month = '11' and day in ('01','02')))" == yearMonthDayTree.toSqlQuery())
    yearMonthDayTree.add(2019, 1, 1)
    assert("((year = '2018' and month = '10' and day in ('15','16','17')) OR (year = '2018' and month = '11' and day in ('01','02')) OR (year = '2019' and month = '01' and day in ('01')))" == yearMonthDayTree.toSqlQuery())

  }

}
