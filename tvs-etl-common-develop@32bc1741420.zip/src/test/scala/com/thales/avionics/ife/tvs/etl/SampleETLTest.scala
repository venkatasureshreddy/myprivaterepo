package com.thales.avionics.ife.tvs

import com.thales.avionics.ife.tvs.etl.ETLTestBase
import org.apache.spark.sql.functions._

class SampleETLTest extends ETLTestBase {

  override def getTestDataLoaderSubdirectory(): Option[String] = Some("/sample-etl")

  override def getFlightProductStatusFilters(): Array[String] = Array("flight_id='ABC123'")

  /**
   * The sample-etl folder in resources contains data for 2 flights: "ABC123" and "DEF456", but this test configures a flightProductStatusFilter that should only match "ABC123".
   * So, when we select logs, we should only see records for flight "ABC123".
   */
  test("ETLContext only loads logs for pending flights") {

    val sqlContext = etlContext.sqlContext

    assert(etlContext.flightProductStatus.getUnfiltered().count() == 2)
    assert(etlContext.flightProductStatus.getFiltered().count() == 1)
    assert(etlContext.flightProductStatus.getFiltered().rdd.toArray()(0).getAs[String]("flight_id") == "ABC123")

    testData.loadHiveLogTable("svcstates")

    val logs = etlContext.selectLogs("stvplus_svcstates")

    logs.show(false)

    assert(logs.count() == 5)
    assert(logs.select("flight_id").distinct().count() == 1)
    assert(logs.select("flight_id").distinct().rdd.toArray()(0).getAs[String]("flight_id").equals("ABC123"))
  }

}