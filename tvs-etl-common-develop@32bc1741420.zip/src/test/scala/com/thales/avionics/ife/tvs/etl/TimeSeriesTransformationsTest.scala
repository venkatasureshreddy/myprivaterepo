//package com.thales.avionics.ife.tvs.etl
//
//import com.holdenkarau.spark.testing.DataFrameSuiteBase
//import org.scalatest.FunSuite
//import java.sql.Timestamp
//
//private case class ExampleTimeseriesRecord(
//  ts: Timestamp, flight_id: String, device_id: String, fault_count: Int, status: String, speed: Double)
//
//class TimeSeriesTransformationsTest extends FunSuite with DataFrameSuiteBase {
//
//  test("reduce noise keeps the expected records") {
//
//    import sqlContext.implicits._
//
//    /**
//     * Lines in the sequence below ending in '//' are expected to appear in the result.
//     */
//    val input = sc.parallelize(Seq(
//      ExampleTimeseriesRecord(new Timestamp(0), "abc", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(1), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(2), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(3), "abc", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(4), "abc", "ZEB", 0, "BAD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(5), "abc", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(6), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(7), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(8), "abc", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(9), "abc", "ZEB", 0, "GOOD", 80.1), //
//      ExampleTimeseriesRecord(new Timestamp(10), "abc", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(11), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(12), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(13), "abc", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(14), "abc", "ZEB", 2, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(15), "abc", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(16), "abc", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(17), "abc", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(18), "abc", "ZEB", 2, "GOOD", 99.9), //
//
//      ExampleTimeseriesRecord(new Timestamp(0), "abc", "ANTENNA", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(1), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(2), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(3), "abc", "ANTENNA", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(4), "abc", "ANTENNA", 0, "BAD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(5), "abc", "ANTENNA", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(6), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(7), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(8), "abc", "ANTENNA", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(9), "abc", "ANTENNA", 0, "GOOD", 80.1), //
//      ExampleTimeseriesRecord(new Timestamp(10), "abc", "ANTENNA", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(11), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(12), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(13), "abc", "ANTENNA", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(14), "abc", "ANTENNA", 2, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(15), "abc", "ANTENNA", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(16), "abc", "ANTENNA", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(17), "abc", "ANTENNA", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(18), "abc", "ANTENNA", 2, "GOOD", 99.9), //
//
//      ExampleTimeseriesRecord(new Timestamp(0), "xyz", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(1), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(2), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(3), "xyz", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(4), "xyz", "ZEB", 0, "BAD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(5), "xyz", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(6), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(7), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(8), "xyz", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(9), "xyz", "ZEB", 0, "GOOD", 80.1), //
//      ExampleTimeseriesRecord(new Timestamp(10), "xyz", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(11), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(12), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(13), "xyz", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(14), "xyz", "ZEB", 2, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(15), "xyz", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(16), "xyz", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(17), "xyz", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(18), "xyz", "ZEB", 2, "GOOD", 99.9), //
//
//      ExampleTimeseriesRecord(new Timestamp(0), "xyz", "ANTENNA", 0, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(1), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(2), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(3), "xyz", "ANTENNA", 0, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(4), "xyz", "ANTENNA", 0, "MEH", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(5), "xyz", "ANTENNA", 0, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(6), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(7), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(8), "xyz", "ANTENNA", 0, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(9), "xyz", "ANTENNA", 0, "OK", 66.5), //
//      ExampleTimeseriesRecord(new Timestamp(10), "xyz", "ANTENNA", 0, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(11), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(12), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(13), "xyz", "ANTENNA", 0, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(14), "xyz", "ANTENNA", 2, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(15), "xyz", "ANTENNA", 2, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(16), "xyz", "ANTENNA", 2, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(17), "xyz", "ANTENNA", 2, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(18), "xyz", "ANTENNA", 2, "OK", 99.9) //
//
//    ), 1).toDF().coalesce(1)
//
//    input.show(500, false)
//
//    val result = input.transform(TimeSeriesTransformations.reduceNoise(
//      timestamp = $"ts",
//      keys = Seq($"flight_id", $"device_id"),
//      values = Seq($"fault_count", $"status", $"speed")))
//
//    result.sort($"flight_id", $"device_id", $"ts").show(500, false)
//
//    // 10 records expected for each device on each flight, 2 devices on each flight, 2 flights
//    assert(result.count() == 40)
//  }
//  
//  test("first, last and on change records") {
//
//    import sqlContext.implicits._
//
//    /**
//     * Lines in the sequence below ending in '//' are expected to appear in the result.
//     */
//    val input = sc.parallelize(Seq(
//      ExampleTimeseriesRecord(new Timestamp(0), "abc", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(1), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(2), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(3), "abc", "ZEB", 0, "GOOD", 99.9), 
//      ExampleTimeseriesRecord(new Timestamp(4), "abc", "ZEB", 0, "BAD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(5), "abc", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(6), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(7), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(8), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(9), "abc", "ZEB", 0, "GOOD", 80.1), //
//      ExampleTimeseriesRecord(new Timestamp(10), "abc", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(11), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(12), "abc", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(13), "abc", "ZEB", 0, "GOOD", 99.9), 
//      ExampleTimeseriesRecord(new Timestamp(14), "abc", "ZEB", 2, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(15), "abc", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(16), "abc", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(17), "abc", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(18), "abc", "ZEB", 2, "GOOD", 99.9), //
//
//      ExampleTimeseriesRecord(new Timestamp(0), "abc", "ANTENNA", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(1), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(2), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(3), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(4), "abc", "ANTENNA", 0, "BAD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(5), "abc", "ANTENNA", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(6), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(7), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(8), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(9), "abc", "ANTENNA", 0, "GOOD", 80.1), //
//      ExampleTimeseriesRecord(new Timestamp(10), "abc", "ANTENNA", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(11), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(12), "abc", "ANTENNA", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(13), "abc", "ANTENNA", 0, "GOOD", 99.9), 
//      ExampleTimeseriesRecord(new Timestamp(14), "abc", "ANTENNA", 2, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(15), "abc", "ANTENNA", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(16), "abc", "ANTENNA", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(17), "abc", "ANTENNA", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(18), "abc", "ANTENNA", 2, "GOOD", 99.9), //
//
//      ExampleTimeseriesRecord(new Timestamp(0), "xyz", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(1), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(2), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(3), "xyz", "ZEB", 0, "GOOD", 99.9), 
//      ExampleTimeseriesRecord(new Timestamp(4), "xyz", "ZEB", 0, "BAD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(5), "xyz", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(6), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(7), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(8), "xyz", "ZEB", 0, "GOOD", 99.9), 
//      ExampleTimeseriesRecord(new Timestamp(9), "xyz", "ZEB", 0, "GOOD", 80.1), //
//      ExampleTimeseriesRecord(new Timestamp(10), "xyz", "ZEB", 0, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(11), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(12), "xyz", "ZEB", 0, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(13), "xyz", "ZEB", 0, "GOOD", 99.9), 
//      ExampleTimeseriesRecord(new Timestamp(14), "xyz", "ZEB", 2, "GOOD", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(15), "xyz", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(16), "xyz", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(17), "xyz", "ZEB", 2, "GOOD", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(18), "xyz", "ZEB", 2, "GOOD", 99.9),//
//
//      ExampleTimeseriesRecord(new Timestamp(0), "xyz", "ANTENNA", 0, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(1), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(2), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(3), "xyz", "ANTENNA", 0, "OK", 99.9), 
//      ExampleTimeseriesRecord(new Timestamp(4), "xyz", "ANTENNA", 0, "MEH", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(5), "xyz", "ANTENNA", 0, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(6), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(7), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(8), "xyz", "ANTENNA", 0, "OK", 99.9), 
//      ExampleTimeseriesRecord(new Timestamp(9), "xyz", "ANTENNA", 0, "OK", 66.5), //
//      ExampleTimeseriesRecord(new Timestamp(10), "xyz", "ANTENNA", 0, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(11), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(12), "xyz", "ANTENNA", 0, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(13), "xyz", "ANTENNA", 0, "OK", 99.9), 
//      ExampleTimeseriesRecord(new Timestamp(14), "xyz", "ANTENNA", 2, "OK", 99.9), //
//      ExampleTimeseriesRecord(new Timestamp(15), "xyz", "ANTENNA", 2, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(16), "xyz", "ANTENNA", 2, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(17), "xyz", "ANTENNA", 2, "OK", 99.9),
//      ExampleTimeseriesRecord(new Timestamp(18), "xyz", "ANTENNA", 2, "OK", 99.9)//
//
//    ), 1).toDF().coalesce(1)
//
//    input.show(false)
//
//    val result = input.transform(TimeSeriesTransformations.firstLastOnChange(
//      timestamp = $"ts",
//      keys = Seq($"flight_id", $"device_id"),
//      values = Seq($"fault_count", $"status", $"speed")))
//      result.sort($"flight_id", $"device_id", $"ts").show(500, false)
//
//    // 7 records expected for each device on each flight, 2 devices on each flight, 2 flights
//    assert(result.count() == 28)
//  }
//
//}