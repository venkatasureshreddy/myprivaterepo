package com.thales.avionics.ife.tvs.etl.hivecompaction

import org.junit.{Assert, Test}

class HiveCompactorOptionsTest {

  @Test
  def testSafeGetArgString(): Unit = {
    Assert.assertEquals("abc", HiveCompactorOptions.safeGetArgString(None, "abc"))
    Assert.assertEquals("abc", HiveCompactorOptions.safeGetArgString(Some(null), "abc"))
    Assert.assertEquals("abc", HiveCompactorOptions.safeGetArgString(Some(""), "abc"))
    Assert.assertEquals("abc", HiveCompactorOptions.safeGetArgString(Some("null"), "abc"))
    Assert.assertEquals("def", HiveCompactorOptions.safeGetArgString(Some("def"), "abc"))
  }

  @Test
  def testSafeParseInt(): Unit = {
    Assert.assertEquals(1, HiveCompactorOptions.safeParseInt(None, 1))
    Assert.assertEquals(1, HiveCompactorOptions.safeParseInt(Some(null), 1))
    Assert.assertEquals(1, HiveCompactorOptions.safeParseInt(Some(""), 1))
    Assert.assertEquals(1, HiveCompactorOptions.safeParseInt(Some("null"), 1))
    Assert.assertEquals(123, HiveCompactorOptions.safeParseInt(Some("123"), 1))
  }

  @Test
  def testSafeParseBoolean(): Unit = {
    Assert.assertTrue(HiveCompactorOptions.safeParseBoolean(None, true))
    Assert.assertTrue(HiveCompactorOptions.safeParseBoolean(Some(null), true))
    Assert.assertTrue(HiveCompactorOptions.safeParseBoolean(Some(""), true))
    Assert.assertTrue(HiveCompactorOptions.safeParseBoolean(Some("null"), true))
    Assert.assertFalse(HiveCompactorOptions.safeParseBoolean(Some("123"), true))
    Assert.assertFalse(HiveCompactorOptions.safeParseBoolean(Some("false"), true))
    Assert.assertTrue(HiveCompactorOptions.safeParseBoolean(Some("true"), false))
  }

  @Test
  def testFromJson(): Unit = {
    var options = HiveCompactorOptions.fromJson(null)
    //verify that defaults are used
    Assert.assertEquals(1000, options.queueCapacity)
    Assert.assertNotNull(options)
    options = HiveCompactorOptions.fromJson("{\"ignoreErrors\":\"true\"}")
    Assert.assertNotNull(options)
    //verify json value is set
    Assert.assertTrue(options.ignoreErrors)
    //verify that value not in json is a default value
    Assert.assertEquals(1000, options.queueCapacity)
    Assert.assertNull(options.lockOptions)
    options = HiveCompactorOptions.fromJson("{\"ignoreErrors\":\"true\",\"lockOptions\":{\"lockZooKeeperUrl\":\"zkUrl123\"}}")
    Assert.assertNotNull(options)
    Assert.assertTrue(options.ignoreErrors)
    //verify that value not in json is a default value
    Assert.assertEquals(1000, options.queueCapacity)
    Assert.assertNotNull(options.lockOptions)
    Assert.assertEquals("zkUrl123", options.lockOptions.lockZooKeeperUrl)
    Assert.assertEquals(5, options.lockOptions.lockMaxRetries)
    Assert.assertNull(options.hiveTables)
    options = HiveCompactorOptions.fromJson("{\"hiveTables\":[{\"name\":\"table1\",\"baseHdfsDir\":\"path1\"},{\"name\":\"table2\",\"baseHdfsDir\":\"path2\"}]}")
    Assert.assertEquals(Seq(HiveTable("table1", "path1"), HiveTable("table2", "path2")), options.hiveTables)
    options = HiveCompactorOptions.fromJson("{\"defaultHiveTableOptions\":{\"minFilesToCompact\":7}}")
    Assert.assertEquals(7, options.defaultHiveTableOptions.minFilesToCompact)
    Assert.assertEquals(60, options.defaultHiveTableOptions.maxDaysAgoToProcess)
    options = HiveCompactorOptions.fromJson("{\"hiveTableOptions\":{\"table1\":{\"minFilesToCompact\":7},\"table2\":{\"minFilesToCompact\":9}}}")
    Assert.assertEquals(2, options.hiveTableOptions.size)
    Assert.assertEquals(7, options.hiveTableOptions("table1").minFilesToCompact)
    Assert.assertEquals(60, options.hiveTableOptions("table1").maxDaysAgoToProcess)
    Assert.assertEquals(9, options.hiveTableOptions("table2").minFilesToCompact)
    Assert.assertEquals(60, options.hiveTableOptions("table2").maxDaysAgoToProcess)

    options = HiveCompactorOptions.fromJson(
      """
       |{
       |	"ignoreErrors": "true",
       |	"lockOptions": {
       |		"lockZooKeeperUrl": "zkUrl123"
       |	},
       |	"hiveTables": [{
       |		"name": "table1",
       |		"baseHdfsDir": "path1"
       |	},
       |	{
       |		"name": "table2",
       |		"baseHdfsDir": "path2"
       |	}],
       |	"defaultHiveTableOptions": {
       |		"minFilesToCompact": 7
       |	},
       |	"hiveTableOptions": {
       |		"table1": {
       |			"minFilesToCompact": 7
       |		},
       |		"table2": {
       |			"minFilesToCompact": 9
       |		}
       |	}
       |}
      """.stripMargin)
    Assert.assertTrue(options.ignoreErrors)
    Assert.assertEquals(1000, options.queueCapacity)
    Assert.assertNotNull(options.lockOptions)
    Assert.assertEquals("zkUrl123", options.lockOptions.lockZooKeeperUrl)
    Assert.assertEquals(5, options.lockOptions.lockMaxRetries)
    Assert.assertEquals(Seq(HiveTable("table1", "path1"), HiveTable("table2", "path2")), options.hiveTables)
    Assert.assertEquals(2, options.hiveTableOptions.size)
    Assert.assertEquals(7, options.hiveTableOptions("table1").minFilesToCompact)
    Assert.assertEquals(60, options.hiveTableOptions("table1").maxDaysAgoToProcess)
    Assert.assertEquals(9, options.hiveTableOptions("table2").minFilesToCompact)
    Assert.assertEquals(60, options.hiveTableOptions("table2").maxDaysAgoToProcess)
  }

}
