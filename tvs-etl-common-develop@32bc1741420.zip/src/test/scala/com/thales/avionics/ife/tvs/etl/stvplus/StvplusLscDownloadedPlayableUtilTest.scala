package com.thales.avionics.ife.tvs.etl.stvplus

import org.junit.Assert
import org.scalatest.FunSuite

class StvplusLscDownloadedPlayableUtilTest extends FunSuite {

  test("parseLscDownloadedPlayableJson") {
    assert(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null) == StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable(null))
    assert(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null) == StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{"))
    assert(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null) == StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("not_valid_json"))
    assert(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null) == StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{}"))
    assert(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null) == StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"downloaded_hv_content_percentage\":\"abc\",\"playable_hv_content_percentage\":\"def\"}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0.5d, false, 0.8d, false, null), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"downloaded_hv_content_percentage\":\"0.5\",\"playable_hv_content_percentage\":\"0.8\"}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0.5d, false, 0.8d, false, null), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"downloaded_hv_content_percentage\":\"0.5\",\"playable_hv_content_percentage\":\"0.8\",\"hv_content_list\":[]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(-1d, false, -1d, false, null), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"downloaded_hv_content_percentage\":\"-1\",\"playable_hv_content_percentage\":\"-1\",\"hv_content_list\":[]}"))
    assert(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null) == StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":\"0.5\"}"))
    assert(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null) == StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[]}"))
    assert(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null) == StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"abc\":\"true\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0d, true, 0d, true, null), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"abc\":\"true\"}]}"))
    assert(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null) == StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"downloaded\":\"true\",\"license_available\":\"true\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(1d, true, 1d, true, 1d), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":\"true\",\"license_available\":\"true\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(-1d, false, -1d, false, null), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"downloaded_hv_content_percentage\":\"-1\",\"playable_hv_content_percentage\":\"-1\",\"hv_content_list\":[{\"downloaded\":\"true\",\"license_available\":\"true\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(-1d, false, -1d, false, null), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"content_id\":\"movie1\",\"downloaded_hv_content_percentage\":\"-1\",\"playable_hv_content_percentage\":\"-1\",\"hv_content_list\":[{\"downloaded\":\"true\",\"license_available\":\"true\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0d, true, 0d, true, null), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":\"false\",\"license_available\":\"false\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0d, true, 1d, true, null), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":\"false\",\"license_available\":\"true\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0d, true, 1d, true, 0d), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":false,\"license_available\":true}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(1d, true, 0d, true, 0d), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":\"true\",\"license_available\":\"false\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(1d, true, 1d, true, 1d), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"downloaded_hv_content_percentage\":\"0.5\",\"playable_hv_content_percentage\":\"0.8\",\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":\"TRUE\",\"license_available\":\"TRUE\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0.5d, true, 0.25d, true, 0d), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":\"true\",\"license_available\":\"false\"},{\"content_id\":\"movie2\",\"downloaded\":\"false\",\"license_available\":\"true\"},{\"content_id\":\"movie3\",\"downloaded\":\"true\",\"license_available\":\"false\"},{\"content_id\":\"movie4\",\"downloaded\":\"false\",\"license_available\":\"false\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0d, true, 0d, true, 0d), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":\"false\",\"license_available\":\"false\"},{\"content_id\":\"movie1\",\"downloaded\":\"true\",\"license_available\":\"true\"},{\"content_id\":\"movie1\",\"downloaded\":\"true\",\"license_available\":\"false\"},{\"content_id\":\"movie1\",\"downloaded\":\"false\",\"license_available\":\"true\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0.33d, true, 0d, true, 0d), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":\"false\",\"license_available\":\"false\"},{\"content_id\":\"movie1\",\"downloaded\":\"true\",\"license_available\":\"true\"},{\"content_id\":\"movie2\",\"downloaded\":\"true\",\"license_available\":\"false\"},{\"content_id\":\"movie3\",\"downloaded\":\"false\",\"license_available\":\"false\"}]}"))
    assertEquals(StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(0.5d, true, .25d, true, 0.25d), StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable("{\"hv_content_list\":[{\"content_id\":\"movie1\",\"downloaded\":\"false\",\"license_available\":\"false\"},{\"content_id\":\"movie1\",\"downloaded\":\"true\",\"license_available\":\"true\"},{\"content_id\":\"movie2\",\"downloaded\":\"true\",\"license_available\":\"false\"},{\"content_id\":\"movie3\",\"downloaded\":\"false\",\"license_available\":\"false\"},{\"content_id\":\"movie4\",\"downloaded\":\"true\",\"license_available\":\"true\"}]}"))
  }

  test("LscDownloadedPlayableSerialize") {
    var lscDownloadedPlayable = StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(null, false, null, false, null)
    assert(StvplusLscDownloadedPlayableUtil.deserialize(StvplusLscDownloadedPlayableUtil.serialize(lscDownloadedPlayable)) == lscDownloadedPlayable)
    lscDownloadedPlayable = StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable(1d, true, 2d, true, 3d)
    assert(StvplusLscDownloadedPlayableUtil.deserialize(StvplusLscDownloadedPlayableUtil.serialize(lscDownloadedPlayable)) == lscDownloadedPlayable)
  }

  private def assertEquals(expected: StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable,
                           actual: StvplusLscDownloadedPlayableUtil.LscDownloadedPlayable): Unit = {
    assertClose(expected.downloadedPct, actual.downloadedPct)
    Assert.assertEquals(expected.downloadedPctCalculatedFromHvContentList, actual.downloadedPctCalculatedFromHvContentList)
    assertClose(expected.playablePct, actual.playablePct)
    Assert.assertEquals(expected.playablePctCalculatedFromHvContentList, actual.playablePctCalculatedFromHvContentList)
    assertClose(expected.downloadedAndPlayablePct, actual.downloadedAndPlayablePct)
  }

  private def assertClose(d1: java.lang.Double, d2: java.lang.Double): Unit = {
    var equals: Option[Boolean] = None
    if(d1 == null) {
      if(d2 != null) {
        equals = Some(false)
      } else {
        equals = Some(true)
      }
    } else {
      if(d2 != null) {
        equals = Some(Math.abs(d1 - d2) < 0.01d)
      } else {
        equals = Some(false)
      }
    }
    assert(equals.isDefined)
    equals.get
  }
}
