package com.thales.avionics.ife.tvs.etl.stvplus

import java.io.{File, FileReader}

import com.google.gson.JsonParser
import org.apache.commons.csv.{CSVFormat, CSVParser}

/**
  * Not a unit test - just a main method for testing seatsession files manually
  */
object StvplusLscDownloadedPlayableUtilMain {

  def main(args: Array[String]): Unit = {
    var file: Option[String] = None
    var dir: Option[String] = None
    var i = 0
    while(i < args.length) {
      val arg = args(i)
      arg match {
        case "-file" => {
          i = i + 1
          file = Some(args(i))
        }
        case "-dir" => {
          i = i + 1
          dir = Some(args(i))
        }
        case _ => //ignore
      }
      i = i + 1
    }
    if(file.isDefined) {
      processFiles(Seq(new File(file.get)))
    } else if(dir.isDefined) {
      val files = new scala.collection.mutable.ArrayBuffer[File]()
      processFiles(new File(dir.get).listFiles())
    } else {
      throw new IllegalArgumentException("No file or directory specified")
    }
  }

  private def processFiles(files: Seq[File]): Unit = {
    val jsonParser = new JsonParser()
    var seatsWithLscCnt = 0
    for(file <- files) {
      val csvParser = new CSVParser(new FileReader(file), CSVFormat.DEFAULT)
      val lineIter = csvParser.iterator()
      while(lineIter.hasNext) {
        val line = lineIter.next()
        val json = line.get(8)
        if(json.contains("HV_STATUS_REPORT")) {
          val hvStatusReport = jsonParser.parse(json).getAsJsonObject.get("event").getAsJsonObject.get("hv_status_report").toString
          val downloadedPlayable = StvplusLscDownloadedPlayableUtil.parseLscDownloadedPlayable(hvStatusReport)
          println(s"${file.getName} $downloadedPlayable")
          if(downloadedPlayable.downloadedPct > 0 && downloadedPlayable.playablePct.toDouble > 0) {
            seatsWithLscCnt = seatsWithLscCnt + 1
          }
        }
      }
      csvParser.close()
    }
    println(s"Seats with LSC: $seatsWithLscCnt")
  }

}
